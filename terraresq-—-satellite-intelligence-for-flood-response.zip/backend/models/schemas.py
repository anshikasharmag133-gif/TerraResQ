"""
TerraResQ — Pydantic Data Models & API Contracts
"""

from typing import List, Optional, Dict, Any
from pydantic import BaseModel, Field


class Coordinate(BaseModel):
    lat: float
    lng: float


class SettlementNode(BaseModel):
    id: str
    name: str
    type: str = Field(description="settlement | town | hospital")
    lat: float
    lng: float
    elevation_m: float
    population: Optional[int] = None
    nearest_town: str
    nearest_hospital: str
    baseline_distance_town_km: float
    baseline_distance_hospital_km: float
    connectivity_status: str = Field(description="CONNECTED | CUT_OFF")
    blocked_route_name: Optional[str] = None
    cutoff_reason: Optional[str] = None
    priority_level: str = Field(description="CRITICAL | HIGH | MODERATE | LOW")


class RoadEdge(BaseModel):
    id: str
    name: str
    road_type: str
    source_node: str
    target_node: str
    length_km: float
    flood_intersected: bool
    inundation_depth_est_m: Optional[float] = None
    connectivity_impact: str
    coordinates: List[List[float]]


class BridgeFeature(BaseModel):
    id: str
    name: str
    lat: float
    lng: float
    road_name: str
    span_m: float
    flood_intersected: bool
    status: str
    confidence: str


class BuildingFootprint(BaseModel):
    id: str
    osm_id: str
    building_type: str
    lat: float
    lng: float
    affected: bool
    confidence: float
    confidence_label: str


class SegmentationMetrics(BaseModel):
    iou: float
    f1_score: float
    precision: float
    recall: float


class AnalysisResponse(BaseModel):
    region_id: str
    region_name: str
    event_name: str
    event_date: str
    is_demo: bool
    demo_notice: str
    processing_status: str
    flood_area_sq_km: float
    pre_event_water_sq_km: float
    change_area_sq_km: float
    ai_confidence_label: str
    ai_confidence_score: float
    metrics: SegmentationMetrics
    affected_buildings_count: int
    total_buildings_evaluated: int
    affected_roads_count: int
    total_roads_evaluated: int
    affected_bridges_count: int
    total_bridges_evaluated: int
    cutoff_settlements_count: int
    connected_settlements_count: int
    settlements: List[SettlementNode]
    roads: List[RoadEdge]
    bridges: List[BridgeFeature]
    buildings: List[BuildingFootprint]
