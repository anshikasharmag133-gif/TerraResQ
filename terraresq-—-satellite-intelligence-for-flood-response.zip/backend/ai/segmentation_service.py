"""
TerraResQ — Backend AI Segmentation Service Wrapper
Bridges the FastAPI routes with the `src/ai/segmentation` module.
"""

from typing import Dict, Any, Optional
import sys
import os

# Ensure root workspace path is importable
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), "../..")))

from src.ai.segmentation.inference import FloodSegmentationInferenceEngine


class SegmentationService:
    def __init__(self):
        self.engine = FloodSegmentationInferenceEngine()

    def execute_segmentation(
        self,
        region_id: str,
        s1_scene_id: str,
        s2_scene_id: Optional[str] = None,
        confusion_counts: Optional[Dict[str, int]] = None,
    ) -> Dict[str, Any]:
        return self.engine.run_inference(
            region_id=region_id,
            s1_scene=s1_scene_id,
            s2_scene=s2_scene_id,
            confusion_counts=confusion_counts,
        )
