"""
TerraResQ — FastAPI Application Entrypoint
Satellite Intelligence for Flood Response (Hackathon Track B)
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from backend.api.routes import router as api_router

app = FastAPI(
    title="TerraResQ — Satellite Intelligence for Flood Response",
    description=(
        "Modular geospatial AI backend for SAR/Optical flood segmentation, "
        "pre-event OpenStreetMap infrastructure overlay, road network cutoff graph analysis, "
        "Copernicus DEM flow modelling, and zero-hallucination situation reporting."
    ),
    version="1.0.0",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(api_router)


if __name__ == "__main__":
    import uvicorn
    uvicorn.run("backend.app.main:app", host="0.0.0.0", port=8000, reload=True)
