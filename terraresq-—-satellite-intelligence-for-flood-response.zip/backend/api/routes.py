"""
TerraResQ — FastAPI Modular Geospatial & AI Endpoints
"""

from fastapi import APIRouter, HTTPException
from typing import Dict, Any
import json
import os

from backend.ai.segmentation_service import SegmentationService
from backend.network.graph_analyzer import RoadNetworkGraphAnalyzer
from backend.geospatial.processor import trace_dem_flood_flow
from backend.reports.generator import generate_structured_situation_report

router = APIRouter(prefix="/api/v1", tags=["TerraResQ Flood Intelligence"])
segmentation_service = SegmentationService()


def _load_demo_dataset() -> Dict[str, Any]:
    demo_path = os.path.abspath(
        os.path.join(os.path.dirname(__file__), "../../data/demo/trishuli_august_2026.json")
    )
    if not os.path.exists(demo_path):
        raise HTTPException(status_code=404, detail="Demo dataset file not found.")
    with open(demo_path, "r", encoding="utf-8") as f:
        return json.load(f)


@router.get("/health")
def health_check() -> Dict[str, str]:
    return {
        "service": "TerraResQ Geospatial AI Backend",
        "status": "AI FLOOD ANALYSIS SYSTEM — READY",
        "mode": "DEMO_CAPABLE",
    }


@router.post("/analyze/{region_id}")
def run_flood_analysis(region_id: str) -> Dict[str, Any]:
    datasets = _load_demo_dataset()
    region = datasets.get("regions", {}).get(region_id)
    if not region:
        raise HTTPException(status_code=404, detail=f"Region '{region_id}' not found.")

    ai_result = segmentation_service.execute_segmentation(
        region_id=region_id,
        s1_scene_id=region["sentinel1_scene"],
        s2_scene_id=region.get("sentinel2_scene"),
    )

    graph = RoadNetworkGraphAnalyzer(
        nodes=region["settlements"],
        roads=region["roads"],
        bridges=region["bridges"],
    )
    evaluated_settlements = graph.analyze_settlement_connectivity()

    return {
        "region_id": region_id,
        "region_name": region["name"],
        "ai_segmentation": ai_result,
        "settlements": evaluated_settlements,
    }


@router.post("/flow-trace")
def run_dem_flow_trace(payload: Dict[str, Any]) -> Dict[str, Any]:
    upstream_point = payload.get("upstream_point", {"lat": 28.185, "lng": 85.342, "elevation_m": 1890})
    dem_nodes = payload.get("dem_nodes", [])
    settlements = payload.get("settlements", [])
    return trace_dem_flood_flow(upstream_point, dem_nodes, settlements)


@router.post("/report")
def build_situation_report(analysis_state: Dict[str, Any]) -> Dict[str, str]:
    report_text = generate_structured_situation_report(analysis_state)
    return {"report": report_text}
