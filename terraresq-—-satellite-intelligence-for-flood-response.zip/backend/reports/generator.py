"""
TerraResQ — Strict Zero-Hallucination Situation Report Generator
Generates emergency situation reports strictly from structured geospatial analysis values.
Never invents casualty numbers, population figures, flood areas, damaged buildings,
road closures, settlement names, or confidence values.
Uses 'Data unavailable.' for any missing metric.
"""

from typing import Dict, Any, List


def generate_structured_situation_report(analysis: Dict[str, Any]) -> str:
    """
    Build a deterministic, verifiable Situation Report strictly from computed state.
    """
    event_name = analysis.get("event_name") or "Data unavailable."
    location = analysis.get("region_name") or "Data unavailable."
    analysis_date = analysis.get("event_date") or "Data unavailable."
    is_demo = analysis.get("is_demo", True)

    flood_area = analysis.get("flood_area_sq_km")
    pre_water = analysis.get("pre_event_water_sq_km")
    change_area = analysis.get("change_area_sq_km")

    affected_buildings = analysis.get("affected_buildings_count")
    total_buildings = analysis.get("total_buildings_evaluated")
    affected_roads = analysis.get("affected_roads_count")
    total_roads = analysis.get("total_roads_evaluated")
    affected_bridges = analysis.get("affected_bridges_count")
    total_bridges = analysis.get("total_bridges_evaluated")

    settlements: List[Dict[str, Any]] = analysis.get("settlements", [])
    cutoff_list = [s for s in settlements if s.get("connectivity_status") == "CUT_OFF"]
    connected_list = [s for s in settlements if s.get("connectivity_status") == "CONNECTED"]

    roads: List[Dict[str, Any]] = analysis.get("roads", [])
    flooded_roads = [r for r in roads if r.get("flood_intersected")]

    metrics = analysis.get("metrics", {})
    iou = metrics.get("iou")
    f1 = metrics.get("f1_score")
    precision = metrics.get("precision")
    recall = metrics.get("recall")
    confidence = analysis.get("ai_confidence_label") or "Data unavailable."

    demo_header = (
        "NOTICE: DEMO MODE — Sample data. Replace with real Sentinel imagery for operational analysis.\n"
        if is_demo
        else "OPERATIONAL SATELLITE ANALYSIS REPORT\n"
    )

    cutoff_lines = []
    if cutoff_list:
        for s in cutoff_list:
            pop_str = f"{s['population']} residents" if s.get("population") is not None else "Data unavailable."
            route_str = s.get("blocked_route_name") or "Data unavailable."
            reason_str = s.get("cutoff_reason") or "Data unavailable."
            cutoff_lines.append(
                f"  - {s['name']} (Priority: {s.get('priority_level', 'Data unavailable.')}): "
                f"Population: {pop_str} | Previous Nearest Town: {s.get('nearest_town', 'Data unavailable.')} "
                f"| Previous Nearest Hospital: {s.get('nearest_hospital', 'Data unavailable.')} "
                f"| Blocked Route: {route_str} | Reason: {reason_str}"
            )
    else:
        cutoff_lines.append("  - None detected in current analysis state.")

    road_lines = []
    if flooded_roads:
        for r in flooded_roads:
            road_lines.append(
                f"  - {r['name']} ({r['road_type']}): Flood intersection confirmed ({r['length_km']} km segment). "
                f"Impact: {r['connectivity_impact']}"
            )
    else:
        road_lines.append("  - No flood-intersected road segments detected.")

    return f"""TERRARESQ FLOOD SITUATION REPORT
{demo_header}====================================================================
Event: {event_name}
Location: {location}
Analysis Date: {analysis_date}
Data Provenance: {"DEMO / SAMPLE DATASET" if is_demo else "LIVE SENTINEL SAR/OPTICAL"}
====================================================================

1. Flood Extent
- Total Post-Event Surface Water Extent: {f"{flood_area:.2f} sq km" if flood_area is not None else "Data unavailable."}
- Pre-Event Baseline River Channel: {f"{pre_water:.2f} sq km" if pre_water is not None else "Data unavailable."}
- Net Flood Inundation / Debris Expansion: {f"+{change_area:.2f} sq km" if change_area is not None else "Data unavailable."}
- Casualty Count: Data unavailable. (Satellite earth observation cannot measure casualties.)

2. Infrastructure Impact (Pre-Event OpenStreetMap Overlay)
- Estimated Affected Buildings: {f"{affected_buildings} of {total_buildings} evaluated structures" if affected_buildings is not None else "Data unavailable."}
- Flood-Intersected Road Segments: {f"{affected_roads} of {total_roads} network edges" if affected_roads is not None else "Data unavailable."}
- Potentially Affected Bridges: {f"{affected_bridges} of {total_bridges} river crossings" if affected_bridges is not None else "Data unavailable."}

3. Road Connectivity
- Connected Settlements / Hubs: {len(connected_list)}
- Disconnected (Cut-Off) Settlements: {len(cutoff_list)}
- Affected Corridors:
{chr(10).join(road_lines)}

4. Cut-off Settlements
{chr(10).join(cutoff_lines)}

5. Priority Areas
{chr(10).join([f"  - {s['name']} ({s.get('priority_level', 'HIGH')}): Isolated from {s.get('nearest_hospital', 'Data unavailable.')} via {s.get('blocked_route_name', 'Data unavailable.')}" for s in cutoff_list]) if cutoff_list else "  - No isolated priority settlements identified."}

6. Data Confidence
- AI Segmentation Confidence Tier: {confidence}
- Validation IoU (Jaccard Index): {f"{iou:.4f}" if iou is not None else "Data unavailable."}
- Validation F1 Score (Dice): {f"{f1:.4f}" if f1 is not None else "Data unavailable."}
- Precision / Recall: {f"{precision:.4f} / {recall:.4f}" if precision is not None and recall is not None else "Data unavailable."}

7. Limitations
- {"DEMO DATA — Replace with real Sentinel imagery for operational analysis." if is_demo else "Satellite-derived flood mask subject to SAR layover/foreshortening in steep Himalayan gorges."}
- Pre-event OpenStreetMap completeness varies in rural mountain corridors; unmapped footpaths or informal structures may be omitted.
- Building impact indicates spatial footprint intersection with the detected flood/debris extent and does not confirm structural collapse without field verification.
- Terrain flow traces use Copernicus WorldDEM-30 (30m resolution) and represent topographic steepest-descent modelling rather than hydrodynamic gauge measurements.
"""
