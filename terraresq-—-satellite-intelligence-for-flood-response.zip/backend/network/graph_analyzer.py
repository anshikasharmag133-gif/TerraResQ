"""
TerraResQ — Road Network Graph & Cut-Off Settlement Analyzer
Builds a topological graph from pre-event OpenStreetMap road segments.
Removes edges intersected by satellite-detected flood masks or damaged bridges,
then runs shortest-path Dijkstra traversal to determine whether each settlement
remains connected to the nearest Town and Hospital.
"""

from typing import Dict, List, Any, Tuple, Set
import heapq


class RoadNetworkGraphAnalyzer:
    """
    Graph connectivity engine for post-disaster lifeline accessibility analysis.
    """

    def __init__(self, nodes: List[Dict[str, Any]], roads: List[Dict[str, Any]], bridges: List[Dict[str, Any]]):
        self.nodes = {n["id"]: n for n in nodes}
        self.roads = roads
        self.bridges = bridges

    def _dijkstra(self, start_id: str, target_ids: Set[str], allow_flooded: bool = False) -> Tuple[Optional[str], float]:
        """
        Compute shortest path distance (km) from start_id to the nearest node in target_ids.
        When allow_flooded=False, flood-intersected road segments and compromised bridge links are blocked.
        """
        adj: Dict[str, List[Tuple[str, float]]] = {nid: [] for nid in self.nodes}
        for r in self.roads:
            if not allow_flooded and r.get("flood_intersected", False):
                continue
            u, v = r["source_node"], r["target_node"]
            w = float(r["length_km"])
            if u in adj and v in adj:
                adj[u].append((v, w))
                adj[v].append((u, w))

        visited: Dict[str, float] = {}
        pq: List[Tuple[float, str]] = [(0.0, start_id)]

        while pq:
            dist, curr = heapq.heappop(pq)
            if curr in visited:
                continue
            visited[curr] = dist
            if curr in target_ids:
                return curr, round(dist, 2)
            for nxt, weight in adj.get(curr, []):
                if nxt not in visited:
                    heapq.heappush(pq, (dist + weight, nxt))

        return None, float("inf")

    def analyze_settlement_connectivity(self) -> List[Dict[str, Any]]:
        """
        Evaluate every settlement node before and after flood-induced road closures.
        """
        town_ids = {nid for nid, n in self.nodes.items() if n["type"] == "town"}
        hospital_ids = {nid for nid, n in self.nodes.items() if n["type"] == "hospital"}

        results = []
        for nid, node in self.nodes.items():
            # Pre-event baseline connectivity
            base_town_id, base_town_dist = self._dijkstra(nid, town_ids, allow_flooded=True)
            base_hosp_id, base_hosp_dist = self._dijkstra(nid, hospital_ids, allow_flooded=True)

            # Post-event flood-constrained connectivity
            post_town_id, post_town_dist = self._dijkstra(nid, town_ids, allow_flooded=False)
            post_hosp_id, post_hosp_dist = self._dijkstra(nid, hospital_ids, allow_flooded=False)

            is_cutoff = (post_town_id is None) or (post_hosp_id is None)

            # Identify specific blocked route causing isolation
            blocked_routes = [
                r["name"]
                for r in self.roads
                if r.get("flood_intersected") and (r["source_node"] == nid or r["target_node"] == nid)
            ]
            blocked_route_str = blocked_routes[0] if blocked_routes else (
                "Primary corridor inundated downstream" if is_cutoff else None
            )

            results.append({
                **node,
                "nearest_town": self.nodes[base_town_id]["name"] if base_town_id else "Data unavailable.",
                "nearest_hospital": self.nodes[base_hosp_id]["name"] if base_hosp_id else "Data unavailable.",
                "baseline_distance_town_km": base_town_dist if base_town_id else 0.0,
                "baseline_distance_hospital_km": base_hosp_dist if base_hosp_id else 0.0,
                "post_event_distance_town_km": post_town_dist if post_town_id else None,
                "post_event_distance_hospital_km": post_hosp_dist if post_hosp_id else None,
                "connectivity_status": "CUT_OFF" if is_cutoff else "CONNECTED",
                "blocked_route_name": blocked_route_str,
            })

        return results
