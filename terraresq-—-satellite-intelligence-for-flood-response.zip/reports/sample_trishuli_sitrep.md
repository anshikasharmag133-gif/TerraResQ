# TERRARESQ FLOOD SITUATION REPORT (SAMPLE OUTPUT)
**NOTICE: DEMO MODE — Sample data. Replace with real Sentinel imagery for operational analysis.**

- **Event:** August 2026 Trishuli Flood
- **Location:** Trishuli River Corridor (Rasuwa–Nuwakot, Nepal)
- **Analysis Date:** 2026-08-14

See interactive dashboard Situation Report Copilot to generate live reports from current analysis state and export to PDF.
