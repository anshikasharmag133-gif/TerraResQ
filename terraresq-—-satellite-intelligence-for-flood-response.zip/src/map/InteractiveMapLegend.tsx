import React, { useState } from 'react';
import {
  InfrastructureAndIsolationSummary,
  MapLayerVisibility,
  SelectedMapObject,
  StudyAreaConfig,
  WaterCandidateMaskResult,
} from '../types/terraresq';

export type LegendFilterCategory = 'ALL' | 'FLOOD' | 'ROADS' | 'SETTLEMENTS';

export interface InteractiveMapLegendProps {
  layers: MapLayerVisibility;
  onToggleLayer: (key: keyof MapLayerVisibility) => void;
  maskResult: WaterCandidateMaskResult | null;
  infraSummary: InfrastructureAndIsolationSummary;
  studyArea: StudyAreaConfig;
  onSelectObject?: (obj: SelectedMapObject) => void;
  onOpenExportGeoJson?: () => void;
  className?: string;
  defaultExpanded?: boolean;
}

export const InteractiveMapLegend: React.FC<InteractiveMapLegendProps> = ({
  layers,
  onToggleLayer,
  maskResult,
  infraSummary,
  studyArea,
  onSelectObject,
  onOpenExportGeoJson,
  className = '',
  defaultExpanded = true,
}) => {
  const [isExpanded, setIsExpanded] = useState<boolean>(defaultExpanded);
  const [category, setCategory] = useState<LegendFilterCategory>('ALL');
  const [isModalView, setIsModalView] = useState<boolean>(false);

  // Computed metrics
  const floodCandidatePixels = maskResult?.newCandidatePixels ?? null;
  const floodAreaSqKm =
    maskResult?.areaDefensible && maskResult.newCandidateAreaSqKm !== null
      ? maskResult.newCandidateAreaSqKm
      : null;

  const impassableRoads = infraSummary.roads.filter((r) => r.markedImpassableByRule);
  const exposedRoads = infraSummary.roads.filter((r) => r.exposed && !r.markedImpassableByRule);
  const passableRoads = infraSummary.roads.filter((r) => !r.markedImpassableByRule && !r.exposed);

  const villageNodes = infraSummary.settlements.filter(
    (s) => s.placeType !== 'hospital' && s.placeType !== 'town'
  );
  const cutOffSettlements = villageNodes.filter(
    (s) => s.isolationStatus === 'CANDIDATE_CUT_OFF'
  );
  const reachableSettlements = villageNodes.filter(
    (s) => s.isolationStatus === 'REACHABLE_ESTIMATE'
  );
  const hospitalNodes = infraSummary.settlements.filter((s) => s.placeType === 'hospital');
  const townNodes = infraSummary.settlements.filter((s) => s.placeType === 'town');

  const activeKeyLayersCount = [
    layers.waterCandidateMask,
    layers.osmRoads,
    layers.osmSettlements,
    layers.osmHospitalsAndTowns,
    layers.osmBridges,
    layers.osmBuildings,
    layers.groundTruthFloodMask,
  ].filter(Boolean).length;

  // Toggle all key thematic layers at once
  const handleToggleAllThematic = (visible: boolean) => {
    const thematicKeys: (keyof MapLayerVisibility)[] = [
      'waterCandidateMask',
      'osmRoads',
      'osmSettlements',
      'osmHospitalsAndTowns',
      'osmBridges',
    ];
    for (const key of thematicKeys) {
      if (Boolean(layers[key]) !== visible) {
        onToggleLayer(key);
      }
    }
  };

  // Content render for both docked card & enlarged modal
  const renderLegendBody = () => (
    <div className="flex flex-col h-full text-xs font-mono text-slate-200">
      {/* 1. Header with Controls */}
      <div className="px-3.5 py-2.5 bg-[#0B0E17] border-b border-[#1E293B] flex items-center justify-between gap-2 shrink-0">
        <div className="flex items-center gap-2 min-w-0">
          <span className="w-2.5 h-2.5 rounded-full bg-teal-400 animate-pulse shrink-0" />
          <div className="truncate">
            <span className="text-[10px] font-bold tracking-wider text-teal-400 uppercase">
              INTERACTIVE MAP LEGEND
            </span>
            <div className="text-xs font-sans font-semibold text-slate-100 truncate">
              Layer Symbology & Visibility Controls
            </div>
          </div>
        </div>

        <div className="flex items-center gap-1.5 shrink-0">
          <button
            type="button"
            onClick={() => setIsModalView(!isModalView)}
            className="px-2 py-1 rounded bg-[#111827] hover:bg-[#1E293B] border border-[#1E293B] text-[10px] text-slate-300 font-medium transition-colors cursor-pointer"
            title={isModalView ? 'Dock legend onto map' : 'Expand legend into centered dialog'}
          >
            {isModalView ? 'Dock' : 'Enlarge'}
          </button>
          <button
            type="button"
            onClick={() => {
              if (isModalView) setIsModalView(false);
              else setIsExpanded(false);
            }}
            className="px-2 py-1 rounded bg-[#1E293B] hover:bg-slate-700 text-slate-200 text-[10px] font-medium transition-colors cursor-pointer"
            title="Collapse legend"
            aria-label="Collapse legend"
          >
            ✕
          </button>
        </div>
      </div>

      {/* 2. Category Filter & Batch Controls Strip */}
      <div className="px-3 py-2 bg-[#111827] border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2 shrink-0 text-[11px]">
        <div className="flex items-center gap-1 overflow-x-auto py-0.5">
          {(
            [
              { id: 'ALL', label: 'All' },
              { id: 'FLOOD', label: 'Flood Pixels' },
              { id: 'ROADS', label: 'Road Closures' },
              { id: 'SETTLEMENTS', label: 'Settlements' },
            ] as { id: LegendFilterCategory; label: string }[]
          ).map((tab) => (
            <button
              key={tab.id}
              type="button"
              onClick={() => setCategory(tab.id)}
              className={`px-2 py-1 rounded transition-colors whitespace-nowrap cursor-pointer text-[10px] ${
                category === tab.id
                  ? 'bg-teal-500 text-slate-950 font-bold shadow-xs'
                  : 'bg-[#0F172A] text-slate-300 hover:bg-[#1E293B] border border-[#1E293B]'
              }`}
            >
              {tab.label}
            </button>
          ))}
        </div>

        <div className="flex items-center gap-1.5 text-[10px]">
          <button
            type="button"
            onClick={() => handleToggleAllThematic(true)}
            className="px-1.5 py-0.5 rounded text-teal-300 hover:text-teal-200 hover:bg-teal-950/40 border border-teal-800/60 cursor-pointer"
            title="Enable all thematic layers"
          >
            All On
          </button>
          <button
            type="button"
            onClick={() => handleToggleAllThematic(false)}
            className="px-1.5 py-0.5 rounded text-slate-400 hover:text-slate-200 hover:bg-slate-800 border border-slate-700 cursor-pointer"
            title="Hide thematic layers"
          >
            All Off
          </button>
        </div>
      </div>

      {/* 3. Symbology & Visibility Status Cards List */}
      <div className="flex-1 overflow-y-auto p-3 space-y-2.5 max-h-[420px] divide-y divide-slate-800/60">
        {/* A. FLOOD CANDIDATE PIXELS */}
        {(category === 'ALL' || category === 'FLOOD') && (
          <div className="pt-2 first:pt-0 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div className="flex items-start gap-2.5">
                {/* Swatch: Cyan/Teal raster drop */}
                <div className="relative w-5 h-5 rounded-xs bg-cyan-400 border-2 border-[#0D9488] shadow-sm shrink-0 mt-0.5 flex items-center justify-center">
                  <span className="w-1.5 h-1.5 rounded-full bg-white opacity-80" />
                </div>
                <div>
                  <div className="font-sans font-bold text-slate-100 text-xs flex items-center gap-1.5">
                    <span>Flood Candidate Pixels</span>
                    <span className="text-[10px] font-mono text-cyan-300 font-semibold px-1 py-0.2 rounded bg-cyan-950/60 border border-cyan-800/60">
                      #22D3EE / #0D9488
                    </span>
                  </div>
                  <div className="text-[10px] text-teal-300 font-mono mt-0.5">
                    Low-Backscatter VV Drop (≤ {maskResult ? maskResult.thresholdDb : -17} dB)
                  </div>
                  <p className="text-[11px] font-sans text-slate-400 mt-0.5 leading-snug">
                    Sentinel-1 SAR candidate water inundation mask. Method:{' '}
                    <span className="text-amber-400 font-semibold">baseline only, not AI</span>.
                  </p>
                </div>
              </div>

              {/* Layer Visibility Toggle Button */}
              <button
                type="button"
                onClick={() => onToggleLayer('waterCandidateMask')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  layers.waterCandidateMask
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/60 shadow-xs'
                    : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-300'
                }`}
                title="Toggle flood candidate mask visibility on map"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    layers.waterCandidateMask ? 'bg-teal-400 animate-pulse' : 'bg-slate-600'
                  }`}
                />
                <span>{layers.waterCandidateMask ? 'VISIBLE' : 'HIDDEN'}</span>
              </button>
            </div>

            {/* Live Statistics & Measurements */}
            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono bg-[#111827] p-2 rounded border border-[#1E293B]">
              <div>
                <span className="text-slate-500 block">PIXEL COUNT</span>
                <span className="text-teal-300 font-bold">
                  {floodCandidatePixels !== null
                    ? `${floodCandidatePixels.toLocaleString()} px`
                    : 'not assessed'}
                </span>
              </div>
              <div>
                <span className="text-slate-500 block">DEFENSIBLE EXTENT</span>
                <span className="text-blue-300 font-bold">
                  {floodAreaSqKm !== null ? `${floodAreaSqKm.toFixed(3)} km²` : 'not assessed'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* B. ROAD CLOSURES & CORRIDORS */}
        {(category === 'ALL' || category === 'ROADS') && (
          <div className="pt-2.5 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-sans font-bold text-slate-100 text-xs flex items-center gap-1.5">
                  <span>Pre-Event OSM Road Corridors</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({infraSummary.roads.length} segments)
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  Source: {infraSummary.osmSourceLabel} · Intersection: exposure estimate
                </div>
              </div>

              {/* Roads Layer Visibility Toggle */}
              <button
                type="button"
                onClick={() => onToggleLayer('osmRoads')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  layers.osmRoads
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/60 shadow-xs'
                    : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-300'
                }`}
                title="Toggle road network visibility on map"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    layers.osmRoads ? 'bg-teal-400 animate-pulse' : 'bg-slate-600'
                  }`}
                />
                <span>{layers.osmRoads ? 'VISIBLE' : 'HIDDEN'}</span>
              </button>
            </div>

            {/* Sub-symbology: Impassable, Exposed, Passable */}
            <div className="space-y-1.5 bg-[#111827] p-2.5 rounded border border-[#1E293B]">
              {/* 1. Impassable Road Closure */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-0 border-t-3 border-dashed border-[#DC2626] shrink-0" />
                  <span className="font-semibold text-rose-400 text-[11px]">
                    Assumed Impassable Road (#DC2626)
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[10px]">
                  <span className="text-rose-300 font-bold font-mono">
                    {infraSummary.roads.length > 0 ? `${impassableRoads.length} closed` : 'not assessed'}
                  </span>
                  {impassableRoads.length > 0 && onSelectObject && (
                    <button
                      type="button"
                      onClick={() => onSelectObject({ kind: 'road', data: impassableRoads[0] })}
                      className="text-teal-300 hover:underline cursor-pointer"
                    >
                      Inspect →
                    </button>
                  )}
                </div>
              </div>

              {/* 2. Exposed Road Segment */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-1.5 rounded-xs bg-[#D97706] shrink-0" />
                  <span className="text-amber-300 text-[11px]">
                    Exposed Road Segment (#D97706)
                  </span>
                </div>
                <span className="text-amber-300 font-mono text-[10px]">
                  {infraSummary.roads.length > 0 ? `${exposedRoads.length} exp` : 'not assessed'}
                </span>
              </div>

              {/* 3. Passable Road */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-5 h-1.5 rounded-xs bg-[#0D9488] shrink-0" />
                  <span className="text-teal-300 text-[11px]">
                    Passable Road (#0D9488)
                  </span>
                </div>
                <span className="text-slate-400 font-mono text-[10px]">
                  {infraSummary.roads.length > 0 ? `${passableRoads.length} open` : 'not assessed'}
                </span>
              </div>
            </div>
          </div>
        )}

        {/* C. AFFECTED SETTLEMENTS & HOSPITALS */}
        {(category === 'ALL' || category === 'SETTLEMENTS') && (
          <div className="pt-2.5 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-sans font-bold text-slate-100 text-xs flex items-center gap-1.5">
                  <span>Settlements & Health Facilities</span>
                  <span className="text-[10px] text-slate-400 font-mono">
                    ({villageNodes.length} nodes)
                  </span>
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  Connectivity: graph route to closest town or hospital
                </div>
              </div>

              {/* Settlements Layer Visibility Toggle */}
              <button
                type="button"
                onClick={() => onToggleLayer('osmSettlements')}
                className={`px-2.5 py-1 rounded text-[11px] font-semibold border transition-all shrink-0 cursor-pointer flex items-center gap-1.5 ${
                  layers.osmSettlements
                    ? 'bg-teal-500/20 text-teal-300 border-teal-500/60 shadow-xs'
                    : 'bg-slate-800/80 text-slate-400 border-slate-700 hover:text-slate-300'
                }`}
                title="Toggle settlement markers visibility on map"
              >
                <span
                  className={`w-2 h-2 rounded-full ${
                    layers.osmSettlements ? 'bg-teal-400 animate-pulse' : 'bg-slate-600'
                  }`}
                />
                <span>{layers.osmSettlements ? 'VISIBLE' : 'HIDDEN'}</span>
              </button>
            </div>

            {/* Sub-symbology: Cut-Off, Reachable, Hospital */}
            <div className="space-y-1.5 bg-[#111827] p-2.5 rounded border border-[#1E293B]">
              {/* 1. Candidate Cut-Off Settlement */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-full bg-[#DC2626] border-2 border-white shadow-xs shrink-0 flex items-center justify-center text-[8px] text-white font-bold">
                    ✕
                  </span>
                  <span className="font-semibold text-rose-400 text-[11px]">
                    Cut-Off Settlement (#DC2626)
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[10px]">
                  <span className="text-rose-300 font-bold font-mono">
                    {villageNodes.length > 0 ? `${cutOffSettlements.length} isolated` : 'not assessed'}
                  </span>
                  {cutOffSettlements.length > 0 && onSelectObject && (
                    <button
                      type="button"
                      onClick={() =>
                        onSelectObject({ kind: 'settlement', data: cutOffSettlements[0] })
                      }
                      className="text-teal-300 hover:underline cursor-pointer"
                    >
                      Inspect →
                    </button>
                  )}
                </div>
              </div>

              {/* 2. Reachable Settlement */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-full bg-[#0D9488] border-2 border-white shadow-xs shrink-0" />
                  <span className="text-teal-300 text-[11px]">
                    Reachable Settlement (#0D9488)
                  </span>
                </div>
                <span className="text-teal-300 font-mono text-[10px]">
                  {villageNodes.length > 0 ? `${reachableSettlements.length} reachable` : 'not assessed'}
                </span>
              </div>

              {/* 3. Hospital Facility */}
              <div className="flex items-center justify-between gap-2">
                <div className="flex items-center gap-2">
                  <span className="w-3.5 h-3.5 rounded-full bg-[#2563EB] border-2 border-white shadow-xs shrink-0 flex items-center justify-center text-[8px] text-white font-bold">
                    H
                  </span>
                  <span className="text-sky-300 text-[11px]">
                    Hospital / Health Post (#2563EB)
                  </span>
                </div>
                <div className="flex items-center gap-2 text-[10px]">
                  <span className="text-sky-300 font-mono">
                    {hospitalNodes.length > 0 ? `${hospitalNodes.length} facility` : 'not assessed'}
                  </span>
                  <button
                    type="button"
                    onClick={() => onToggleLayer('osmHospitalsAndTowns')}
                    className={`text-[9px] px-1.5 py-0.2 rounded border ${
                      layers.osmHospitalsAndTowns
                        ? 'border-sky-500/50 text-sky-300'
                        : 'border-slate-700 text-slate-500'
                    }`}
                  >
                    {layers.osmHospitalsAndTowns ? 'ON' : 'OFF'}
                  </button>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* D. BRIDGES & BUILDINGS (Infrastructure Exposure) */}
        {category === 'ALL' && (
          <div className="pt-2.5 space-y-2">
            <div className="flex items-start justify-between gap-2">
              <div>
                <div className="font-sans font-bold text-slate-100 text-xs">
                  River Bridges & Buildings
                </div>
                <div className="text-[10px] text-slate-400 font-mono mt-0.5">
                  Over-water crossings and structural footprints
                </div>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => onToggleLayer('osmBridges')}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                    layers.osmBridges
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                  title="Toggle OSM bridges"
                >
                  Bridges: {layers.osmBridges ? 'ON' : 'OFF'}
                </button>
                <button
                  type="button"
                  onClick={() => onToggleLayer('osmBuildings')}
                  className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                    layers.osmBuildings
                      ? 'bg-amber-500/20 text-amber-300 border-amber-500/50'
                      : 'bg-slate-800 text-slate-400 border-slate-700'
                  }`}
                  title="Toggle OSM buildings"
                >
                  Bldgs: {layers.osmBuildings ? 'ON' : 'OFF'}
                </button>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-2 text-[10px] font-mono bg-[#111827] p-2 rounded border border-[#1E293B]">
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-full bg-[#F59E0B] border border-white shrink-0" />
                <span className="text-amber-300">
                  {infraSummary.exposedBridgesCount ?? 0}/{infraSummary.totalBridgesCount} Bridges Exp
                </span>
              </div>
              <div className="flex items-center gap-1.5">
                <span className="w-2.5 h-2.5 rounded-xs bg-[#F59E0B] border border-slate-300 shrink-0" />
                <span className="text-amber-300">
                  {infraSummary.exposedBuildingsCount ?? 0}/{infraSummary.totalBuildingsCount} Bldgs Exp
                </span>
              </div>
            </div>
          </div>
        )}

        {/* E. GROUND-TRUTH & VALIDATION REFERENCE */}
        {category === 'ALL' && (
          <div className="pt-2.5 space-y-1.5">
            <div className="flex items-center justify-between gap-2">
              <div className="flex items-center gap-2">
                <span className="w-4 h-3.5 rounded-xs border-2 border-dashed border-[#9333EA] bg-[#A855F7]/30 shrink-0" />
                <span className="font-sans text-xs text-purple-300 font-semibold">
                  Ground-Truth Flood Mask (Kuro Siwo)
                </span>
              </div>

              <button
                type="button"
                onClick={() => onToggleLayer('groundTruthFloodMask')}
                className={`px-2 py-0.5 rounded text-[10px] font-mono border ${
                  layers.groundTruthFloodMask
                    ? 'bg-purple-500/20 text-purple-300 border-purple-500/60'
                    : 'bg-slate-800 text-slate-400 border-slate-700'
                }`}
              >
                {layers.groundTruthFloodMask ? 'VISIBLE' : 'HIDDEN'}
              </button>
            </div>
            <div className="text-[10px] font-mono text-slate-500">
              Reference labels only. Strictly kept separate from model predictions and inferences.
            </div>
          </div>
        )}
      </div>

      {/* 4. Footer Summary & External Export Action */}
      <div className="px-3.5 py-2.5 bg-[#0B0E17] border-t border-[#1E293B] flex items-center justify-between gap-2 shrink-0 text-[11px] font-mono">
        <div className="text-slate-400 truncate">
          <span className="text-teal-400 font-semibold">{activeKeyLayersCount}</span> of 7 layers active
        </div>

        {onOpenExportGeoJson && (
          <button
            type="button"
            onClick={onOpenExportGeoJson}
            className="px-2.5 py-1 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-600/60 rounded text-[10px] font-semibold transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
          >
            <span>⤓ Export GeoJSON</span>
          </button>
        )}
      </div>
    </div>
  );

  return (
    <>
      {/* 1. COMPACT DOCKED BAR (Rendered on map when collapsed) */}
      {!isExpanded && !isModalView && (
        <div
          className={`absolute bottom-3 left-3 z-[400] bg-[#0F172A]/95 backdrop-blur-xs border border-[#1E293B] rounded-md px-3 py-2 text-[11px] font-mono text-slate-200 shadow-xl flex flex-wrap items-center gap-3 animate-card-enter ${className}`}
        >
          {/* Quick Swatches Preview */}
          <div className="flex items-center gap-2.5">
            <span
              className="inline-flex items-center gap-1 cursor-pointer hover:text-teal-300"
              onClick={() => onToggleLayer('waterCandidateMask')}
              title={`Flood Candidate Pixels: ${layers.waterCandidateMask ? 'VISIBLE' : 'HIDDEN'}`}
            >
              <span className="w-2.5 h-2.5 rounded-xs bg-cyan-400 border border-[#0D9488]" />
              <span className={layers.waterCandidateMask ? 'text-cyan-300' : 'text-slate-500 line-through'}>
                Flood ({floodCandidatePixels !== null ? `${floodCandidatePixels.toLocaleString()}px` : 'N/A'})
              </span>
            </span>

            <span
              className="inline-flex items-center gap-1 cursor-pointer hover:text-rose-300"
              onClick={() => onToggleLayer('osmRoads')}
              title={`Impassable Roads: ${layers.osmRoads ? 'VISIBLE' : 'HIDDEN'}`}
            >
              <span className="w-3.5 h-0 border-t-2 border-dashed border-[#DC2626]" />
              <span className={layers.osmRoads ? 'text-rose-300' : 'text-slate-500 line-through'}>
                Road Closures ({impassableRoads.length})
              </span>
            </span>

            <span
              className="inline-flex items-center gap-1 cursor-pointer hover:text-rose-300"
              onClick={() => onToggleLayer('osmSettlements')}
              title={`Cut-Off Settlements: ${layers.osmSettlements ? 'VISIBLE' : 'HIDDEN'}`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#DC2626] border border-white" />
              <span className={layers.osmSettlements ? 'text-rose-300' : 'text-slate-500 line-through'}>
                Cut-Off ({cutOffSettlements.length})
              </span>
            </span>

            <span
              className="inline-flex items-center gap-1 cursor-pointer hover:text-sky-300"
              onClick={() => onToggleLayer('osmHospitalsAndTowns')}
              title={`Hospitals: ${layers.osmHospitalsAndTowns ? 'VISIBLE' : 'HIDDEN'}`}
            >
              <span className="w-2.5 h-2.5 rounded-full bg-[#2563EB] border border-white" />
              <span className={layers.osmHospitalsAndTowns ? 'text-sky-300' : 'text-slate-500 line-through'}>
                [H] Hospital
              </span>
            </span>
          </div>

          {/* Action buttons */}
          <div className="flex items-center gap-1.5 ml-auto border-l border-slate-700 pl-2.5">
            <button
              type="button"
              onClick={() => setIsExpanded(true)}
              className="px-2 py-0.5 bg-teal-600 hover:bg-teal-500 text-slate-950 font-bold rounded text-[10px] transition-colors cursor-pointer flex items-center gap-1 shadow-xs"
            >
              <span>Interactive Legend</span>
              <span className="text-[9px]">▲</span>
            </button>

            {onOpenExportGeoJson && (
              <button
                type="button"
                onClick={onOpenExportGeoJson}
                className="px-2 py-0.5 bg-emerald-950 hover:bg-emerald-900 text-emerald-300 border border-emerald-600/50 rounded text-[10px] font-semibold transition-colors cursor-pointer"
                title="Download GeoJSON for external GIS processing"
              >
                <span>Export</span>
              </button>
            )}
          </div>
        </div>
      )}

      {/* 2. DOCKED EXPANDED OVERLAY ON MAP */}
      {isExpanded && !isModalView && (
        <div
          id="terraresq-interactive-legend-docked"
          className={`absolute bottom-3 left-3 z-[450] w-[340px] sm:w-[420px] max-w-[calc(100vw-24px)] bg-[#0F172A] border border-[#1E293B] rounded-md shadow-2xl overflow-hidden animate-panel-enter ${className}`}
        >
          {renderLegendBody()}
        </div>
      )}

      {/* 3. CENTERED MODAL DIALOG VIEW */}
      {isModalView && (
        <div
          id="terraresq-interactive-legend-modal"
          role="dialog"
          aria-modal="true"
          aria-label="Interactive Map Symbology & Provenance Legend"
          className="absolute inset-0 z-[500] bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto animate-panel-enter"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setIsModalView(false);
            }
          }}
        >
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-lg shadow-2xl w-full max-w-2xl max-h-[85vh] flex flex-col overflow-hidden">
            {renderLegendBody()}
          </div>
        </div>
      )}
    </>
  );
};
