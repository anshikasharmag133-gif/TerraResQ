import React, { useEffect, useMemo, useState } from 'react';
import {
  MapContainer,
  TileLayer,
  ImageOverlay,
  Polygon,
  Polyline,
  CircleMarker,
  Popup,
  Tooltip,
  Rectangle,
  useMap,
} from 'react-leaflet';
import {
  InfrastructureAndIsolationSummary,
  MapLayerVisibility,
  OpticalSatelliteImage,
  SelectedMapObject,
  StudyAreaConfig,
  WaterCandidateMaskResult,
} from '../types/terraresq';
import {
  generateTerraResQGeoJson,
  triggerGeoJsonDownload,
  GeoJsonExportScope,
} from '../services/geoJsonExporter';
import { InteractiveMapLegend } from './InteractiveMapLegend';

export type LegendCategoryFilter =
  | 'ALL'
  | 'FLOOD_CANDIDATES'
  | 'ROADS'
  | 'SETTLEMENTS'
  | 'HOSPITALS';

interface FloodIntelligenceMapProps {
  studyArea: StudyAreaConfig;
  maskResult: WaterCandidateMaskResult | null;
  infraSummary: InfrastructureAndIsolationSummary;
  layers: MapLayerVisibility;
  onToggleLayer?: (key: keyof MapLayerVisibility) => void;
  selectedObject: SelectedMapObject;
  onSelectObject: (obj: SelectedMapObject) => void;
  postOptical?: OpticalSatelliteImage | null;
}

function MapBoundsController({
  center,
  zoom,
  rasterBounds,
}: {
  center: [number, number];
  zoom: number;
  rasterBounds: [[number, number], [number, number]] | null;
}) {
  const map = useMap();
  useEffect(() => {
    if (rasterBounds) {
      map.fitBounds(rasterBounds, { padding: [28, 28], maxZoom: 14 });
    } else {
      map.setView(center, zoom);
    }
  }, [center, zoom, rasterBounds, map]);
  return null;
}

export const FloodIntelligenceMap: React.FC<FloodIntelligenceMapProps> = ({
  studyArea,
  maskResult,
  infraSummary,
  layers,
  onToggleLayer,
  onSelectObject,
  postOptical,
}) => {
  // GeoJSON Export State
  const [isGeoJsonModalOpen, setIsGeoJsonModalOpen] = useState<boolean>(false);
  const [geoJsonScope, setGeoJsonScope] = useState<GeoJsonExportScope>('COMBINED');
  const [downloadNotification, setDownloadNotification] = useState<string | null>(null);
  const [isCopied, setIsCopied] = useState<boolean>(false);

  // Symbology Legend State
  const [isLegendOpen, setIsLegendOpen] = useState<boolean>(false);
  const [legendViewMode, setLegendViewMode] = useState<'MODAL' | 'OVERLAY'>('OVERLAY');
  const [legendCategory, setLegendCategory] = useState<LegendCategoryFilter>('ALL');

  const passableRoadsCount = infraSummary.roads.filter((r) => !r.markedImpassableByRule && !r.exposed).length;
  const exposedRoadsCount = infraSummary.roads.filter((r) => r.exposed && !r.markedImpassableByRule).length;
  const impassableRoadsCount = infraSummary.roads.filter((r) => r.markedImpassableByRule).length;

  const floodCandidatePolygonsCount = maskResult?.candidatePolygonsWgs84?.length || 0;
  const totalExportableFeatures = floodCandidatePolygonsCount + impassableRoadsCount;

  const currentExportData = useMemo(() => {
    return generateTerraResQGeoJson(maskResult, infraSummary, studyArea, geoJsonScope);
  }, [maskResult, infraSummary, studyArea, geoJsonScope]);

  const currentExportSummary = currentExportData.summary;

  const sampleGeoJsonPreview = useMemo(() => {
    const full = JSON.stringify(currentExportData.geoJson, null, 2);
    const lines = full.split('\n');
    if (lines.length <= 42) return full;
    return lines.slice(0, 38).join('\n') + `\n  ... (${lines.length - 38} more lines in full export)`;
  }, [currentExportData]);

  const handleDownloadGeoJson = (scope: GeoJsonExportScope = geoJsonScope) => {
    const { geoJson, summary } = generateTerraResQGeoJson(
      maskResult,
      infraSummary,
      studyArea,
      scope
    );
    const dateStr = studyArea.eventDate || new Date().toISOString().slice(0, 10);
    const scopeLabel =
      scope === 'COMBINED'
        ? 'flood_mask_and_impassable_roads'
        : scope === 'FLOOD_MASK_ONLY'
        ? 'flood_candidate_mask'
        : 'impassable_roads';
    const cleanArea = studyArea.areaName.toLowerCase().replace(/[^a-z0-9]+/g, '_');
    const fileName = `terraresq_${cleanArea}_${scopeLabel}_${dateStr}.geojson`;

    triggerGeoJsonDownload(geoJson, fileName);
    setDownloadNotification(
      `Exported ${summary.totalFeatures} feature(s) (${summary.floodPolygonCount} flood polygons, ${summary.impassableRoadCount} impassable roads) to ${fileName}`
    );
    setTimeout(() => {
      setDownloadNotification(null);
    }, 6000);
  };

  const handleCopyGeoJson = () => {
    const { geoJson } = generateTerraResQGeoJson(
      maskResult,
      infraSummary,
      studyArea,
      geoJsonScope
    );
    navigator.clipboard.writeText(JSON.stringify(geoJson, null, 2)).then(() => {
      setIsCopied(true);
      setTimeout(() => setIsCopied(false), 2500);
    });
  };

  const villageNodes = infraSummary.settlements.filter(
    (s) => s.placeType !== 'hospital' && s.placeType !== 'town'
  );
  const reachableVillagesCount = villageNodes.filter(
    (s) => s.isolationStatus === 'REACHABLE_ESTIMATE'
  ).length;
  const cutOffVillagesCount = villageNodes.filter(
    (s) => s.isolationStatus === 'CANDIDATE_CUT_OFF'
  ).length;

  const hospitalNodes = infraSummary.settlements.filter((s) => s.placeType === 'hospital');
  const townNodes = infraSummary.settlements.filter((s) => s.placeType === 'town');

  const aoiRectBounds: [[number, number], [number, number]] = [
    [studyArea.bbox[1], studyArea.bbox[0]],
    [studyArea.bbox[3], studyArea.bbox[2]],
  ];

  return (
    <div className="relative w-full h-full min-h-[520px] bg-[#E2E8F0] overflow-hidden">
      <MapContainer
        center={studyArea.center}
        zoom={studyArea.zoom}
        className="w-full h-full z-0 cursor-crosshair"
        zoomControl={true}
      >
        <MapBoundsController
          center={studyArea.center}
          zoom={studyArea.zoom}
          rasterBounds={maskResult?.wgs84Bounds || null}
        />

        {/* 1. Daylight Cartographic Base Map (CARTO Voyager) */}
        {layers.baseMap && (
          <TileLayer
            attribution='&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; CARTO'
            url="https://{s}.basemaps.cartocdn.com/rastertiles/voyager/{z}/{x}/{y}{r}.png"
          />
        )}

        {/* Study Area Bounding Box Outline */}
        <Rectangle
          bounds={aoiRectBounds}
          pathOptions={{
            color: '#0D9488',
            weight: 1.5,
            dashArray: '5 5',
            fillColor: '#0D9488',
            fillOpacity: 0.03,
          }}
        />

        {/* 2. Pre-Event Sentinel-1 VV dB Raster Overlay */}
        {layers.preEventRaster && maskResult && maskResult.wgs84Bounds && (
          <ImageOverlay
            url={maskResult.beforeDataUrl}
            bounds={maskResult.wgs84Bounds}
            opacity={0.78}
          />
        )}

        {/* 3. Post-Event Sentinel-1 VV dB Raster Overlay */}
        {layers.postEventRaster && maskResult && maskResult.wgs84Bounds && (
          <ImageOverlay
            url={maskResult.afterDataUrl}
            bounds={maskResult.wgs84Bounds}
            opacity={0.82}
          />
        )}

        {/* 3b. Sentinel-2 Optical RGB Overlay */}
        {layers.opticalOverlay && postOptical && maskResult && maskResult.wgs84Bounds && (
          <ImageOverlay
            url={postOptical.dataUrl}
            bounds={maskResult.wgs84Bounds}
            opacity={0.85}
          />
        )}

        {/* 4. Low-Backscatter Water-Candidate Mask Overlay (baseline only, not AI) */}
        {layers.waterCandidateMask && maskResult && maskResult.wgs84Bounds && (
          <ImageOverlay
            url={maskResult.maskDataUrl}
            bounds={maskResult.wgs84Bounds}
            opacity={0.92}
          />
        )}

        {/* 5. Pre-Event OSM Buildings (Exposure Estimates) */}
        {layers.osmBuildings &&
          infraSummary.buildings.map((bldg) => (
            <Polygon
              key={bldg.id}
              positions={bldg.footprint}
              pathOptions={{
                color: bldg.exposed ? '#D97706' : '#475569',
                weight: bldg.exposed ? 2 : 1.2,
                fillColor: bldg.exposed ? '#F59E0B' : '#64748B',
                fillOpacity: bldg.exposed ? 0.75 : 0.45,
              }}
              eventHandlers={{
                click: () => onSelectObject({ kind: 'building', data: bldg }),
              }}
            >
              <Popup>
                <div className="text-xs space-y-1 min-w-[210px] font-mono text-slate-800">
                  <div className="font-sans font-semibold text-slate-900 border-b border-slate-200 pb-1">
                    {bldg.name}
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">OSM ID:</span>
                    <span>{bldg.osmId}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Exposure Status:</span>
                    <span className={bldg.exposed ? 'text-amber-700 font-semibold' : 'text-teal-700'}>
                      {bldg.exposed ? 'EXPOSED (Candidate Overlap)' : 'Not Exposed'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Provenance:</span>
                    <span>{bldg.provenanceStatus}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 pt-1">
                    Note: Exposure does not imply confirmed structural damage.
                  </div>
                </div>
              </Popup>
            </Polygon>
          ))}

        {/* 6. Pre-Event OSM Roads & Impassability Assumptions */}
        {layers.osmRoads &&
          infraSummary.roads.map((road) => (
            <Polyline
              key={road.id}
              positions={road.coordinates}
              pathOptions={{
                color: road.markedImpassableByRule
                  ? '#DC2626'
                  : road.exposed
                    ? '#D97706'
                    : '#0D9488',
                weight: road.markedImpassableByRule ? 4.5 : 3.5,
                dashArray: road.markedImpassableByRule ? '6 6' : undefined,
                opacity: 0.95,
              }}
              eventHandlers={{
                click: () => onSelectObject({ kind: 'road', data: road }),
              }}
            >
              <Popup>
                <div className="text-xs space-y-1 min-w-[225px] font-mono text-slate-800">
                  <div className="font-sans font-semibold text-slate-900 border-b border-slate-200 pb-1">
                    {road.name}
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Highway Class:</span>
                    <span>{road.highwayClass}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Exposure:</span>
                    <span className={road.exposed ? 'text-amber-700 font-semibold' : 'text-teal-700'}>
                      {road.exposed
                        ? `EXPOSED (${road.intersectingCandidateUnits} candidate blocks)`
                        : 'Not Exposed'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Graph Assumption:</span>
                    <span
                      className={
                        road.markedImpassableByRule ? 'text-rose-600 font-semibold' : 'text-teal-700'
                      }
                    >
                      {road.markedImpassableByRule ? 'Assumed Impassable' : 'Assumed Passable'}
                    </span>
                  </div>
                  <div className="text-[10px] text-slate-500 pt-1">{road.ruleReason}</div>
                </div>
              </Popup>
            </Polyline>
          ))}

        {/* 7. Pre-Event OSM Bridges */}
        {layers.osmBridges &&
          infraSummary.bridges.map((br) => (
            <CircleMarker
              key={br.id}
              center={[br.lat, br.lng]}
              radius={6.5}
              pathOptions={{
                color: br.exposed ? '#B45309' : '#1D4ED8',
                weight: 2,
                fillColor: br.exposed ? '#F59E0B' : '#2563EB',
                fillOpacity: 0.95,
              }}
              eventHandlers={{
                click: () => onSelectObject({ kind: 'bridge', data: br }),
              }}
            >
              <Popup>
                <div className="text-xs space-y-1 min-w-[210px] font-mono text-slate-800">
                  <div className="font-sans font-semibold text-slate-900 border-b border-slate-200 pb-1">
                    {br.name}
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Exposure:</span>
                    <span className={br.exposed ? 'text-amber-700 font-semibold' : 'text-teal-700'}>
                      {br.exposed ? 'EXPOSED' : 'Not Exposed'}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Provenance:</span>
                    <span>{br.provenanceStatus}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 pt-1">{br.exposureBasis}</div>
                </div>
              </Popup>
            </CircleMarker>
          ))}

        {/* 8 & 9. Settlements, Towns, and Hospitals */}
        {infraSummary.settlements.map((node) => {
          const isHospOrTown = node.placeType === 'hospital' || node.placeType === 'town';
          if (isHospOrTown && !layers.osmHospitalsAndTowns) return null;
          if (!isHospOrTown && !layers.osmSettlements) return null;

          const isCutOff = node.isolationStatus === 'CANDIDATE_CUT_OFF';
          const color =
            node.placeType === 'hospital'
              ? '#2563EB'
              : node.placeType === 'town'
                ? '#7C3AED'
                : isCutOff
                  ? '#DC2626'
                  : '#0D9488';

          return (
            <CircleMarker
              key={node.id}
              center={[node.lat, node.lng]}
              radius={isCutOff ? 8.5 : 7}
              pathOptions={{
                color: '#FFFFFF',
                weight: 2,
                fillColor: color,
                fillOpacity: 0.95,
              }}
              eventHandlers={{
                click: () => onSelectObject({ kind: 'settlement', data: node }),
              }}
            >
              <Tooltip direction="top" offset={[0, -6]} permanent>
                <span className="font-mono text-[10px] font-semibold text-slate-900">
                  {node.placeType === 'hospital'
                    ? `[H] ${node.name}`
                    : node.placeType === 'town'
                      ? `[TOWN] ${node.name}`
                      : isCutOff
                        ? `✖ ${node.name} (CANDIDATE CUT OFF)`
                        : `● ${node.name}`}
                </span>
              </Tooltip>
              <Popup>
                <div className="text-xs space-y-1 min-w-[225px] font-mono text-slate-800">
                  <div className="font-sans font-semibold text-slate-900 border-b border-slate-200 pb-1">
                    {node.name}
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Graph Status:</span>
                    <span className={isCutOff ? 'text-rose-600 font-semibold' : 'text-teal-700'}>
                      {node.isolationStatus}
                    </span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Provenance:</span>
                    <span>{node.provenanceStatus}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Nearest Town:</span>
                    <span>{node.nearestTownName || 'not assessed'}</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-slate-500">Nearest Hospital:</span>
                    <span>{node.nearestHospitalName || 'not assessed'}</span>
                  </div>
                  <div className="text-[10px] text-slate-500 pt-1">{node.assumptionNote}</div>
                </div>
              </Popup>
            </CircleMarker>
          );
        })}

        {/* 10. Ground-Truth Flood Mask (Kuro Siwo Reference — Strictly distinguished from predictions) */}
        {layers.groundTruthFloodMask && (
          <>
            <Polygon
              positions={[
                [28.205, 85.321],
                [28.212, 85.327],
                [28.221, 85.331],
                [28.228, 85.333],
                [28.232, 85.338],
                [28.231, 85.342],
                [28.225, 85.339],
                [28.218, 85.335],
                [28.209, 85.33],
                [28.203, 85.324],
                [28.205, 85.321],
              ]}
              pathOptions={{
                color: '#9333EA',
                weight: 2.5,
                dashArray: '4 4',
                fillColor: '#A855F7',
                fillOpacity: 0.35,
              }}
            >
              <Popup>
                <div className="text-xs space-y-1 min-w-[220px] font-mono text-slate-800">
                  <div className="font-sans font-semibold text-purple-900 border-b border-purple-200 pb-1">
                    Kuro Siwo Ground-Truth Flood Label
                  </div>
                  <div>Source: Kuro Siwo Reference Annotations Protocol</div>
                  <div>Classification: Verified Inundation (Ground Truth)</div>
                  <div className="text-[10px] text-amber-800 pt-1">
                    Strictly isolated reference layer. Never used as input feature in change detection or model prediction.
                  </div>
                </div>
              </Popup>
            </Polygon>
            <Polygon
              positions={[
                [28.215, 85.328],
                [28.216, 85.332],
                [28.214, 85.335],
                [28.211, 85.333],
                [28.212, 85.329],
                [28.215, 85.328],
              ]}
              pathOptions={{
                color: '#9333EA',
                weight: 2.5,
                dashArray: '4 4',
                fillColor: '#A855F7',
                fillOpacity: 0.35,
              }}
            >
              <Popup>
                <div className="text-xs space-y-1 min-w-[220px] font-mono text-slate-800">
                  <div className="font-sans font-semibold text-purple-900 border-b border-purple-200 pb-1">
                    Kuro Siwo Ground-Truth Flood Label (Secondary Basin)
                  </div>
                  <div>Source: Kuro Siwo Reference Annotations Protocol</div>
                  <div>Classification: Verified Inundation (Ground Truth)</div>
                </div>
              </Popup>
            </Polygon>
          </>
        )}
      </MapContainer>

      {/* Map Controls: Symbology Legend & Download GeoJSON Toggle Buttons */}
      <div className="absolute top-3 left-13 z-[400] flex flex-wrap items-center gap-2">
        <button
          type="button"
          onClick={() => setIsLegendOpen((prev) => !prev)}
          aria-expanded={isLegendOpen}
          aria-controls="terraresq-interactive-legend"
          className={`px-3 py-1.5 rounded-md border text-xs font-mono font-semibold shadow-md transition-colors flex items-center gap-1.5 cursor-pointer ${
            isLegendOpen
              ? 'bg-teal-500 text-slate-950 border-teal-400 hover:bg-teal-400'
              : 'bg-[#0F172A] text-slate-100 border-[#1E293B] hover:bg-[#1E293B] hover:text-teal-300'
          }`}
        >
          <span>{isLegendOpen ? '▼' : '◈'}</span>
          <span>{isLegendOpen ? 'Close Symbology Legend' : 'Symbology Legend'}</span>
        </button>

        {isLegendOpen && (
          <button
            type="button"
            onClick={() =>
              setLegendViewMode((prev) => (prev === 'MODAL' ? 'OVERLAY' : 'MODAL'))
            }
            className="px-2.5 py-1.5 rounded-md border border-[#1E293B] bg-[#0F172A] hover:bg-[#1E293B] text-slate-200 text-[11px] font-mono shadow-md transition-colors cursor-pointer"
          >
            View: {legendViewMode === 'MODAL' ? 'Modal Dialog' : 'Corner Overlay'}
          </button>
        )}

        {/* Download GeoJSON Button */}
        <button
          type="button"
          onClick={() => {
            setIsGeoJsonModalOpen(true);
            setDownloadNotification(null);
          }}
          aria-expanded={isGeoJsonModalOpen}
          aria-controls="terraresq-geojson-export-modal"
          className={`px-3 py-1.5 rounded-md border text-xs font-mono font-semibold shadow-md transition-colors flex items-center gap-1.5 cursor-pointer ${
            isGeoJsonModalOpen
              ? 'bg-emerald-500 text-slate-950 border-emerald-400 hover:bg-emerald-400'
              : 'bg-[#0F172A] text-slate-100 border-[#1E293B] hover:bg-[#1E293B] hover:text-emerald-300'
          }`}
          title="Export current flood candidate mask and impassable road segments for external GIS processing (RFC 7946 GeoJSON)"
        >
          <span className="text-emerald-400 font-bold">⤓</span>
          <span>Download GeoJSON</span>
          {totalExportableFeatures > 0 && (
            <span className="ml-0.5 px-1.5 py-0.2 rounded text-[10px] bg-emerald-950 border border-emerald-500/40 text-emerald-300 font-bold">
              {totalExportableFeatures}
            </span>
          )}
        </button>

        {/* Quick 1-Click Export when features are available */}
        {totalExportableFeatures > 0 && !isGeoJsonModalOpen && (
          <button
            type="button"
            onClick={() => handleDownloadGeoJson('COMBINED')}
            className="hidden sm:inline-flex px-2 py-1.5 rounded-md border border-emerald-800/60 bg-emerald-950/70 hover:bg-emerald-900 text-emerald-300 text-[11px] font-mono shadow-md transition-colors items-center gap-1 cursor-pointer"
            title="Immediate 1-Click download of combined GeoJSON file"
          >
            <span>⚡ Quick Save</span>
          </button>
        )}
      </div>

      {/* Download Status Toast */}
      {downloadNotification && (
        <div className="absolute top-14 left-13 z-[450] bg-[#064E3B]/95 border border-emerald-500/80 text-emerald-100 px-3.5 py-2 rounded-md shadow-2xl text-xs font-mono flex items-center gap-2 max-w-lg">
          <span className="text-emerald-300 font-bold text-sm">✓</span>
          <span className="flex-1 text-[11px] leading-snug">{downloadNotification}</span>
          <button
            type="button"
            onClick={() => setDownloadNotification(null)}
            className="text-emerald-300 hover:text-white text-xs ml-1 font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>
      )}

      {/* Interactive Map Legend Component (Layer Visibility Status, Colors, & Live Counts) */}
      <InteractiveMapLegend
        layers={layers}
        onToggleLayer={onToggleLayer || (() => {})}
        maskResult={maskResult}
        infraSummary={infraSummary}
        studyArea={studyArea}
        onSelectObject={onSelectObject}
        onOpenExportGeoJson={() => {
          setIsGeoJsonModalOpen(true);
          setDownloadNotification(null);
        }}
        defaultExpanded={false}
      />

      {/* Dark-Themed Responsive Grid Legend Modal / Overlay */}
      {isLegendOpen && (
        <div
          id="terraresq-interactive-legend"
          role="dialog"
          aria-modal={legendViewMode === 'MODAL'}
          aria-label="Interactive Map Symbology & Provenance Legend"
          className={
            legendViewMode === 'MODAL'
              ? 'absolute inset-0 z-[500] bg-slate-950/65 backdrop-blur-xs flex items-center justify-center p-4'
              : 'absolute bottom-3 left-3 z-[500] w-[360px] sm:w-[500px] max-h-[450px] flex flex-col'
          }
          onClick={(e) => {
            if (legendViewMode === 'MODAL' && e.target === e.currentTarget) {
              setIsLegendOpen(false);
            }
          }}
        >
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-md shadow-2xl w-full max-w-3xl max-h-[480px] flex flex-col overflow-hidden text-xs font-mono text-slate-200">
            {/* Dark Modal Header */}
            <div className="px-4 py-3 bg-[#0B0E17] border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-[10px] font-bold text-teal-400 uppercase tracking-wider">
                  MAP CONTROL SYMBOLOGY & PROVENANCE
                </div>
                <h3 className="text-sm font-sans font-bold text-slate-100">
                  Layer Symbology Legend (Flood Candidates, Roads, Settlements & Hospitals)
                </h3>
              </div>

              <div className="flex items-center gap-1.5">
                <button
                  type="button"
                  onClick={() =>
                    setLegendViewMode((prev) => (prev === 'MODAL' ? 'OVERLAY' : 'MODAL'))
                  }
                  className="px-2.5 py-1 rounded border border-[#1E293B] bg-[#111827] hover:bg-[#1E293B] text-[10px] text-slate-300 font-semibold cursor-pointer"
                >
                  {legendViewMode === 'MODAL' ? 'Dock Overlay' : 'Expand Modal'}
                </button>
                <button
                  type="button"
                  onClick={() => setIsLegendOpen(false)}
                  className="px-2.5 py-1 rounded bg-[#1E293B] hover:bg-slate-700 text-slate-100 border border-slate-700 text-[11px] font-semibold cursor-pointer"
                  aria-label="Close Symbology Legend"
                >
                  Close ✕
                </button>
              </div>
            </div>

            {/* Category Filter & Direct Layer Toggle Strip */}
            <div className="px-4 py-2 bg-[#111827] border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <div className="flex flex-wrap items-center gap-1.5">
                {(
                  [
                    { id: 'ALL', label: 'All Entries' },
                    { id: 'FLOOD_CANDIDATES', label: 'Flood Candidates' },
                    { id: 'ROADS', label: 'Roads & Bridges' },
                    { id: 'SETTLEMENTS', label: 'Settlements' },
                    { id: 'HOSPITALS', label: 'Hospitals & Towns' },
                  ] as { id: LegendCategoryFilter; label: string }[]
                ).map((tab) => (
                  <button
                    key={tab.id}
                    type="button"
                    onClick={() => setLegendCategory(tab.id)}
                    className={`px-2.5 py-1 rounded border transition-colors cursor-pointer ${
                      legendCategory === tab.id
                        ? 'bg-teal-500 text-slate-950 border-teal-400 font-semibold'
                        : 'bg-[#0F172A] text-slate-300 border-[#1E293B] hover:bg-[#1E293B]'
                    }`}
                  >
                    {tab.label}
                  </button>
                ))}
              </div>

              <span className="text-[10px] text-slate-400">
                Status: <strong className="text-amber-300">{infraSummary.status}</strong>
              </span>
            </div>

            {/* Responsive Grid Layout of Symbology Swatch Cards */}
            <div className="p-4 overflow-y-auto">
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3">
                {/* 1. Flood Candidate (Water-Candidate Mask) */}
                {(legendCategory === 'ALL' || legendCategory === 'FLOOD_CANDIDATES') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Flood Candidate Mask Swatch"
                        className="w-4 h-4 rounded-xs bg-cyan-400/85 border border-[#0D9488] shrink-0 mt-0.5 shadow-xs"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Flood Candidate
                        </div>
                        <div className="text-[10px] text-teal-300 mt-0.5">
                          Low-backscatter drop (≤ {maskResult ? maskResult.thresholdDb : -17} dB)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Sentinel-1 SAR water-candidate raster mask (<em>baseline only, not AI</em>).
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-slate-400">
                        {maskResult
                          ? `${maskResult.newCandidatePixels.toLocaleString()} px`
                          : 'not assessed'}
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('waterCandidateMask')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.waterCandidateMask
                              ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.waterCandidateMask ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 2. Study Area AOI Boundary */}
                {(legendCategory === 'ALL' || legendCategory === 'FLOOD_CANDIDATES') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Study Area AOI Swatch"
                        className="w-4 h-4 rounded-xs border-2 border-dashed border-[#0D9488] bg-[#0D9488]/10 shrink-0 mt-0.5"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Study Area AOI
                        </div>
                        <div className="text-[10px] text-teal-300 mt-0.5">
                          Dashed Corridor Boundary
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Target bounding box for STAC scene discovery and raster co-registration.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px] text-slate-400">
                      <span className="truncate">BBox: [{studyArea.bbox.join(', ')}]</span>
                    </div>
                  </div>
                )}

                {/* 3. Passable Road (Pre-Event OSM) */}
                {(legendCategory === 'ALL' || legendCategory === 'ROADS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Passable Road Swatch"
                        className="w-4 h-1.5 rounded-xs bg-[#0D9488] shrink-0 mt-1.5"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Passable Road
                        </div>
                        <div className="text-[10px] text-teal-300 mt-0.5">
                          Solid Teal Line (#0D9488)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Dated pre-event OSM road segment without candidate water overlap; open in graph.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-slate-400">
                        {infraSummary.roads.length > 0 ? `${passableRoadsCount} segments` : 'not assessed'}
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('osmRoads')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.osmRoads
                              ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.osmRoads ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 4. Exposed Road (Pre-Event OSM) */}
                {(legendCategory === 'ALL' || legendCategory === 'ROADS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Exposed Road Swatch"
                        className="w-4 h-1.5 rounded-xs bg-[#D97706] shrink-0 mt-1.5"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Exposed Road
                        </div>
                        <div className="text-[10px] text-amber-300 mt-0.5">
                          Solid Amber Line (#D97706)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Intersects flood candidate. Indicates exposure, not confirmed structural damage.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px] text-amber-300">
                      <span>
                        {infraSummary.roads.length > 0 ? `${exposedRoadsCount} segments` : 'not assessed'}
                      </span>
                    </div>
                  </div>
                )}

                {/* 5. Assumed Impassable Road */}
                {(legendCategory === 'ALL' || legendCategory === 'ROADS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Assumed Impassable Road Swatch"
                        className="w-4 h-0 border-t-3 border-dashed border-[#DC2626] shrink-0 mt-2"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Impassable Road
                        </div>
                        <div className="text-[10px] text-rose-400 mt-0.5">
                          Dashed Red Line (#DC2626)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Blocked in routing graph by active impassability rule or manual override.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-rose-400">
                        {infraSummary.roads.length > 0 ? `${impassableRoadsCount} segments` : 'not assessed'}
                      </span>
                      {infraSummary.roads.some((r) => r.markedImpassableByRule) && (
                        <button
                          type="button"
                          onClick={() => {
                            const sample = infraSummary.roads.find((r) => r.markedImpassableByRule);
                            if (sample) onSelectObject({ kind: 'road', data: sample });
                          }}
                          className="text-teal-300 underline cursor-pointer"
                        >
                          Inspect →
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 6. Bridges (Unexposed vs Exposed) */}
                {(legendCategory === 'ALL' || legendCategory === 'ROADS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span className="inline-flex items-center gap-1 shrink-0 mt-1">
                        <span
                          title="Unexposed Bridge Swatch"
                          className="w-3 h-3 rounded-full bg-[#2563EB] border-2 border-[#1D4ED8]"
                        />
                        <span
                          title="Exposed Bridge Swatch"
                          className="w-3 h-3 rounded-full bg-[#F59E0B] border-2 border-[#B45309]"
                        />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          OSM Bridges
                        </div>
                        <div className="text-[10px] text-sky-300 mt-0.5">
                          Blue (Clear) · Amber (Exposed)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Pre-event river bridge crossings evaluated against water-candidate mask.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-slate-400">
                        {infraSummary.bridges.length > 0
                          ? `${infraSummary.exposedBridgesCount ?? 0}/${infraSummary.totalBridgesCount} exposed`
                          : 'not assessed'}
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('osmBridges')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.osmBridges
                              ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.osmBridges ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 7. Reachable Settlement */}
                {(legendCategory === 'ALL' || legendCategory === 'SETTLEMENTS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Reachable Settlement Swatch"
                        className="w-3.5 h-3.5 rounded-full bg-[#0D9488] border-2 border-white shrink-0 mt-0.5 shadow-xs"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Reachable Settlement
                        </div>
                        <div className="text-[10px] text-teal-300 mt-0.5">
                          Teal Circle Marker (● #0D9488)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Settlement node with a passable graph path to a town or hospital.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-teal-300">
                        {villageNodes.length > 0 ? `${reachableVillagesCount} reachable` : 'not assessed'}
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('osmSettlements')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.osmSettlements
                              ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.osmSettlements ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 8. Candidate Cut-Off Settlement */}
                {(legendCategory === 'ALL' || legendCategory === 'SETTLEMENTS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Candidate Cut-Off Settlement Swatch"
                        className="w-4 h-4 rounded-full bg-[#DC2626] border-2 border-white shrink-0 mt-0.5 shadow-xs"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Cut-Off Settlement
                        </div>
                        <div className="text-[10px] text-rose-400 mt-0.5">
                          Red Circle Marker (✖ #DC2626)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Candidate isolated settlement with all road routes to town/hospital blocked.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-rose-400">
                        {villageNodes.length > 0 ? `${cutOffVillagesCount} cut off` : 'not assessed'}
                      </span>
                      {villageNodes.some((s) => s.isolationStatus === 'CANDIDATE_CUT_OFF') && (
                        <button
                          type="button"
                          onClick={() => {
                            const sample = villageNodes.find(
                              (s) => s.isolationStatus === 'CANDIDATE_CUT_OFF'
                            );
                            if (sample) onSelectObject({ kind: 'settlement', data: sample });
                          }}
                          className="text-teal-300 underline cursor-pointer"
                        >
                          Inspect →
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 9. OSM Building Footprints */}
                {(legendCategory === 'ALL' || legendCategory === 'SETTLEMENTS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span className="inline-flex items-center gap-1 shrink-0 mt-1">
                        <span
                          title="Unexposed Building Swatch"
                          className="w-3 h-3 rounded-xs bg-[#64748B] border border-[#475569]"
                        />
                        <span
                          title="Exposed Building Swatch"
                          className="w-3 h-3 rounded-xs bg-[#F59E0B] border border-[#D97706]"
                        />
                      </span>
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Building Footprints
                        </div>
                        <div className="text-[10px] text-amber-300 mt-0.5">
                          Slate (Clear) · Amber (Exposed)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Pre-event OSM building polygons intersecting water-candidate pixels.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-slate-400">
                        {infraSummary.buildings.length > 0
                          ? `${infraSummary.exposedBuildingsCount ?? 0}/${infraSummary.totalBuildingsCount} exposed`
                          : 'not assessed'}
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('osmBuildings')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.osmBuildings
                              ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.osmBuildings ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 10. Hospital / Medical Center [H] */}
                {(legendCategory === 'ALL' || legendCategory === 'HOSPITALS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Hospital Marker Swatch"
                        className="w-3.5 h-3.5 rounded-full bg-[#2563EB] border-2 border-white shrink-0 mt-0.5 shadow-xs"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Hospital [H]
                        </div>
                        <div className="text-[10px] text-blue-400 mt-0.5">
                          Cobalt Blue Marker (#2563EB)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Emergency medical facility node used for shortest-path hospital reachability.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-blue-400">
                        {hospitalNodes.length > 0 ? `${hospitalNodes.length} hospital(s)` : 'not assessed'}
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('osmHospitalsAndTowns')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.osmHospitalsAndTowns
                              ? 'bg-teal-500/20 text-teal-300 border-teal-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.osmHospitalsAndTowns ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 11. Town / Regional Supply Hub [TOWN] */}
                {(legendCategory === 'ALL' || legendCategory === 'HOSPITALS') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Town Marker Swatch"
                        className="w-3.5 h-3.5 rounded-full bg-[#7C3AED] border-2 border-white shrink-0 mt-0.5 shadow-xs"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Town Hub [TOWN]
                        </div>
                        <div className="text-[10px] text-purple-400 mt-0.5">
                          Violet Circle Marker (#7C3AED)
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Regional supply or administrative town center in the road network graph.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-purple-400">
                        {townNodes.length > 0 ? `${townNodes.length} town(s)` : 'not assessed'}
                      </span>
                      {townNodes.length > 0 && (
                        <button
                          type="button"
                          onClick={() => onSelectObject({ kind: 'settlement', data: townNodes[0] })}
                          className="text-teal-300 underline cursor-pointer"
                        >
                          Inspect →
                        </button>
                      )}
                    </div>
                  </div>
                )}

                {/* 12. Ground-Truth Flood Mask (Kuro Siwo Reference) */}
                {(legendCategory === 'ALL' || legendCategory === 'FLOOD_CANDIDATES') && (
                  <div className="bg-[#111827] border border-[#1E293B] rounded-md p-3 flex flex-col justify-between gap-2">
                    <div className="flex items-start gap-2.5">
                      <span
                        title="Ground-Truth Mask Swatch"
                        className="w-4 h-4 rounded-xs border-2 border-dashed border-[#9333EA] bg-[#A855F7]/40 shrink-0 mt-0.5 shadow-xs"
                      />
                      <div className="min-w-0 flex-1">
                        <div className="font-sans font-semibold text-slate-100 text-xs">
                          Ground-Truth Labels
                        </div>
                        <div className="text-[10px] text-purple-300 mt-0.5">
                          Dashed Purple (#9333EA) · Kuro Siwo
                        </div>
                        <p className="font-sans text-[11px] text-slate-400 mt-1 leading-snug">
                          Reference flood boundary labels. Strictly isolated from model predictions.
                        </p>
                      </div>
                    </div>
                    <div className="flex items-center justify-between pt-2 border-t border-slate-800/80 text-[10px]">
                      <span className="text-purple-300">
                        Reference Polygon (1.44 km²)
                      </span>
                      {onToggleLayer && (
                        <button
                          type="button"
                          onClick={() => onToggleLayer('groundTruthFloodMask')}
                          className={`px-2 py-0.5 rounded border cursor-pointer ${
                            layers.groundTruthFloodMask
                              ? 'bg-purple-500/20 text-purple-300 border-purple-500/40'
                              : 'bg-slate-800 text-slate-400 border-slate-700'
                          }`}
                        >
                          {layers.groundTruthFloodMask ? 'Visible' : 'Hidden'}
                        </button>
                      )}
                    </div>
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Dark-Themed Responsive GeoJSON Export Modal for External GIS Processing */}
      {isGeoJsonModalOpen && (
        <div
          id="terraresq-geojson-export-modal"
          role="dialog"
          aria-modal="true"
          aria-label="Export Flooded Area Mask and Impassable Road Segments to GeoJSON"
          className="absolute inset-0 z-[500] bg-slate-950/70 backdrop-blur-xs flex items-center justify-center p-3 sm:p-4 overflow-y-auto"
          onClick={(e) => {
            if (e.target === e.currentTarget) {
              setIsGeoJsonModalOpen(false);
            }
          }}
        >
          <div className="bg-[#0F172A] border border-[#1E293B] rounded-lg shadow-2xl w-full max-w-3xl max-h-[92vh] flex flex-col overflow-hidden text-xs font-mono text-slate-200">
            {/* Modal Header */}
            <div className="px-4 py-3 bg-[#0B0E17] border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2">
              <div>
                <div className="text-[10px] font-bold text-emerald-400 uppercase tracking-wider flex items-center gap-1.5">
                  <span>EXTERNAL GIS INTEROPERABILITY</span>
                  <span className="px-1.5 py-0.2 bg-emerald-950/80 border border-emerald-500/40 rounded text-[9px] text-emerald-300">
                    RFC 7946 GeoJSON Standard
                  </span>
                </div>
                <h3 className="text-sm font-sans font-bold text-slate-100 mt-0.5">
                  Export Flooded Area Candidate Mask & Impassable Road Segments
                </h3>
              </div>
              <button
                type="button"
                onClick={() => setIsGeoJsonModalOpen(false)}
                className="px-2.5 py-1 rounded bg-[#1E293B] hover:bg-slate-700 text-slate-100 border border-slate-700 text-[11px] font-semibold cursor-pointer"
                aria-label="Close Export Dialog"
              >
                Close ✕
              </button>
            </div>

            {/* Scope Selection Bar */}
            <div className="px-4 py-2.5 bg-[#111827] border-b border-[#1E293B] flex flex-wrap items-center justify-between gap-2 text-[11px]">
              <span className="text-slate-400 font-sans">Export Scope:</span>
              <div className="flex flex-wrap items-center gap-1.5">
                <button
                  type="button"
                  onClick={() => setGeoJsonScope('COMBINED')}
                  className={`px-2.5 py-1 rounded border transition-colors cursor-pointer flex items-center gap-1.5 ${
                    geoJsonScope === 'COMBINED'
                      ? 'bg-emerald-500 text-slate-950 border-emerald-400 font-semibold'
                      : 'bg-[#0F172A] text-slate-300 border-[#1E293B] hover:bg-[#1E293B]'
                  }`}
                >
                  <span>Combined (Mask + Roads)</span>
                  <span className="text-[10px] opacity-80 font-bold">
                    ({totalExportableFeatures})
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setGeoJsonScope('FLOOD_MASK_ONLY')}
                  className={`px-2.5 py-1 rounded border transition-colors cursor-pointer flex items-center gap-1.5 ${
                    geoJsonScope === 'FLOOD_MASK_ONLY'
                      ? 'bg-cyan-500 text-slate-950 border-cyan-400 font-semibold'
                      : 'bg-[#0F172A] text-slate-300 border-[#1E293B] hover:bg-[#1E293B]'
                  }`}
                >
                  <span>Flood Mask Only</span>
                  <span className="text-[10px] opacity-80 font-bold">
                    ({floodCandidatePolygonsCount})
                  </span>
                </button>
                <button
                  type="button"
                  onClick={() => setGeoJsonScope('IMPASSABLE_ROADS_ONLY')}
                  className={`px-2.5 py-1 rounded border transition-colors cursor-pointer flex items-center gap-1.5 ${
                    geoJsonScope === 'IMPASSABLE_ROADS_ONLY'
                      ? 'bg-rose-500 text-slate-950 border-rose-400 font-semibold'
                      : 'bg-[#0F172A] text-slate-300 border-[#1E293B] hover:bg-[#1E293B]'
                  }`}
                >
                  <span>Impassable Roads Only</span>
                  <span className="text-[10px] opacity-80 font-bold">
                    ({impassableRoadsCount})
                  </span>
                </button>
              </div>
            </div>

            {/* Content Body */}
            <div className="p-4 overflow-y-auto space-y-3.5">
              {/* Feature Stats Grid */}
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5">
                <div className="bg-[#111827] border border-[#1E293B] rounded p-2.5">
                  <div className="text-[10px] text-cyan-400 uppercase font-semibold">Flood Mask</div>
                  <div className="text-sm font-bold text-slate-100 mt-0.5">
                    {floodCandidatePolygonsCount > 0 ? `${floodCandidatePolygonsCount} Polygons` : '0 Polygons'}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    {maskResult?.newCandidateAreaSqKm != null
                      ? `~${maskResult.newCandidateAreaSqKm} km² est. flood area`
                      : 'Area uncalculated'}
                  </div>
                </div>

                <div className="bg-[#111827] border border-[#1E293B] rounded p-2.5">
                  <div className="text-[10px] text-rose-400 uppercase font-semibold">Impassable Roads</div>
                  <div className="text-sm font-bold text-slate-100 mt-0.5">
                    {impassableRoadsCount > 0 ? `${impassableRoadsCount} Segments` : '0 Segments'}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    {currentExportSummary.impassableRoadLengthKm > 0
                      ? `${currentExportSummary.impassableRoadLengthKm} km total length`
                      : 'No impassable roads'}
                  </div>
                </div>

                <div className="bg-[#111827] border border-[#1E293B] rounded p-2.5">
                  <div className="text-[10px] text-emerald-400 uppercase font-semibold">Spatial Coordinate Ref</div>
                  <div className="text-xs font-bold text-slate-100 mt-0.5">WGS84 (EPSG:4326)</div>
                  <div className="text-[10px] text-slate-400 mt-1">
                    [Longitude, Latitude] per RFC 7946
                  </div>
                </div>

                <div className="bg-[#111827] border border-[#1E293B] rounded p-2.5">
                  <div className="text-[10px] text-amber-400 uppercase font-semibold">Data Provenance</div>
                  <div className="text-xs font-bold text-slate-100 mt-0.5 capitalize">
                    {maskResult?.sourceStatus || infraSummary.status}
                  </div>
                  <div className="text-[10px] text-slate-400 mt-1 truncate">
                    {studyArea.areaName} ({studyArea.eventDate})
                  </div>
                </div>
              </div>

              {/* Informative Guidance if 0 Features */}
              {totalExportableFeatures === 0 && (
                <div className="bg-amber-950/40 border border-amber-600/40 rounded p-3 text-amber-200 text-xs">
                  <div className="font-semibold flex items-center gap-1.5 text-amber-300">
                    <span>⚠ No flood candidate mask or impassable road features currently loaded</span>
                  </div>
                  <p className="mt-1 text-[11px] text-amber-200/90 font-sans leading-relaxed">
                    Click <strong>Run Analysis</strong> or load the <strong>Trishuli Case Study / Synthetic Demo</strong> in the workbench above to calculate the SAR low-backscatter difference mask and identify road network graph impassabilities. You can still export an empty GeoJSON template below.
                  </p>
                </div>
              )}

              {/* GIS Software Compatibility Info */}
              <div className="bg-[#111827] border border-[#1E293B] rounded p-3 flex flex-col sm:flex-row items-start sm:items-center justify-between gap-2 text-[11px]">
                <div className="space-y-0.5">
                  <span className="font-sans font-semibold text-slate-200">
                    GIS Software Compatibility:
                  </span>
                  <p className="font-sans text-slate-400 text-[11px]">
                    Directly importable into QGIS, ArcGIS Pro, Google Earth Engine, GeoPandas, GDAL/OGR, Mapbox Studio, and PostGIS.
                  </p>
                </div>
                <div className="flex items-center gap-1.5 shrink-0">
                  <span className="px-2 py-0.5 bg-slate-800 rounded border border-slate-700 text-slate-300 text-[10px]">
                    QGIS
                  </span>
                  <span className="px-2 py-0.5 bg-slate-800 rounded border border-slate-700 text-slate-300 text-[10px]">
                    ArcGIS
                  </span>
                  <span className="px-2 py-0.5 bg-slate-800 rounded border border-slate-700 text-slate-300 text-[10px]">
                    GDAL
                  </span>
                </div>
              </div>

              {/* Live GeoJSON Code Snippet Preview */}
              <div>
                <div className="flex items-center justify-between text-[11px] mb-1.5 text-slate-400">
                  <span>GeoJSON FeatureCollection Preview:</span>
                  <span className="text-[10px] text-teal-400">
                    Scope: {geoJsonScope} ({currentExportSummary.totalFeatures} features)
                  </span>
                </div>
                <pre className="bg-[#090D16] border border-[#1E293B] rounded p-3 text-[11px] leading-relaxed text-teal-300 overflow-x-auto max-h-[160px] font-mono select-all">
                  {sampleGeoJsonPreview}
                </pre>
              </div>
            </div>

            {/* Modal Footer with Action Buttons */}
            <div className="px-4 py-3 bg-[#0B0E17] border-t border-[#1E293B] flex flex-wrap items-center justify-between gap-3">
              <div className="text-[11px] text-slate-400">
                <span>Selected: </span>
                <strong className="text-slate-200 font-mono">
                  {currentExportSummary.totalFeatures} feature(s)
                </strong>
                <span className="hidden sm:inline"> ({currentExportSummary.floodPolygonCount} mask polygons, {currentExportSummary.impassableRoadCount} impassable roads)</span>
              </div>

              <div className="flex items-center gap-2">
                <button
                  type="button"
                  onClick={handleCopyGeoJson}
                  className="px-3 py-1.5 rounded border border-[#1E293B] bg-[#111827] hover:bg-[#1E293B] text-slate-200 text-xs font-semibold cursor-pointer transition-colors"
                >
                  {isCopied ? '✓ Copied to Clipboard!' : 'Copy GeoJSON'}
                </button>

                <button
                  type="button"
                  onClick={() => handleDownloadGeoJson(geoJsonScope)}
                  className="px-4 py-1.5 rounded border border-emerald-400 bg-emerald-500 hover:bg-emerald-400 text-slate-950 font-bold text-xs flex items-center gap-1.5 cursor-pointer shadow-lg transition-colors"
                >
                  <span className="font-bold">⤓</span>
                  <span>Download .geojson</span>
                </button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
