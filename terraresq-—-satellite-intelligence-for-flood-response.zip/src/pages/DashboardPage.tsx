export { default as DashboardPage } from '../App';
