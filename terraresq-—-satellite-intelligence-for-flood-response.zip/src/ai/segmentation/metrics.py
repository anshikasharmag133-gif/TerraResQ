"""
TerraResQ — Flood Segmentation Evaluation Metrics
Computes standard binary/multi-class spatial accuracy metrics:
- Intersection over Union (IoU / Jaccard Index)
- F1 Score (Dice Coefficient)
- Precision (Positive Predictive Value)
- Recall (Sensitivity / True Positive Rate)

Note: Validation against external reference datasets (such as EMSR927) is strictly
performed post-inference in the Validation Reference module and never used as a model input.
"""

from typing import Dict


def compute_confusion_metrics(
    true_positives: int,
    false_positives: int,
    false_negatives: int,
    true_negatives: int = 0,
    eps: float = 1e-7,
) -> Dict[str, float]:
    """
    Calculate IoU, F1 Score, Precision, and Recall from pixel-level confusion counts.
    """
    tp = float(true_positives)
    fp = float(false_positives)
    fn = float(false_negatives)

    precision = tp / (tp + fp + eps)
    recall = tp / (tp + fn + eps)
    f1_score = (2.0 * precision * recall) / (precision + recall + eps)
    iou = tp / (tp + fp + fn + eps)

    return {
        "iou": round(iou, 4),
        "f1_score": round(f1_score, 4),
        "precision": round(precision, 4),
        "recall": round(recall, 4),
    }


def classify_confidence_tier(mean_probability: float, iou_score: float) -> str:
    """
    Classify inference confidence tier into High / Medium / Low based on
    posterior probability calibration and validation IoU.
    """
    combined = 0.6 * mean_probability + 0.4 * iou_score
    if combined >= 0.78:
        return "High"
    if combined >= 0.58:
        return "Medium"
    return "Low"
