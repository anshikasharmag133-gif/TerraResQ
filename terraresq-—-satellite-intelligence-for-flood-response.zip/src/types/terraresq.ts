import {
  DataProvenanceStatus,
  ParsedGeoTiffRaster,
  RasterValidationResult,
  WaterCandidateMaskResult,
} from '../services/geotiffProcessor';

export type {
  DataProvenanceStatus,
  ParsedGeoTiffRaster,
  RasterValidationResult,
  WaterCandidateMaskResult,
};

export type WorkspaceMode = 'CASE_STUDY_TRISHULI' | 'CUSTOM_AOI' | 'SYNTHETIC_DEMO';

export interface OpticalSatelliteImage {
  id: string;
  fileName: string;
  sensorType: 'SENTINEL_2_OPTICAL';
  role: 'PRE_EVENT' | 'POST_EVENT';
  acquisitionDate: string;
  sourceStatus: 'uploaded' | 'synthetic demo';
  width: number;
  height: number;
  spatialResolutionM: number;
  bandsDescription: string;
  crsCode: number | null;
  dataUrl: string;
  meanReflectance: number;
  cloudCoverPercent: number;
  fileSizeBytes: number;
}

export interface StudyAreaConfig {
  mode: WorkspaceMode;
  areaName: string;
  eventDate: string;
  preEventWindowStart: string;
  bbox: [number, number, number, number]; // [west, south, east, north]
  center: [number, number]; // [lat, lng]
  zoom: number;
}

export interface OsmSettlementNode {
  id: string;
  osmId: string;
  name: string;
  placeType: 'settlement' | 'town' | 'hospital';
  lat: number;
  lng: number;
  population: number | null;
}

export interface OsmRoadSegment {
  id: string;
  osmId: string;
  name: string;
  highwayClass: string;
  sourceNodeId: string;
  targetNodeId: string;
  lengthKm: number;
  coordinates: [number, number][]; // [lat, lng][]
}

export interface OsmBridgeAsset {
  id: string;
  osmId: string;
  name: string;
  roadId: string;
  roadName: string;
  lat: number;
  lng: number;
  spanM: number | null;
}

export interface OsmBuildingAsset {
  id: string;
  osmId: string;
  name: string;
  buildingClass: string;
  lat: number;
  lng: number;
  footprint: [number, number][];
}

export interface DatedPreEventOsmExtract {
  fileName: string;
  extractTimestampIso: string; // Must be prior to eventDate
  sourceLabel: string;
  provenanceStatus: 'uploaded' | 'synthetic demo';
  isProvisionalOrMissingAttributes: boolean;
  settlements: OsmSettlementNode[];
  roads: OsmRoadSegment[];
  bridges: OsmBridgeAsset[];
  buildings: OsmBuildingAsset[];
}

export interface ImpassabilityRuleConfig {
  minIntersectingCandidateBlocks: number;
  bufferDistanceMeters: number;
  treatExposedBridgesAsImpassable: boolean;
  manualRoadOverrides: Record<string, boolean>; // true = forced impassable, false = forced passable
}

export interface EvaluatedRoadExposure extends OsmRoadSegment {
  intersectingCandidateUnits: number;
  exposed: boolean;
  markedImpassableByRule: boolean;
  ruleReason: string;
  provenanceStatus: 'derived estimate' | 'synthetic demo' | 'not assessed';
}

export interface EvaluatedBridgeExposure extends OsmBridgeAsset {
  exposed: boolean;
  exposureBasis: string;
  provenanceStatus: 'derived estimate' | 'synthetic demo' | 'not assessed';
}

export interface EvaluatedBuildingExposure extends OsmBuildingAsset {
  exposed: boolean;
  provenanceStatus: 'derived estimate' | 'synthetic demo' | 'not assessed';
}

export interface EvaluatedSettlementIsolation extends OsmSettlementNode {
  nearestTownName: string | null;
  nearestHospitalName: string | null;
  preEventTownDistKm: number | null;
  preEventHospitalDistKm: number | null;
  postEventTownDistKm: number | null;
  postEventHospitalDistKm: number | null;
  isolationStatus: 'REACHABLE_ESTIMATE' | 'CANDIDATE_CUT_OFF' | 'NOT_ASSESSED';
  limitingCorridor: string | null;
  assumptionNote: string;
  provenanceStatus: 'derived estimate' | 'synthetic demo' | 'not assessed';
}

export interface InfrastructureAndIsolationSummary {
  status: DataProvenanceStatus;
  osmExtractDate: string | null;
  osmSourceLabel: string;
  ruleDescription: string;
  exposedBuildingsCount: number | null;
  totalBuildingsCount: number | null;
  exposedRoadsCount: number | null;
  impassableRoadsCount: number | null;
  totalRoadsCount: number | null;
  exposedBridgesCount: number | null;
  totalBridgesCount: number | null;
  candidateCutOffSettlementsCount: number | null;
  reachableSettlementsCount: number | null;
  roads: EvaluatedRoadExposure[];
  bridges: EvaluatedBridgeExposure[];
  buildings: EvaluatedBuildingExposure[];
  settlements: EvaluatedSettlementIsolation[];
}

export interface InstalledAiModelManifest {
  weightsFileName: string;
  weightsByteSize: number;
  metadataFileName: string;
  uploadedAtIso: string;
  provenanceStatus: 'uploaded';
  modelName: string;
  sensor: string;
  polarizationsOrBands: string[];
  preprocessingSteps: string[];
  datasetSource: string;
  datasetLicense: string;
  splitStrategy: string;
  splitVerifiedDisjoint: boolean;
  heldOutMetrics: {
    iou: number | null;
    f1Score: number | null;
    precision: number | null;
    recall: number | null;
  };
  limitations: string[];
}

export interface CopernicusCatalogScene {
  id: string;
  collection: string;
  sensor: string;
  acquisitionDate: string;
  orbitDirection: string;
  relativeOrbitTrack: string | number;
  polarization: string;
  cloudCoverPercent: number | null;
  bbox: number[] | null;
  footprintCoverageNote: string;
  accessStatus: string;
  provenanceStatus: 'catalog result';
}

export interface FrozenOutputSnapshot {
  frozenAtIso: string;
  frozenHash: string;
  pathwayType: 'baseline only, not AI and not validated' | 'installed AI model';
  preRasterFile: string;
  postRasterFile: string;
  thresholdDb: number;
  minDropDb: number;
  candidatePixels: number;
  candidateAreaSqKm: number | null;
  candidatePolygonsWgs84: [number, number][][];
}

export interface EmsrValidationComparison {
  referenceFileName: string;
  referenceProductCode: 'EMSR927';
  comparedAgainstFrozenHash: string;
  comparedAtIso: string;
  referencePolygonCount: number;
  frozenCandidateBlocksCount: number;
  overlappingCandidateBlocksCount: number;
  overlapRatioEstimate: number;
  notes: string[];
}

export interface MapLayerVisibility {
  baseMap: boolean;
  preEventRaster: boolean;
  postEventRaster: boolean;
  opticalOverlay?: boolean;
  waterCandidateMask: boolean;
  osmBuildings: boolean;
  osmRoads: boolean;
  osmBridges: boolean;
  osmSettlements: boolean;
  osmHospitalsAndTowns: boolean;
  groundTruthFloodMask?: boolean;
  emsrValidationOverlay: boolean;
}

export type SelectedMapObject =
  | { kind: 'settlement'; data: EvaluatedSettlementIsolation }
  | { kind: 'road'; data: EvaluatedRoadExposure }
  | { kind: 'bridge'; data: EvaluatedBridgeExposure }
  | { kind: 'building'; data: EvaluatedBuildingExposure }
  | null;
