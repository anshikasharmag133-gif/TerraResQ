import { fromArrayBuffer, writeArrayBuffer } from 'geotiff';

export type DataProvenanceStatus =
  | 'uploaded'
  | 'catalog result'
  | 'derived estimate'
  | 'synthetic demo'
  | 'not assessed';

export interface ParsedGeoTiffRaster {
  fileName: string;
  sourceStatus: 'uploaded' | 'synthetic demo';
  acquisitionDate: string;
  width: number;
  height: number;
  bandCount: number;
  crsCode: number | null;
  crsName: string;
  isMetricProjectedCrs: boolean;
  pixelScale: [number, number, number] | null;
  tiepoint: [number, number, number, number, number, number] | null;
  bboxProjected: [number, number, number, number] | null;
  wgs84Bounds: [[number, number], [number, number]] | null; // [[south, west], [north, east]]
  nodataValue: number | null;
  declaredUnits: string;
  minDb: number;
  maxDb: number;
  meanDb: number;
  validPixelCount: number;
  nodataPixelCount: number;
  data: Float32Array;
}

export interface RasterValidationResult {
  valid: boolean;
  errors: string[];
  warnings: string[];
  checks: {
    fileTypeOk: boolean;
    bandCountOk: boolean;
    crsOk: boolean;
    transformOk: boolean;
    dimensionsMatch: boolean;
    nodataChecked: boolean;
    unitsOk: boolean;
  };
}

export interface WaterCandidateMaskResult {
  methodLabel: 'baseline only, not AI and not validated';
  sourceStatus: 'derived estimate' | 'synthetic demo';
  thresholdDb: number;
  minDropDb: number;
  width: number;
  height: number;
  totalPixels: number;
  validEvaluatedPixels: number;
  preWaterPixels: number;
  postWaterPixels: number;
  newCandidatePixels: number;
  areaDefensible: boolean;
  areaDefensibleReason: string;
  pixelAreaSqM: number | null;
  newCandidateAreaSqM: number | null;
  newCandidateAreaSqKm: number | null;
  postTotalWaterAreaSqKm: number | null;
  maskBinary: Uint8Array; // 1 = new water candidate, 0 = background, 255 = nodata
  wgs84Bounds: [[number, number], [number, number]] | null;
  crsCode: number | null;
  pixelScale: [number, number, number] | null;
  tiepoint: [number, number, number, number, number, number] | null;
  beforeDataUrl: string;
  afterDataUrl: string;
  maskDataUrl: string;
   candidatePolygonsWgs84: [number, number][][];
}

/**
 * Convert UTM (Zone 44N or 45N, WGS84) Easting/Northing (meters) to WGS84 [lat, lng].
 */
export function utmToWgs84(easting: number, northing: number, zone: number): [number, number] {
  const a = 6378137.0;
  const e = 0.081819190842622;
  const e1sq = 0.00673949674227643;
  const k0 = 0.9996;

  const x = easting - 500000.0;
  const y = northing;

  const m = y / k0;
  const mu = m / (a * (1 - (e * e) / 4 - (3 * Math.pow(e, 4)) / 64 - (5 * Math.pow(e, 6)) / 256));

  const phi1Rad =
    mu +
    ((3 * e1sq) / 2 - (27 * Math.pow(e1sq, 3)) / 32) * Math.sin(2 * mu) +
    ((21 * Math.pow(e1sq, 2)) / 16 - (55 * Math.pow(e1sq, 4)) / 32) * Math.sin(4 * mu) +
    ((151 * Math.pow(e1sq, 3)) / 96) * Math.sin(6 * mu);

  const n1 = a / Math.sqrt(1 - Math.pow(e * Math.sin(phi1Rad), 2));
  const t1 = Math.pow(Math.tan(phi1Rad), 2);
  const c1 = e1sq * Math.pow(Math.cos(phi1Rad), 2);
  const r1 = (a * (1 - e * e)) / Math.pow(1 - Math.pow(e * Math.sin(phi1Rad), 2), 1.5);
  const d = x / (n1 * k0);

  const latRad =
    phi1Rad -
    ((n1 * Math.tan(phi1Rad)) / r1) *
      ((d * d) / 2 -
        ((5 + 3 * t1 + 10 * c1 - 4 * c1 * c1 - 9 * e1sq) * Math.pow(d, 4)) / 24 +
        ((61 + 90 * t1 + 298 * c1 + 45 * t1 * t1 - 252 * e1sq - 3 * c1 * c1) * Math.pow(d, 6)) / 720);

  const lonOrigin = (zone - 1) * 6 - 180 + 3;
  const lngRad =
    (d -
      ((1 + 2 * t1 + c1) * Math.pow(d, 3)) / 6 +
      ((5 - 2 * c1 + 28 * t1 - 3 * c1 * c1 + 8 * e1sq + 24 * t1 * t1) * Math.pow(d, 5)) / 120) /
    Math.cos(phi1Rad);

  const lat = (latRad * 180) / Math.PI;
  const lng = lonOrigin + (lngRad * 180) / Math.PI;
  return [Number(lat.toFixed(6)), Number(lng.toFixed(6))];
}

/**
 * Parse a GeoTIFF file or ArrayBuffer and extract metadata + float32 pixel values.
 */
export async function parseGeoTiffBuffer(
  buffer: ArrayBuffer,
  fileName: string,
  acquisitionDate: string,
  declaredUnits: string,
  sourceStatus: 'uploaded' | 'synthetic demo' = 'uploaded'
): Promise<ParsedGeoTiffRaster> {
  const lower = fileName.toLowerCase();
  if (!lower.endsWith('.tif') && !lower.endsWith('.tiff')) {
    throw new Error(
      `Unsupported file format for "${fileName}". Please upload a valid GeoTIFF (.tif or .tiff) raster.`
    );
  }

  let tiff;
  try {
    tiff = await fromArrayBuffer(buffer);
  } catch (err) {
    throw new Error(
      `Could not parse "${fileName}" as a valid TIFF/GeoTIFF binary: ${
        err instanceof Error ? err.message : 'Corrupted header'
      }`
    );
  }

  const image = await tiff.getImage();
  const width = image.getWidth();
  const height = image.getHeight();
  const bandCount = image.getSamplesPerPixel();
  const fileDir = image.getFileDirectory() as unknown as Record<string, number[] | undefined>;
  const geoKeys = (image.getGeoKeys() || {}) as Record<string, number | undefined>;

  const crsCode: number | null =
    geoKeys.ProjectedCSTypeGeoKey || geoKeys.GeographicTypeGeoKey || null;

  const isMetricProjectedCrs =
    crsCode !== null &&
    ((crsCode >= 32601 && crsCode <= 32760) || crsCode === 3857 || crsCode === 3035);

  let crsName = 'Unspecified / Missing CRS';
  if (crsCode === 32645) crsName = 'EPSG:32645 (WGS 84 / UTM zone 45N — Metric)';
  else if (crsCode === 32644) crsName = 'EPSG:32644 (WGS 84 / UTM zone 44N — Metric)';
  else if (crsCode === 4326) crsName = 'EPSG:4326 (WGS 84 Geographic Degrees)';
  else if (crsCode !== null) crsName = `EPSG:${crsCode}`;

  const rawScale = fileDir.ModelPixelScale;
  const pixelScale: [number, number, number] | null =
    rawScale && rawScale.length >= 2
      ? [Number(rawScale[0]), Number(rawScale[1]), Number(rawScale[2] || 0)]
      : null;

  const rawTie = fileDir.ModelTiepoint;
  const tiepoint: [number, number, number, number, number, number] | null =
    rawTie && rawTie.length >= 6
      ? [
          Number(rawTie[0]),
          Number(rawTie[1]),
          Number(rawTie[2]),
          Number(rawTie[3]),
          Number(rawTie[4]),
          Number(rawTie[5]),
        ]
      : null;

  let bboxProjected: [number, number, number, number] | null = null;
  let wgs84Bounds: [[number, number], [number, number]] | null = null;

  if (pixelScale && tiepoint) {
    const minX = tiepoint[3];
    const maxY = tiepoint[4];
    const maxX = minX + width * pixelScale[0];
    const minY = maxY - height * pixelScale[1];
    bboxProjected = [minX, minY, maxX, maxY];

    if (crsCode === 4326) {
      wgs84Bounds = [
        [minY, minX],
        [maxY, maxX],
      ];
    } else if (crsCode === 32645 || crsCode === 32644) {
      const zone = crsCode === 32645 ? 45 : 44;
      const sw = utmToWgs84(minX, minY, zone);
      const ne = utmToWgs84(maxX, maxY, zone);
      wgs84Bounds = [sw, ne];
    }
  }

  const gdalNoDataStr = image.getGDALNoData();
  const nodataValue =
    gdalNoDataStr !== null && gdalNoDataStr !== undefined && !Number.isNaN(Number(gdalNoDataStr))
      ? Number(gdalNoDataStr)
      : -9999;

  const rasters = await image.readRasters();
  const band0 = rasters[0] as ArrayLike<number>;
  const floatData = new Float32Array(width * height);

  let minDb = Infinity;
  let maxDb = -Infinity;
  let sumDb = 0;
  let validPixelCount = 0;
  let nodataPixelCount = 0;

  for (let i = 0; i < width * height; i++) {
    const v = Number(band0[i]);
    if (
      Number.isNaN(v) ||
      !Number.isFinite(v) ||
      (nodataValue !== null && Math.abs(v - nodataValue) < 1e-4) ||
      v <= -999
    ) {
      floatData[i] = NaN;
      nodataPixelCount++;
    } else {
      floatData[i] = v;
      if (v < minDb) minDb = v;
      if (v > maxDb) maxDb = v;
      sumDb += v;
      validPixelCount++;
    }
  }

  return {
    fileName,
    sourceStatus,
    acquisitionDate,
    width,
    height,
    bandCount,
    crsCode,
    crsName,
    isMetricProjectedCrs,
    pixelScale,
    tiepoint,
    bboxProjected,
    wgs84Bounds,
    nodataValue,
    declaredUnits,
    minDb: validPixelCount > 0 ? Number(minDb.toFixed(2)) : 0,
    maxDb: validPixelCount > 0 ? Number(maxDb.toFixed(2)) : 0,
    meanDb: validPixelCount > 0 ? Number((sumDb / validPixelCount).toFixed(2)) : 0,
    validPixelCount,
    nodataPixelCount,
    data: floatData,
  };
}

/**
 * Validate a pre-event and post-event Sentinel-1 VV GeoTIFF pair.
 * Rejects incompatible rasters with plain-language errors.
 */
export function validateCoRegisteredRasters(
  pre: ParsedGeoTiffRaster | null,
  post: ParsedGeoTiffRaster | null,
  unitsConfirmedAsDb: boolean
): RasterValidationResult {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (!pre || !post) {
    return {
      valid: false,
      errors: ['Both a pre-event and a post-event Sentinel-1 VV GeoTIFF raster must be loaded.'],
      warnings: [],
      checks: {
        fileTypeOk: false,
        bandCountOk: false,
        crsOk: false,
        transformOk: false,
        dimensionsMatch: false,
        nodataChecked: false,
        unitsOk: false,
      },
    };
  }

  const fileTypeOk =
    (pre.fileName.toLowerCase().endsWith('.tif') || pre.fileName.toLowerCase().endsWith('.tiff')) &&
    (post.fileName.toLowerCase().endsWith('.tif') || post.fileName.toLowerCase().endsWith('.tiff'));

  if (!fileTypeOk) {
    errors.push('File type error: Both uploads must be GeoTIFF (.tif or .tiff) files.');
  }

  const bandCountOk = pre.bandCount === 1 && post.bandCount === 1;
  if (!bandCountOk) {
    errors.push(
      `Incompatible band count: Expected single-band (1-band) Sentinel-1 VV backscatter rasters, but pre-event has ${pre.bandCount} band(s) and post-event has ${post.bandCount} band(s).`
    );
  }

  const dimensionsMatch =
    pre.width > 0 &&
    pre.height > 0 &&
    pre.width === post.width &&
    pre.height === post.height;

  if (!dimensionsMatch) {
    errors.push(
      `Grid dimension mismatch: Pre-event raster is ${pre.width}×${pre.height} pixels, whereas post-event raster is ${post.width}×${post.height} pixels. Rasters must be co-registered on the same grid.`
    );
  }

  const crsOk = pre.crsCode !== null && post.crsCode !== null && pre.crsCode === post.crsCode;
  if (pre.crsCode === null || post.crsCode === null) {
    errors.push(
      `Missing Coordinate Reference System (CRS): Pre-event CRS is "${pre.crsName}" and Post-event CRS is "${post.crsName}". Both GeoTIFFs must declare a valid EPSG CRS.`
    );
  } else if (pre.crsCode !== post.crsCode) {
    errors.push(
      `CRS mismatch: Pre-event raster is in EPSG:${pre.crsCode}, whereas post-event raster is in EPSG:${post.crsCode}. Reproject both rasters to a shared CRS before running change detection.`
    );
  }

  let transformOk = false;
  if (pre.pixelScale && post.pixelScale && pre.tiepoint && post.tiepoint) {
    const scaleMatch =
      Math.abs(pre.pixelScale[0] - post.pixelScale[0]) < 1e-4 &&
      Math.abs(pre.pixelScale[1] - post.pixelScale[1]) < 1e-4;
    const originMatch =
      Math.abs(pre.tiepoint[3] - post.tiepoint[3]) < 1e-2 &&
      Math.abs(pre.tiepoint[4] - post.tiepoint[4]) < 1e-2;
    transformOk = scaleMatch && originMatch;
    if (!scaleMatch) {
      errors.push(
        `Pixel resolution mismatch: Pre-event pixel size is (${pre.pixelScale[0]}, ${pre.pixelScale[1]}), while post-event pixel size is (${post.pixelScale[0]}, ${post.pixelScale[1]}).`
      );
    }
    if (!originMatch) {
      errors.push(
        `Georeferencing origin mismatch: Pre-event tiepoint (${pre.tiepoint[3]}, ${pre.tiepoint[4]}) does not align with post-event tiepoint (${post.tiepoint[3]}, ${post.tiepoint[4]}).`
      );
    }
  } else {
    errors.push(
      'Missing GeoTIFF affine transform tags (ModelPixelScaleTag / ModelTiepointTag). Cannot verify co-registration.'
    );
  }

  const nodataChecked = pre.validPixelCount > 0 && post.validPixelCount > 0;
  if (!nodataChecked) {
    errors.push('One or both rasters contain zero valid non-nodata pixels.');
  }

  // Check declared units & plausible physical SAR decibel range [-55, +30] dB
  const plausibleDbRange =
    pre.minDb >= -60 &&
    pre.maxDb <= 35 &&
    post.minDb >= -60 &&
    post.maxDb <= 35;

  const unitsOk = unitsConfirmedAsDb && pre.declaredUnits === 'dB' && post.declaredUnits === 'dB' && plausibleDbRange;
  if (!unitsConfirmedAsDb) {
    errors.push('Declared units not confirmed: You must confirm that input raster values are in decibels (dB).');
  }
  if (!plausibleDbRange) {
    errors.push(
      `Implausible SAR decibel values detected: Pre-event range is [${pre.minDb}, ${pre.maxDb}] and Post-event range is [${post.minDb}, ${post.maxDb}]. Calibrated Sentinel-1 VV backscatter in dB must lie within [-60 dB, +35 dB]. Uncalibrated linear DN integers are rejected.`
    );
  }

  if (!pre.isMetricProjectedCrs && crsOk) {
    warnings.push(
      `CRS EPSG:${pre.crsCode} uses angular degrees rather than projected meters. Candidate pixel count will be reported, but metric area calculation is disabled unless rasters use a projected metric CRS (e.g., EPSG:32645 UTM Zone 45N).`
    );
  }

  return {
    valid: errors.length === 0,
    errors,
    warnings,
    checks: {
      fileTypeOk,
      bandCountOk,
      crsOk,
      transformOk,
      dimensionsMatch,
      nodataChecked,
      unitsOk,
    },
  };
}

/**
 * Render a grayscale or mask RGBA PNG DataURL from a raster grid for Leaflet ImageOverlay & Before/After view.
 */
function renderGridToDataUrl(
  width: number,
  height: number,
  pixelCallback: (idx: number) => [number, number, number, number]
): string {
  const canvas = document.createElement('canvas');
  canvas.width = width;
  canvas.height = height;
  const ctx = canvas.getContext('2d');
  if (!ctx) return '';
  const imgData = ctx.createImageData(width, height);
  const buf = imgData.data;
  for (let i = 0; i < width * height; i++) {
    const [r, g, b, a] = pixelCallback(i);
    const offset = i * 4;
    buf[offset] = r;
    buf[offset + 1] = g;
    buf[offset + 2] = b;
    buf[offset + 3] = a;
  }
  ctx.putImageData(imgData, 0, 0);
  return canvas.toDataURL('image/png');
}

/**
 * Generate the simple low-backscatter water-candidate mask from validated pre & post rasters.
 * Explicitly labelled "baseline only, not AI and not validated".
 */
export function computeLowBackscatterCandidateMask(
  pre: ParsedGeoTiffRaster,
  post: ParsedGeoTiffRaster,
  thresholdDb: number,
  minDropDb: number = 1.5
): WaterCandidateMaskResult {
  const width = pre.width;
  const height = pre.height;
  const totalPixels = width * height;
  const maskBinary = new Uint8Array(totalPixels);

  let validEvaluatedPixels = 0;
  let preWaterPixels = 0;
  let postWaterPixels = 0;
  let newCandidatePixels = 0;

  for (let i = 0; i < totalPixels; i++) {
    const vPre = pre.data[i];
    const vPost = post.data[i];
    if (Number.isNaN(vPre) || Number.isNaN(vPost)) {
      maskBinary[i] = 255; // nodata
      continue;
    }
    validEvaluatedPixels++;
    const isPreWater = vPre <= thresholdDb;
    const isPostWater = vPost <= thresholdDb;
    if (isPreWater) preWaterPixels++;
    if (isPostWater) postWaterPixels++;

    // New low-backscatter water candidate: post is below threshold, pre was above threshold, and drop >= minDropDb
    if (isPostWater && !isPreWater && vPost - vPre <= -minDropDb) {
      maskBinary[i] = 1;
      newCandidatePixels++;
    } else {
      maskBinary[i] = 0;
    }
  }

  // Check if pixel size and CRS support a defensible metric area calculation
  let areaDefensible = false;
  let areaDefensibleReason =
    'Area not assessed — CRS or pixel scale does not support a defensible metric area calculation.';
  let pixelAreaSqM: number | null = null;
  let newCandidateAreaSqM: number | null = null;
  let newCandidateAreaSqKm: number | null = null;
  let postTotalWaterAreaSqKm: number | null = null;

  if (pre.isMetricProjectedCrs && pre.pixelScale && pre.pixelScale[0] > 0 && pre.pixelScale[1] > 0) {
    areaDefensible = true;
    pixelAreaSqM = Number((pre.pixelScale[0] * pre.pixelScale[1]).toFixed(4));
    newCandidateAreaSqM = Number((newCandidatePixels * pixelAreaSqM).toFixed(1));
    newCandidateAreaSqKm = Number(((newCandidatePixels * pixelAreaSqM) / 1e6).toFixed(4));
    postTotalWaterAreaSqKm = Number(((postWaterPixels * pixelAreaSqM) / 1e6).toFixed(4));
    areaDefensibleReason = `Projected metric CRS (${pre.crsName}) with ${pre.pixelScale[0]}m × ${pre.pixelScale[1]}m pixel resolution (${pixelAreaSqM} m²/pixel).`;
  }

  // Render Before, After, and Mask DataURLs for Map Overlay & Inspector
  const dbToGray = (db: number): number => {
    const norm = (Math.max(-28, Math.min(-2, db)) - -28) / 26;
    return Math.round(norm * 255);
  };

  const beforeDataUrl = renderGridToDataUrl(width, height, (idx) => {
    const v = pre.data[idx];
    if (Number.isNaN(v)) return [0, 0, 0, 0];
    const g = dbToGray(v);
    return [g, g + 3 > 255 ? 255 : g + 3, g + 6 > 255 ? 255 : g + 6, 230];
  });

  const afterDataUrl = renderGridToDataUrl(width, height, (idx) => {
    const v = post.data[idx];
    if (Number.isNaN(v)) return [0, 0, 0, 0];
    const g = dbToGray(v);
    return [g, g + 3 > 255 ? 255 : g + 3, g + 6 > 255 ? 255 : g + 6, 230];
  });

  const maskDataUrl = renderGridToDataUrl(width, height, (idx) => {
    const m = maskBinary[idx];
    if (m === 1) {
      // High-visibility cyan for new water candidate
      return [6, 182, 212, 215];
    }
    if (!Number.isNaN(pre.data[idx]) && pre.data[idx] <= thresholdDb) {
      // Pre-existing baseline river channel in muted deep blue
      return [2, 132, 199, 130];
    }
    return [0, 0, 0, 0];
  });

  // Extract bounding candidate cells in WGS84 for vector intersection checks against pre-event OSM
  const candidatePolygonsWgs84: [number, number][][] = [];
  if (pre.wgs84Bounds) {
    const [[south, west], [north, east]] = pre.wgs84Bounds;
    const dLat = (north - south) / height;
    const dLng = (east - west) / width;
    // Group into coarse 4x4 block bounding boxes for fast intersection checks
    const step = 4;
    for (let r = 0; r < height; r += step) {
      for (let c = 0; c < width; c += step) {
        let countInBlock = 0;
        for (let dr = 0; dr < step && r + dr < height; dr++) {
          for (let dc = 0; dc < step && c + dc < width; dc++) {
            if (maskBinary[(r + dr) * width + (c + dc)] === 1) {
              countInBlock++;
            }
          }
        }
        if (countInBlock >= 2) {
          const cellNorth = north - r * dLat;
          const cellSouth = north - Math.min(height, r + step) * dLat;
          const cellWest = west + c * dLng;
          const cellEast = west + Math.min(width, c + step) * dLng;
          candidatePolygonsWgs84.push([
            [cellSouth, cellWest],
            [cellSouth, cellEast],
            [cellNorth, cellEast],
            [cellNorth, cellWest],
          ]);
        }
      }
    }
  }

  return {
    methodLabel: 'baseline only, not AI and not validated',
    sourceStatus:
      pre.sourceStatus === 'synthetic demo' || post.sourceStatus === 'synthetic demo'
        ? 'synthetic demo'
        : 'derived estimate',
    thresholdDb,
    minDropDb,
    width,
    height,
    totalPixels,
    validEvaluatedPixels,
    preWaterPixels,
    postWaterPixels,
    newCandidatePixels,
    areaDefensible,
    areaDefensibleReason,
    pixelAreaSqM,
    newCandidateAreaSqM,
    newCandidateAreaSqKm,
    postTotalWaterAreaSqKm,
    maskBinary,
    wgs84Bounds: pre.wgs84Bounds,
    crsCode: pre.crsCode,
    pixelScale: pre.pixelScale,
    tiepoint: pre.tiepoint,
    beforeDataUrl,
    afterDataUrl,
    maskDataUrl,
    candidatePolygonsWgs84,
  };
}

/**
 * Export the candidate mask as a valid georeferenced 8-bit GeoTIFF binary ArrayBuffer.
 */
export async function exportCandidateMaskGeoTiff(
  maskResult: WaterCandidateMaskResult
): Promise<ArrayBuffer> {
  const { width, height, maskBinary, pixelScale, tiepoint, crsCode } = maskResult;
  const metadata: Record<string, unknown> = {
    width,
    height,
    BitsPerSample: [8],
    Compression: 1,
    PhotometricInterpretation: 1,
    SamplesPerPixel: 1,
    SampleFormat: [1],
  };

  if (pixelScale) {
    metadata.ModelPixelScale = pixelScale;
  }
  if (tiepoint) {
    metadata.ModelTiepoint = tiepoint;
  }
  if (crsCode) {
    if (crsCode === 4326) {
      metadata.GeographicTypeGeoKey = 4326;
      metadata.GTModelTypeGeoKey = 2;
    } else {
      metadata.ProjectedCSTypeGeoKey = crsCode;
      metadata.GTModelTypeGeoKey = 1;
    }
  }

  return await writeArrayBuffer(maskBinary, metadata);
}

/**
 * Generate a synthetic co-registered Sentinel-1 VV dB GeoTIFF pair in memory
 * (or downloadable as .tif files) explicitly marked as "synthetic demo".
 * Uses UTM Zone 45N (EPSG:32645) with 20m x 20m pixels (120 x 120 grid = 2.4km x 2.4km).
 */
export async function createSyntheticDemoGeoTiffBuffers(options?: {
  makeIncompatible?: boolean;
}): Promise<{
  preBuffer: ArrayBuffer;
  postBuffer: ArrayBuffer;
  preFileName: string;
  postFileName: string;
}> {
  const width = 120;
  const height = 120;
  const pixelSizeM = 30; // 30m x 30m resolution -> 3.6km x 3.6km swath
  // UTM Zone 45N coordinates near Syaphrubesi / Timure gorge (Easting ~336000, Northing ~3118000)
  const originX = 334500;
  const originY = 3121500;

  const preValues = new Uint8Array(width * height);
  const postWidth = options?.makeIncompatible ? 96 : width;
  const postHeight = options?.makeIncompatible ? 96 : height;
  const postValues = new Uint8Array(postWidth * postHeight);

  // Note: writeArrayBuffer in geotiff.js works cleanest with typed arrays.
  // To store signed dB values in a compact portable TIFF or Float32, let's check if writeArrayBuffer supports Float32Array or Int8.
  // Actually, let's build a clean IEEE-754 Float32 GeoTIFF binary writer so our generated .tif files have exact Float32 dB values (e.g. -22.4 dB to -6.5 dB)!
  const preFloat = new Float32Array(width * height);
  const postFloat = new Float32Array(postWidth * postHeight);

  for (let r = 0; r < height; r++) {
    for (let c = 0; c < width; c++) {
      const idx = r * width + c;
      const riverCenter = width * 0.5 + Math.sin(r * 0.08) * 14;
      const dist = Math.abs(c - riverCenter);
      const terrainNoise = Math.sin(r * 0.35 + c * 0.27) * 1.6 + Math.cos(r * 0.19 - c * 0.41) * 1.1;

      // Pre-event: narrow river channel (dist < 3.2 pixels has ~ -20.5 dB, valley slopes have ~ -9.5 dB)
      if (dist < 3.2) {
        preFloat[idx] = Number((-20.8 + terrainNoise * 0.4).toFixed(2));
      } else {
        preFloat[idx] = Number((-9.8 + terrainNoise).toFixed(2));
      }
      preValues[idx] = 0;
    }
  }

  for (let r = 0; r < postHeight; r++) {
    for (let c = 0; c < postWidth; c++) {
      const idx = r * postWidth + c;
      const riverCenter = postWidth * 0.5 + Math.sin(r * 0.08) * 14;
      const dist = Math.abs(c - riverCenter);
      const terrainNoise = Math.sin(r * 0.31 + c * 0.29) * 1.5 + Math.cos(r * 0.23 - c * 0.37) * 1.1;

      // Post-event: expanded low-backscatter flood zone along river benches (dist < 11.5 pixels drops to ~ -19.2 dB)
      const floodSpread = 10.5 + Math.sin(r * 0.12) * 3.5;
      if (dist < floodSpread) {
        postFloat[idx] = Number((-19.4 + terrainNoise * 0.45).toFixed(2));
      } else {
        postFloat[idx] = Number((-9.6 + terrainNoise).toFixed(2));
      }
      postValues[idx] = 0;
    }
  }

  const preBuffer = encodeFloat32GeoTiff(preFloat, width, height, {
    crsCode: 32645,
    pixelScale: [pixelSizeM, pixelSizeM, 0],
    tiepoint: [0, 0, 0, originX, originY, 0],
  });

  const postBuffer = encodeFloat32GeoTiff(postFloat, postWidth, postHeight, {
    crsCode: options?.makeIncompatible ? 4326 : 32645,
    pixelScale: options?.makeIncompatible ? [0.00025, 0.00025, 0] : [pixelSizeM, pixelSizeM, 0],
    tiepoint: [0, 0, 0, originX, originY, 0],
  });

  return {
    preBuffer,
    postBuffer,
    preFileName: 'SYNTHETIC_DEMO_S1_VV_PRE_20260802_dB.tif',
    postFileName: options?.makeIncompatible
      ? 'INCOMPATIBLE_TEST_S1_VV_POST_MISMATCH.tif'
      : 'SYNTHETIC_DEMO_S1_VV_POST_20260814_dB.tif',
  };
}

/**
 * Minimal, standards-compliant IEEE-754 32-bit Float GeoTIFF encoder.
 * Writes exact Float32 pixel values along with ModelPixelScaleTag (33550),
 * ModelTiepointTag (33922), and GeoKeyDirectoryTag (34735) so `geotiff.fromArrayBuffer`
 * and desktop GIS tools (QGIS / Rasterio) read exact dB floats and CRS tags.
 */
export function encodeFloat32GeoTiff(
  floatData: Float32Array,
  width: number,
  height: number,
  geo: {
    crsCode: number;
    pixelScale: [number, number, number];
    tiepoint: [number, number, number, number, number, number];
  }
): ArrayBuffer {
  const numPixels = width * height;
  const pixelBytes = numPixels * 4;

  // GeoKeyDirectory: [KeyDirectoryVersion=1, KeyRevision=1, MinorRevision=0, NumberOfKeys=2,
  //   1024 (GTModelTypeGeoKey), 0, 1, 1 (Projected) or 2 (Geographic),
  //   3072 (ProjectedCSTypeGeoKey) or 2048 (GeographicTypeGeoKey), 0, 1, crsCode]
  const isGeographic = geo.crsCode === 4326;
  const geoKeys = new Uint16Array([
    1,
    1,
    0,
    2,
    1024,
    0,
    1,
    isGeographic ? 2 : 1,
    isGeographic ? 2048 : 3072,
    0,
    1,
    geo.crsCode,
  ]);

  const numEntries = 12;
  const headerSize = 8;
  const ifdSize = 2 + numEntries * 12 + 4;
  const extraDataOffset = headerSize + ifdSize;
  // Extra data:
  // - ModelPixelScale: 3 doubles = 24 bytes
  // - ModelTiepoint: 6 doubles = 48 bytes
  // - GeoKeyDirectory: 12 uint16 = 24 bytes
  const scaleOffset = extraDataOffset;
  const tiepointOffset = scaleOffset + 24;
  const geoKeyOffset = tiepointOffset + 48;
  const stripOffset = geoKeyOffset + 24;
  const totalByteLength = stripOffset + pixelBytes;

  const buffer = new ArrayBuffer(totalByteLength);
  const view = new DataView(buffer);

  // Little-endian TIFF header ('II', 42, offset to first IFD = 8)
  view.setUint8(0, 0x49);
  view.setUint8(1, 0x49);
  view.setUint16(2, 42, true);
  view.setUint32(4, 8, true);

  let pos = 8;
  view.setUint16(pos, numEntries, true);
  pos += 2;

  const writeEntry = (tag: number, type: number, count: number, valueOrOffset: number) => {
    view.setUint16(pos, tag, true);
    view.setUint16(pos + 2, type, true);
    view.setUint32(pos + 4, count, true);
    view.setUint32(pos + 8, valueOrOffset, true);
    pos += 12;
  };

  // Tags must be in ascending numerical order per TIFF 6.0 specification:
  // 256: ImageWidth (LONG = 4)
  writeEntry(256, 4, 1, width);
  // 257: ImageLength (LONG = 4)
  writeEntry(257, 4, 1, height);
  // 258: BitsPerSample (SHORT = 3) -> 32 bits
  writeEntry(258, 3, 1, 32);
  // 259: Compression (SHORT = 3) -> 1 (No compression)
  writeEntry(259, 3, 1, 1);
  // 262: PhotometricInterpretation (SHORT = 3) -> 1 (BlackIsZero)
  writeEntry(262, 3, 1, 1);
  // 273: StripOffsets (LONG = 4)
  writeEntry(273, 4, 1, stripOffset);
  // 277: SamplesPerPixel (SHORT = 3) -> 1
  writeEntry(277, 3, 1, 1);
  // 278: RowsPerStrip (LONG = 4) -> height
  writeEntry(278, 4, 1, height);
  // 279: StripByteCounts (LONG = 4) -> pixelBytes
  writeEntry(279, 4, 1, pixelBytes);
  // 339: SampleFormat (SHORT = 3) -> 3 (IEEE floating point)
  writeEntry(339, 3, 1, 3);
  // 33550: ModelPixelScaleTag (DOUBLE = 12, count = 3)
  writeEntry(33550, 12, 3, scaleOffset);
  // 33922: ModelTiepointTag (DOUBLE = 12, count = 6)
  writeEntry(33922, 12, 6, tiepointOffset);

  // Wait: let's include 34735 (GeoKeyDirectoryTag) as the 13th entry! Let's adjust numEntries properly.
  return encodeFloat32GeoTiffWithGeoKeys(floatData, width, height, geo, geoKeys);
}

function encodeFloat32GeoTiffWithGeoKeys(
  floatData: Float32Array,
  width: number,
  height: number,
  geo: {
    crsCode: number;
    pixelScale: [number, number, number];
    tiepoint: [number, number, number, number, number, number];
  },
  geoKeys: Uint16Array
): ArrayBuffer {
  const numPixels = width * height;
  const pixelBytes = numPixels * 4;
  const numEntries = 13;
  const headerSize = 8;
  const ifdSize = 2 + numEntries * 12 + 4;
  const scaleOffset = headerSize + ifdSize;
  const tiepointOffset = scaleOffset + 24;
  const geoKeyOffset = tiepointOffset + 48;
  const stripOffset = geoKeyOffset + geoKeys.byteLength;
  const totalByteLength = stripOffset + pixelBytes;

  const buffer = new ArrayBuffer(totalByteLength);
  const view = new DataView(buffer);

  view.setUint8(0, 0x49);
  view.setUint8(1, 0x49);
  view.setUint16(2, 42, true);
  view.setUint32(4, 8, true);

  let pos = 8;
  view.setUint16(pos, numEntries, true);
  pos += 2;

  const writeEntry = (tag: number, type: number, count: number, valueOrOffset: number) => {
    view.setUint16(pos, tag, true);
    view.setUint16(pos + 2, type, true);
    view.setUint32(pos + 4, count, true);
    view.setUint32(pos + 8, valueOrOffset, true);
    pos += 12;
  };

  writeEntry(256, 4, 1, width);
  writeEntry(257, 4, 1, height);
  writeEntry(258, 3, 1, 32);
  writeEntry(259, 3, 1, 1);
  writeEntry(262, 3, 1, 1);
  writeEntry(273, 4, 1, stripOffset);
  writeEntry(277, 3, 1, 1);
  writeEntry(278, 4, 1, height);
  writeEntry(279, 4, 1, pixelBytes);
  writeEntry(339, 3, 1, 3); // IEEE Float
  writeEntry(33550, 12, 3, scaleOffset);
  writeEntry(33922, 12, 6, tiepointOffset);
  writeEntry(34735, 3, geoKeys.length, geoKeyOffset);

  // Next IFD offset = 0
  view.setUint32(pos, 0, true);

  // Write ModelPixelScale (3 float64)
  for (let i = 0; i < 3; i++) {
    view.setFloat64(scaleOffset + i * 8, geo.pixelScale[i], true);
  }
  // Write ModelTiepoint (6 float64)
  for (let i = 0; i < 6; i++) {
    view.setFloat64(tiepointOffset + i * 8, geo.tiepoint[i], true);
  }
  // Write GeoKeys (uint16[])
  for (let i = 0; i < geoKeys.length; i++) {
    view.setUint16(geoKeyOffset + i * 2, geoKeys[i], true);
  }
  // Write Float32 pixel values
  for (let i = 0; i < numPixels; i++) {
    view.setFloat32(stripOffset + i * 4, floatData[i], true);
  }

  return buffer;
}
