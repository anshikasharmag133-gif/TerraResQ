import {
  DatedPreEventOsmExtract,
  EvaluatedBridgeExposure,
  EvaluatedBuildingExposure,
  EvaluatedRoadExposure,
  EvaluatedSettlementIsolation,
  FrozenOutputSnapshot,
  ImpassabilityRuleConfig,
  InfrastructureAndIsolationSummary,
  InstalledAiModelManifest,
  OsmBridgeAsset,
  OsmBuildingAsset,
  OsmRoadSegment,
  OsmSettlementNode,
  StudyAreaConfig,
  WaterCandidateMaskResult,
} from '../types/terraresq';

/**
 * Compute geodesic distance in meters between two WGS84 [lat, lng] points.
 */
export function haversineMeters(
  lat1: number,
  lng1: number,
  lat2: number,
  lng2: number
): number {
  const R = 6371000;
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLng = ((lng2 - lng1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLng / 2) *
      Math.sin(dLng / 2);
  return 2 * R * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
}

/**
 * Check if a point [lat, lng] lies within bufferMeters of any candidate block polygon.
 */
function countNearbyCandidateBlocks(
  points: [number, number][],
  candidatePolygons: [number, number][][],
  bufferMeters: number
): number {
  let count = 0;
  for (const poly of candidatePolygons) {
    const centerLat = (poly[0][0] + poly[2][0]) / 2;
    const centerLng = (poly[0][1] + poly[2][1]) / 2;
    for (const [pLat, pLng] of points) {
      if (haversineMeters(pLat, pLng, centerLat, centerLng) <= bufferMeters + 65) {
        count++;
        break;
      }
    }
  }
  return count;
}

/**
 * Interpolate intermediate points along a road polyline for accurate candidate mask intersection.
 */
function samplePolylinePoints(coords: [number, number][]): [number, number][] {
  const sampled: [number, number][] = [];
  for (let i = 0; i < coords.length; i++) {
    sampled.push(coords[i]);
    if (i < coords.length - 1) {
      const [lat1, lng1] = coords[i];
      const [lat2, lng2] = coords[i + 1];
      for (let s = 1; s <= 4; s++) {
        const frac = s / 5;
        sampled.push([lat1 + (lat2 - lat1) * frac, lng1 + (lng2 - lng1) * frac]);
      }
    }
  }
  return sampled;
}

/**
 * Dijkstra shortest path on the supplied road graph.
 */
function shortestPathOnGraph(
  startNodeId: string,
  targetNodeIds: Set<string>,
  allNodeIds: string[],
  roads: EvaluatedRoadExposure[],
  ignoreImpassable: boolean
): { targetId: string | null; distKm: number | null; usedRoadNames: string[] } {
  const adj = new Map<
    string,
    { neighborId: string; lengthKm: number; roadName: string }[]
  >();
  for (const id of allNodeIds) adj.set(id, []);

  for (const r of roads) {
    if (ignoreImpassable && r.markedImpassableByRule) continue;
    adj.get(r.sourceNodeId)?.push({
      neighborId: r.targetNodeId,
      lengthKm: r.lengthKm,
      roadName: r.name,
    });
    adj.get(r.targetNodeId)?.push({
      neighborId: r.sourceNodeId,
      lengthKm: r.lengthKm,
      roadName: r.name,
    });
  }

  const dist = new Map<string, number>();
  const prevEdge = new Map<string, { from: string; roadName: string }>();
  const visited = new Set<string>();
  dist.set(startNodeId, 0);

  while (visited.size < allNodeIds.length) {
    let curr: string | null = null;
    let best = Infinity;
    for (const [nid, d] of dist.entries()) {
      if (!visited.has(nid) && d < best) {
        best = d;
        curr = nid;
      }
    }
    if (curr === null || best === Infinity) break;
    visited.add(curr);

    if (targetNodeIds.has(curr)) {
      const roadPath: string[] = [];
      let trace = curr;
      while (prevEdge.has(trace)) {
        const p = prevEdge.get(trace)!;
        roadPath.unshift(p.roadName);
        trace = p.from;
      }
      return {
        targetId: curr,
        distKm: Number(best.toFixed(2)),
        usedRoadNames: roadPath,
      };
    }

    for (const edge of adj.get(curr) || []) {
      if (!visited.has(edge.neighborId)) {
        const alt = best + edge.lengthKm;
        if (alt < (dist.get(edge.neighborId) ?? Infinity)) {
          dist.set(edge.neighborId, alt);
          prevEdge.set(edge.neighborId, { from: curr, roadName: edge.roadName });
        }
      }
    }
  }

  return { targetId: null, distKm: null, usedRoadNames: [] };
}

/**
 * Evaluate pre-event OSM infrastructure exposure and road-graph isolation
 * strictly from the loaded water-candidate mask and dated pre-event OSM extract.
 * Never invents features or claims structural damage from intersection alone.
 */
export function evaluateInfrastructureAndIsolation(
  osmExtract: DatedPreEventOsmExtract | null,
  maskResult: WaterCandidateMaskResult | null,
  rule: ImpassabilityRuleConfig
): InfrastructureAndIsolationSummary {
  const ruleDescription = `Mark road segment impassable if >= ${rule.minIntersectingCandidateBlocks} water-candidate block(s) intersect within ${rule.bufferDistanceMeters}m buffer${
    rule.treatExposedBridgesAsImpassable ? ' OR if a bridge on the segment is exposed' : ''
  } (Assumption only; does not represent live road conditions).`;

  if (!osmExtract) {
    return {
      status: 'not assessed',
      osmExtractDate: null,
      osmSourceLabel: 'No dated pre-event OSM extract supplied',
      ruleDescription,
      exposedBuildingsCount: null,
      totalBuildingsCount: null,
      exposedRoadsCount: null,
      impassableRoadsCount: null,
      totalRoadsCount: null,
      exposedBridgesCount: null,
      totalBridgesCount: null,
      candidateCutOffSettlementsCount: null,
      reachableSettlementsCount: null,
      roads: [],
      bridges: [],
      buildings: [],
      settlements: [],
    };
  }

  const provenance: 'derived estimate' | 'synthetic demo' | 'not assessed' =
    !maskResult
      ? 'not assessed'
      : osmExtract.provenanceStatus === 'synthetic demo' ||
          maskResult.sourceStatus === 'synthetic demo'
        ? 'synthetic demo'
        : 'derived estimate';

  const candidatePolys = maskResult ? maskResult.candidatePolygonsWgs84 : [];

  // 1. Evaluate Bridges (Exposure estimate only)
  const bridges: EvaluatedBridgeExposure[] = osmExtract.bridges.map((b) => {
    const hits = maskResult
      ? countNearbyCandidateBlocks([[b.lat, b.lng]], candidatePolys, rule.bufferDistanceMeters)
      : 0;
    const exposed = hits > 0;
    return {
      ...b,
      exposed,
      exposureBasis: !maskResult
        ? 'Not assessed (no flood-candidate mask active)'
        : exposed
          ? `Intersects/lies within ${rule.bufferDistanceMeters}m of ${hits} flood-candidate cell block(s) — Exposed (structural damage not inferred)`
          : 'Outside flood-candidate mask buffer',
      provenanceStatus: provenance,
    };
  });

  // 2. Evaluate Buildings (Exposure estimate only)
  const buildings: EvaluatedBuildingExposure[] = osmExtract.buildings.map((bldg) => {
    const hits = maskResult
      ? countNearbyCandidateBlocks(
          [[bldg.lat, bldg.lng], ...bldg.footprint],
          candidatePolys,
          rule.bufferDistanceMeters
        )
      : 0;
    return {
      ...bldg,
      exposed: hits > 0,
      provenanceStatus: provenance,
    };
  });

  // 3. Evaluate Roads & Apply Explicit Impassability Rule
  const roads: EvaluatedRoadExposure[] = osmExtract.roads.map((road) => {
    const sampledPts = samplePolylinePoints(road.coordinates);
    const hits = maskResult
      ? countNearbyCandidateBlocks(sampledPts, candidatePolys, rule.bufferDistanceMeters)
      : 0;
    const exposed = hits > 0;

    const hasExposedBridge =
      rule.treatExposedBridgesAsImpassable &&
      bridges.some((br) => br.roadId === road.id && br.exposed);

    const manualOverride = rule.manualRoadOverrides[road.id];
    let markedImpassableByRule = false;
    let ruleReason = 'Passable under current rule assumption';

    if (!maskResult && manualOverride === undefined) {
      markedImpassableByRule = false;
      ruleReason = 'Not assessed (awaiting flood-candidate mask)';
    } else if (manualOverride !== undefined) {
      markedImpassableByRule = manualOverride;
      ruleReason = manualOverride
        ? 'User manual assumption override: Marked impassable'
        : 'User manual assumption override: Marked passable';
    } else if (hits >= rule.minIntersectingCandidateBlocks) {
      markedImpassableByRule = true;
      ruleReason = `Assumed impassable: ${hits} candidate block(s) >= rule threshold (${rule.minIntersectingCandidateBlocks})`;
    } else if (hasExposedBridge) {
      markedImpassableByRule = true;
      ruleReason = 'Assumed impassable: Bridge on segment is exposed to flood-candidate mask';
    }

    return {
      ...road,
      intersectingCandidateUnits: hits,
      exposed,
      markedImpassableByRule,
      ruleReason,
      provenanceStatus: provenance,
    };
  });

  // 4. Evaluate Settlement Isolation on Supplied Road Graph
  const allNodeIds = osmExtract.settlements.map((s) => s.id);
  const townIds = new Set(
    osmExtract.settlements.filter((s) => s.placeType === 'town').map((s) => s.id)
  );
  const hospitalIds = new Set(
    osmExtract.settlements.filter((s) => s.placeType === 'hospital').map((s) => s.id)
  );
  const nodeNameById = new Map(osmExtract.settlements.map((s) => [s.id, s.name]));

  const hasDestinations = townIds.size > 0 || hospitalIds.size > 0;

  const settlements: EvaluatedSettlementIsolation[] = osmExtract.settlements.map((s) => {
    if (!maskResult || !hasDestinations || osmExtract.roads.length === 0) {
      return {
        ...s,
        nearestTownName: null,
        nearestHospitalName: null,
        preEventTownDistKm: null,
        preEventHospitalDistKm: null,
        postEventTownDistKm: null,
        postEventHospitalDistKm: null,
        isolationStatus: 'NOT_ASSESSED',
        limitingCorridor: null,
        assumptionNote: !maskResult
          ? 'Not assessed: Upload/generate a flood-candidate mask first.'
          : 'Not assessed: Supplied OSM extract lacks complete road graph or town/hospital nodes.',
        provenanceStatus: 'not assessed',
      };
    }

    const preTown =
      townIds.size > 0
        ? shortestPathOnGraph(s.id, townIds, allNodeIds, roads, false)
        : { targetId: null, distKm: null, usedRoadNames: [] };
    const preHosp =
      hospitalIds.size > 0
        ? shortestPathOnGraph(s.id, hospitalIds, allNodeIds, roads, false)
        : { targetId: null, distKm: null, usedRoadNames: [] };

    const postTown =
      townIds.size > 0
        ? shortestPathOnGraph(s.id, townIds, allNodeIds, roads, true)
        : { targetId: null, distKm: null, usedRoadNames: [] };
    const postHosp =
      hospitalIds.size > 0
        ? shortestPathOnGraph(s.id, hospitalIds, allNodeIds, roads, true)
        : { targetId: null, distKm: null, usedRoadNames: [] };

    const lostTownAccess = townIds.size > 0 && preTown.distKm !== null && postTown.distKm === null;
    const lostHospAccess =
      hospitalIds.size > 0 && preHosp.distKm !== null && postHosp.distKm === null;
    const isCutOff = lostTownAccess || lostHospAccess;

    const blockedBaselineRoad = roads.find(
      (r) =>
        r.markedImpassableByRule &&
        (preHosp.usedRoadNames.includes(r.name) ||
          preTown.usedRoadNames.includes(r.name) ||
          r.sourceNodeId === s.id ||
          r.targetNodeId === s.id)
    );

    return {
      ...s,
      nearestTownName: preTown.targetId ? nodeNameById.get(preTown.targetId) || null : null,
      nearestHospitalName: preHosp.targetId ? nodeNameById.get(preHosp.targetId) || null : null,
      preEventTownDistKm: preTown.distKm,
      preEventHospitalDistKm: preHosp.distKm,
      postEventTownDistKm: postTown.distKm,
      postEventHospitalDistKm: postHosp.distKm,
      isolationStatus: isCutOff ? 'CANDIDATE_CUT_OFF' : 'REACHABLE_ESTIMATE',
      limitingCorridor: isCutOff
        ? blockedBaselineRoad?.name || 'Downstream graph segment marked impassable by rule'
        : null,
      assumptionNote:
        'Connectivity estimate based strictly on supplied pre-event OSM graph and impassability rule; does not represent live field road conditions.',
      provenanceStatus: provenance,
    };
  });

  if (!maskResult) {
    return {
      status: 'not assessed',
      osmExtractDate: osmExtract.extractTimestampIso,
      osmSourceLabel: osmExtract.sourceLabel,
      ruleDescription,
      exposedBuildingsCount: null,
      totalBuildingsCount: buildings.length,
      exposedRoadsCount: null,
      impassableRoadsCount: null,
      totalRoadsCount: roads.length,
      exposedBridgesCount: null,
      totalBridgesCount: bridges.length,
      candidateCutOffSettlementsCount: null,
      reachableSettlementsCount: null,
      roads,
      bridges,
      buildings,
      settlements,
    };
  }

  return {
    status: provenance,
    osmExtractDate: osmExtract.extractTimestampIso,
    osmSourceLabel: osmExtract.sourceLabel,
    ruleDescription,
    exposedBuildingsCount: buildings.filter((b) => b.exposed).length,
    totalBuildingsCount: buildings.length,
    exposedRoadsCount: roads.filter((r) => r.exposed).length,
    impassableRoadsCount: roads.filter((r) => r.markedImpassableByRule).length,
    totalRoadsCount: roads.length,
    exposedBridgesCount: bridges.filter((b) => b.exposed).length,
    totalBridgesCount: bridges.length,
    candidateCutOffSettlementsCount: settlements.filter(
      (s) => s.isolationStatus === 'CANDIDATE_CUT_OFF'
    ).length,
    reachableSettlementsCount: settlements.filter(
      (s) => s.isolationStatus === 'REACHABLE_ESTIMATE'
    ).length,
    roads,
    bridges,
    buildings,
    settlements,
  };
}

/**
 * Parse a user-uploaded dated pre-event OSM GeoJSON extract.
 * Rejects extracts that lack a valid pre-event extract_date or claim current/post-event OSM as pre-event.
 */
export function parseDatedPreEventOsmGeoJson(
  jsonText: string,
  fileName: string,
  eventDateStr: string
): DatedPreEventOsmExtract {
  let parsed: Record<string, unknown>;
  try {
    parsed = JSON.parse(jsonText);
  } catch {
    throw new Error(`Invalid JSON in "${fileName}". Expected a dated pre-event OpenStreetMap GeoJSON extract.`);
  }

  const extractDateStr = String(
    parsed.extract_date || parsed.extractTimestampIso || parsed.timestamp || ''
  ).trim();

  if (!extractDateStr) {
    throw new Error(
      `Rejected OSM file "${fileName}": Missing top-level "extract_date" or "timestamp" metadata. Current or undated OpenStreetMap data cannot be treated as pre-event OSM.`
    );
  }

  if (extractDateStr.slice(0, 10) >= eventDateStr.slice(0, 10)) {
    throw new Error(
      `Rejected OSM file "${fileName}": Declared extract date (${extractDateStr.slice(0, 10)}) is not prior to the flood event date (${eventDateStr.slice(0, 10)}). Post-event OSM edits are prohibited.`
    );
  }

  const settlements: OsmSettlementNode[] = Array.isArray(parsed.settlements)
    ? (parsed.settlements as OsmSettlementNode[])
    : [];
  const roads: OsmRoadSegment[] = Array.isArray(parsed.roads)
    ? (parsed.roads as OsmRoadSegment[])
    : [];
  const bridges: OsmBridgeAsset[] = Array.isArray(parsed.bridges)
    ? (parsed.bridges as OsmBridgeAsset[])
    : [];
  const buildings: OsmBuildingAsset[] = Array.isArray(parsed.buildings)
    ? (parsed.buildings as OsmBuildingAsset[])
    : [];

  return {
    fileName,
    extractTimestampIso: extractDateStr,
    sourceLabel: String(parsed.source_label || `Uploaded Dated Pre-Event OSM (${fileName})`),
    provenanceStatus: 'uploaded',
    isProvisionalOrMissingAttributes: settlements.length === 0 || roads.length === 0,
    settlements,
    roads,
    bridges,
    buildings,
  };
}

/**
 * Create a clearly marked "synthetic demo" pre-event OSM extract matching the synthetic
 * UTM Zone 45N GeoTIFF bounds (~[28.200..28.233 N, 85.311..85.349 E]).
 * Explicitly tagged as "synthetic demo" and never mixed with real Trishuli case-study results.
 */
export function buildSyntheticDemoOsmExtract(): DatedPreEventOsmExtract {
  return {
    fileName: 'SYNTHETIC_DEMO_PRE_EVENT_OSM_2026-08-01.json',
    extractTimestampIso: '2026-08-01T00:00:00Z',
    sourceLabel: 'Synthetic Demo Pre-Event OSM Extract (Marked: synthetic demo)',
    provenanceStatus: 'synthetic demo',
    isProvisionalOrMissingAttributes: false,
    settlements: [
      {
        id: 'syn_node_upper_village',
        osmId: 'synthetic/node/101',
        name: 'Synthetic Upper Gorge Hamlet [SYNTHETIC]',
        placeType: 'settlement',
        lat: 28.228,
        lng: 85.331,
        population: null, // Not invented
      },
      {
        id: 'syn_node_river_terrace',
        osmId: 'synthetic/node/102',
        name: 'Synthetic River Terrace Settlement [SYNTHETIC]',
        placeType: 'settlement',
        lat: 28.217,
        lng: 85.329,
        population: null,
      },
      {
        id: 'syn_node_west_ridge',
        osmId: 'synthetic/node/103',
        name: 'Synthetic West Ridge Village [SYNTHETIC]',
        placeType: 'settlement',
        lat: 28.214,
        lng: 85.316,
        population: null,
      },
      {
        id: 'syn_node_town',
        osmId: 'synthetic/node/104',
        name: 'Synthetic Hub Town [SYNTHETIC]',
        placeType: 'town',
        lat: 28.204,
        lng: 85.318,
        population: null,
      },
      {
        id: 'syn_node_hospital',
        osmId: 'synthetic/node/105',
        name: 'Synthetic District Clinic [SYNTHETIC]',
        placeType: 'hospital',
        lat: 28.203,
        lng: 85.315,
        population: null,
      },
    ],
    roads: [
      {
        id: 'syn_road_valley_north',
        osmId: 'synthetic/way/201',
        name: 'Synthetic Valley Floor Road (North) [SYNTHETIC]',
        highwayClass: 'secondary',
        sourceNodeId: 'syn_node_upper_village',
        targetNodeId: 'syn_node_river_terrace',
        lengthKm: 1.35,
        coordinates: [
          [28.228, 85.331],
          [28.222, 85.33],
          [28.217, 85.329],
        ],
      },
      {
        id: 'syn_road_valley_south',
        osmId: 'synthetic/way/202',
        name: 'Synthetic Valley Floor Road (South Crossing) [SYNTHETIC]',
        highwayClass: 'secondary',
        sourceNodeId: 'syn_node_river_terrace',
        targetNodeId: 'syn_node_town',
        lengthKm: 1.85,
        coordinates: [
          [28.217, 85.329],
          [28.211, 85.326],
          [28.204, 85.318],
        ],
      },
      {
        id: 'syn_road_west_ridge',
        osmId: 'synthetic/way/203',
        name: 'Synthetic High Ridge Road [SYNTHETIC]',
        highwayClass: 'tertiary',
        sourceNodeId: 'syn_node_west_ridge',
        targetNodeId: 'syn_node_town',
        lengthKm: 1.2,
        coordinates: [
          [28.214, 85.316],
          [28.209, 85.317],
          [28.204, 85.318],
        ],
      },
      {
        id: 'syn_road_hosp_link',
        osmId: 'synthetic/way/204',
        name: 'Synthetic Clinic Access Road [SYNTHETIC]',
        highwayClass: 'residential',
        sourceNodeId: 'syn_node_town',
        targetNodeId: 'syn_node_hospital',
        lengthKm: 0.4,
        coordinates: [
          [28.204, 85.318],
          [28.203, 85.315],
        ],
      },
    ],
    bridges: [
      {
        id: 'syn_bridge_1',
        osmId: 'synthetic/way/301',
        name: 'Synthetic Gorge Crossing Bridge [SYNTHETIC]',
        roadId: 'syn_road_valley_south',
        roadName: 'Synthetic Valley Floor Road (South Crossing) [SYNTHETIC]',
        lat: 28.215,
        lng: 85.328,
        spanM: 65,
      },
    ],
    buildings: [
      {
        id: 'syn_bldg_1',
        osmId: 'synthetic/way/401',
        name: 'Synthetic Riverside Structure A [SYNTHETIC]',
        buildingClass: 'yes',
        lat: 28.221,
        lng: 85.33,
        footprint: [
          [28.2206, 85.3296],
          [28.2206, 85.3304],
          [28.2214, 85.3304],
          [28.2214, 85.3296],
        ],
      },
      {
        id: 'syn_bldg_2',
        osmId: 'synthetic/way/402',
        name: 'Synthetic Riverside Structure B [SYNTHETIC]',
        buildingClass: 'yes',
        lat: 28.216,
        lng: 85.329,
        footprint: [
          [28.2156, 85.3286],
          [28.2156, 85.3294],
          [28.2164, 85.3294],
          [28.2164, 85.3286],
        ],
      },
      {
        id: 'syn_bldg_3',
        osmId: 'synthetic/way/403',
        name: 'Synthetic High Ridge Structure C [SYNTHETIC]',
        buildingClass: 'yes',
        lat: 28.214,
        lng: 85.316,
        footprint: [
          [28.2136, 85.3156],
          [28.2136, 85.3164],
          [28.2144, 85.3164],
          [28.2144, 85.3156],
        ],
      },
    ],
  };
}

/**
 * Build a deterministic, zero-hallucination One-Page Situation Report.
 * Every item states its source, date, and provenance status ("uploaded", "catalog result",
 * "derived estimate", "synthetic demo", or "not assessed").
 */
export function buildOnePageSituationReport(params: {
  studyArea: StudyAreaConfig;
  maskResult: WaterCandidateMaskResult | null;
  infraSummary: InfrastructureAndIsolationSummary;
  aiModel: InstalledAiModelManifest | null;
  frozenSnapshot: FrozenOutputSnapshot | null;
}): string {
  const { studyArea, maskResult, infraSummary, aiModel, frozenSnapshot } = params;

  const isSynthetic =
    studyArea.mode === 'SYNTHETIC_DEMO' ||
    maskResult?.sourceStatus === 'synthetic demo' ||
    infraSummary.status === 'synthetic demo';

  const modeBanner = isSynthetic
    ? 'SYNTHETIC DEMO MODE — Contains synthetic test data. Do not mix with or cite as real Trishuli case-study findings.'
    : 'CASE STUDY / OPERATIONAL WORKSPACE — Unsupplied layers and unverified metrics are strictly reported as "not assessed".';

  const maskSection = maskResult
    ? [
        `• Method Label: ${maskResult.methodLabel} [Status: ${maskResult.sourceStatus}]`,
        `• Threshold Parameters: Post-event <= ${maskResult.thresholdDb.toFixed(1)} dB, Pre-event > ${maskResult.thresholdDb.toFixed(1)} dB, Min drop <= -${maskResult.minDropDb.toFixed(1)} dB`,
        `• Valid Evaluated Pixels: ${maskResult.validEvaluatedPixels.toLocaleString()} (${maskResult.width}×${maskResult.height} grid)`,
        `• New Low-Backscatter Water-Candidate Pixels: ${maskResult.newCandidatePixels.toLocaleString()} pixels`,
        `• Defensible Metric Area: ${
          maskResult.areaDefensible && maskResult.newCandidateAreaSqKm !== null
            ? `${maskResult.newCandidateAreaSqKm.toFixed(4)} sq km (${maskResult.newCandidateAreaSqM?.toLocaleString()} sq m) — ${maskResult.areaDefensibleReason}`
            : `Not assessed (${maskResult.areaDefensibleReason})`
        }`,
      ].join('\n')
    : '• Status: not assessed (Upload co-registered pre-event and post-event Sentinel-1 VV dB GeoTIFFs to compute water-candidate mask).';

  const aiSection = aiModel
    ? [
        `• Model Status: Installed (${aiModel.modelName}) [Status: ${aiModel.provenanceStatus}]`,
        `• Weights & Manifest: ${aiModel.weightsFileName} / ${aiModel.metadataFileName}`,
        `• Training Dataset & License: ${aiModel.datasetSource} (${aiModel.datasetLicense})`,
        `• Split Strategy: ${aiModel.splitStrategy} (Disjoint Verified: ${aiModel.splitVerifiedDisjoint ? 'Yes' : 'No'})`,
        `• Recorded Held-Out Metrics: IoU=${aiModel.heldOutMetrics.iou ?? 'not assessed'}, F1=${aiModel.heldOutMetrics.f1Score ?? 'not assessed'}`,
      ].join('\n')
    : '• Status: AI model not installed [not assessed]. Using separate dB threshold baseline only.';

  const infraSection =
    infraSummary.status !== 'not assessed'
      ? [
          `• Pre-Event OSM Source: ${infraSummary.osmSourceLabel} (Extract Date: ${infraSummary.osmExtractDate}) [Status: ${infraSummary.status}]`,
          `• Exposed Buildings (Intersection Estimate, NOT confirmed structural damage): ${infraSummary.exposedBuildingsCount} of ${infraSummary.totalBuildingsCount}`,
          `• Exposed Road Segments: ${infraSummary.exposedRoadsCount} of ${infraSummary.totalRoadsCount}`,
          `• Roads Marked Impassable by Rule Assumption: ${infraSummary.impassableRoadsCount} of ${infraSummary.totalRoadsCount}`,
          `• Exposed Bridges (Exposure only, structural integrity not assessed): ${infraSummary.exposedBridgesCount} of ${infraSummary.totalBridgesCount}`,
          `• Impassability Rule Assumption: ${infraSummary.ruleDescription}`,
        ].join('\n')
      : `• Status: not assessed (${infraSummary.osmSourceLabel}). Require a dated pre-event OSM extract and active water-candidate mask.`;

  const cutoffNodes = infraSummary.settlements.filter(
    (s) => s.isolationStatus === 'CANDIDATE_CUT_OFF'
  );

  const isolationSection =
    infraSummary.status !== 'not assessed'
      ? [
          `• Candidate Cut-Off Settlements: ${infraSummary.candidateCutOffSettlementsCount} [Status: ${infraSummary.status}]`,
          `• Reachable Settlements (Graph Estimate): ${infraSummary.reachableSettlementsCount}`,
          ...(cutoffNodes.length > 0
            ? cutoffNodes.map(
                (c) =>
                  `  - ${c.name}: Candidate Cut-Off from ${c.nearestTownName || 'nearest town'} / ${c.nearestHospitalName || 'nearest hospital'} (Assumed blocked corridor: ${c.limitingCorridor})`
              )
            : ['  - No candidate cut-off settlements identified under current graph assumptions.']),
        ].join('\n')
      : '• Status: not assessed (Requires dated pre-event OSM road graph, town/hospital nodes, and flood-candidate mask).';

  return `TERRARESQ — ONE-PAGE FLOOD EXPOSURE & ISOLATION SITUATION REPORT
================================================================================
${modeBanner}
Study Area: ${studyArea.areaName}
Event Date: ${studyArea.eventDate} | Pre-Event Baseline Window: ${studyArea.preEventWindowStart}
Workspace Mode: ${studyArea.mode}
================================================================================

1. SATELLITE WATER-CANDIDATE BASELINE (Not AI & Not Validated)
${maskSection}

2. AI FLOOD SEGMENTATION PATHWAY
${aiSection}

3. PRE-EVENT OPENSTREETMAP INFRASTRUCTURE EXPOSURE ESTIMATES
${infraSection}

4. CANDIDATE SETTLEMENT ISOLATION (ROAD GRAPH ESTIMATES)
${isolationSection}

5. VALIDATION SEPARATION STATUS (EMSR927)
• Output Freeze Status: ${
    frozenSnapshot
      ? `Frozen at ${frozenSnapshot.frozenAtIso} (Hash: ${frozenSnapshot.frozenHash})`
      : 'Not frozen yet — Freeze model/baseline outputs and parameters before comparing with EMSR927.'
  }
• Validation Rule: EMSR927 is strictly reserved for post-hoc validation only and never used as a model input, training label, tuning target, or inference feature.

6. DATA INTEGRITY & LIMITATIONS
• Exposure vs. Damage: Spatial intersection with a water-candidate mask indicates exposure only and does not prove structural damage to buildings, roads, or bridges.
• Graph Assumptions: Connectivity estimates depend on the completeness of the supplied pre-event OSM road network and the user-configured impassability rule; they do not represent live road conditions.
• Attribution: Contains modified Copernicus Sentinel data 2026 · Copernicus WorldDEM-30 · © OpenStreetMap contributors.`;
}
