/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import {
  InfrastructureAndIsolationSummary,
  StudyAreaConfig,
  WaterCandidateMaskResult,
} from '../types/terraresq';

export type GeoJsonExportScope =
  | 'COMBINED'
  | 'FLOOD_MASK_ONLY'
  | 'IMPASSABLE_ROADS_ONLY';

export interface GeoJsonExportSummary {
  floodPolygonCount: number;
  floodAreaSqKm: number | null;
  impassableRoadCount: number;
  impassableRoadLengthKm: number;
  totalFeatures: number;
}

/**
 * Build an RFC 7946 compliant GeoJSON FeatureCollection containing
 * the current flooded area candidate mask and/or impassable road segments.
 */
export function generateTerraResQGeoJson(
  maskResult: WaterCandidateMaskResult | null,
  infraSummary: InfrastructureAndIsolationSummary,
  studyArea: StudyAreaConfig,
  scope: GeoJsonExportScope = 'COMBINED'
): { geoJson: Record<string, unknown>; summary: GeoJsonExportSummary } {
  const features: Array<Record<string, unknown>> = [];

  let floodPolygonCount = 0;
  let impassableRoadCount = 0;
  let impassableRoadLengthKm = 0;

  // 1. Process Flooded Area Candidate Mask Polygons
  if (scope === 'COMBINED' || scope === 'FLOOD_MASK_ONLY') {
    if (maskResult && maskResult.candidatePolygonsWgs84 && maskResult.candidatePolygonsWgs84.length > 0) {
      maskResult.candidatePolygonsWgs84.forEach((poly, idx) => {
        if (!poly || poly.length < 3) return;

        // Leaflet/WGS84 internal coords are [lat, lng].
        // GeoJSON standard (RFC 7946) requires [longitude, latitude].
        const ring: [number, number][] = poly.map(([lat, lng]) => [
          Number(lng.toFixed(6)),
          Number(lat.toFixed(6)),
        ]);

        // Ensure linear ring is closed (first coordinate matches last coordinate)
        if (
          ring.length > 0 &&
          (ring[0][0] !== ring[ring.length - 1][0] || ring[0][1] !== ring[ring.length - 1][1])
        ) {
          ring.push([ring[0][0], ring[0][1]]);
        }

        if (ring.length >= 4) {
          floodPolygonCount++;
          features.push({
            type: 'Feature',
            id: `flood_candidate_${idx + 1}`,
            geometry: {
              type: 'Polygon',
              coordinates: [ring],
            },
            properties: {
              layer: 'flooded_area_candidate_mask',
              featureIndex: idx + 1,
              classification: 'water_candidate_low_backscatter',
              provenanceStatus: maskResult.sourceStatus,
              methodologyLabel: maskResult.methodLabel,
              thresholdDb: maskResult.thresholdDb,
              minDropDb: maskResult.minDropDb,
              areaDefensible: maskResult.areaDefensible,
              pixelResolutionM: maskResult.pixelScale ? maskResult.pixelScale[0] : 10,
              totalDetectedCandidatePixels: maskResult.newCandidatePixels,
              totalCandidateAreaSqKm: maskResult.newCandidateAreaSqKm,
              sensorInput: 'Sentinel-1 SAR C-band VV (dB)',
            },
          });
        }
      });
    }
  }

  // 2. Process Impassable Road Segments
  if (scope === 'COMBINED' || scope === 'IMPASSABLE_ROADS_ONLY') {
    const impassableRoads = (infraSummary.roads || []).filter(
      (r) => r.markedImpassableByRule
    );

    impassableRoads.forEach((road) => {
      if (!road.coordinates || road.coordinates.length < 2) return;

      impassableRoadCount++;
      impassableRoadLengthKm += road.lengthKm || 0;

      // Road coordinates are [lat, lng], convert to [longitude, latitude]
      const coords: [number, number][] = road.coordinates.map(([lat, lng]) => [
        Number(lng.toFixed(6)),
        Number(lat.toFixed(6)),
      ]);

      features.push({
        type: 'Feature',
        id: `road_${road.id}`,
        geometry: {
          type: 'LineString',
          coordinates: coords,
        },
        properties: {
          layer: 'impassable_road_segments',
          osmId: road.osmId,
          roadName: road.name || 'Unnamed Segment',
          highwayClass: road.highwayClass,
          lengthKm: Number((road.lengthKm || 0).toFixed(3)),
          markedImpassableByRule: true,
          graphRuleReason: road.ruleReason,
          intersectingCandidateUnits: road.intersectingCandidateUnits,
          exposed: road.exposed,
          sourceNodeId: road.sourceNodeId,
          targetNodeId: road.targetNodeId,
          provenanceStatus: road.provenanceStatus,
          networkAssumption: 'Assumed impassable by SAR flood intersection buffer rule',
        },
      });
    });
  }

  const summary: GeoJsonExportSummary = {
    floodPolygonCount,
    floodAreaSqKm: maskResult?.newCandidateAreaSqKm ?? null,
    impassableRoadCount,
    impassableRoadLengthKm: Number(impassableRoadLengthKm.toFixed(2)),
    totalFeatures: features.length,
  };

  const geoJson = {
    type: 'FeatureCollection',
    name: `TerraResQ_${studyArea.areaName.replace(/\s+/g, '_')}_${scope}`,
    crs: {
      type: 'name',
      properties: {
        name: 'urn:ogc:def:crs:OGC:1.3:CRS84',
      },
    },
    metadata: {
      title: 'TerraResQ Flood Intelligence GIS Export',
      studyAreaName: studyArea.areaName,
      eventDate: studyArea.eventDate,
      bboxWgs84: studyArea.bbox,
      exportScope: scope,
      exportedAtIso: new Date().toISOString(),
      generator: 'TerraResQ Multimodal AI Flood Mapping System',
      totalFeatures: features.length,
      floodCandidatePolygonsCount: floodPolygonCount,
      estimatedFloodAreaSqKm: maskResult?.newCandidateAreaSqKm ?? null,
      impassableRoadSegmentsCount: impassableRoadCount,
      totalImpassableRoadLengthKm: summary.impassableRoadLengthKm,
      disclaimer:
        'Derived rapid assessment model outputs. Copernicus EMSR927 should be used as reference. Not an authoritative civil protection ground-truth.',
    },
    features,
  };

  return { geoJson, summary };
}

/**
 * Triggers a client-side download of the GeoJSON data as a .geojson file.
 */
export function triggerGeoJsonDownload(
  geoJsonObject: Record<string, unknown>,
  suggestedFileName: string
): void {
  const jsonString = JSON.stringify(geoJsonObject, null, 2);
  const blob = new Blob([jsonString], { type: 'application/geo+json;charset=utf-8;' });
  const url = URL.createObjectURL(blob);

  const anchor = document.createElement('a');
  anchor.href = url;
  anchor.download = suggestedFileName.endsWith('.geojson')
    ? suggestedFileName
    : `${suggestedFileName}.geojson`;

  document.body.appendChild(anchor);
  anchor.click();
  document.body.removeChild(anchor);

  // Release memory
  setTimeout(() => {
    URL.revokeObjectURL(url);
  }, 1000);
}
