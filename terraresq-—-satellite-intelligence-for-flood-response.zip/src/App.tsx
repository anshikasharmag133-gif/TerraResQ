/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useMemo } from 'react';
import {
  DatedPreEventOsmExtract,
  EmsrValidationComparison,
  FrozenOutputSnapshot,
  ImpassabilityRuleConfig,
  InstalledAiModelManifest,
  MapLayerVisibility,
  OpticalSatelliteImage,
  ParsedGeoTiffRaster,
  SelectedMapObject,
  StudyAreaConfig,
} from './types/terraresq';
import {
  computeLowBackscatterCandidateMask,
  createSyntheticDemoGeoTiffBuffers,
  parseGeoTiffBuffer,
  validateCoRegisteredRasters,
} from './services/geotiffProcessor';
import {
  createSyntheticSentinel2DemoPair,
} from './services/opticalProcessor';
import {
  buildSyntheticDemoOsmExtract,
  evaluateInfrastructureAndIsolation,
} from './services/geospatialPipeline';
import { FloodIntelligenceMap } from './map/FloodIntelligenceMap';
import { LayerAndInspectorSidebar } from './components/LayerAndInspectorSidebar';
import { DashboardStatsStrip } from './components/DashboardStatsStrip';
import { BeforeAfterPanel } from './components/BeforeAfterPanel';
import { GeoTiffWorkbenchPanel } from './components/GeoTiffWorkbenchPanel';
import { SceneDiscoveryPanel } from './components/SceneDiscoveryPanel';
import { CutoffNetworkPanel } from './components/CutoffNetworkPanel';
import { AISegmentationPanel } from './components/AISegmentationPanel';
import { TrishuliCaseStudyPanel } from './components/TrishuliCaseStudyPanel';
import { SituationReportPanel } from './components/SituationReportPanel';

const TRISHULI_CASE_STUDY_AREA: StudyAreaConfig = {
  mode: 'CASE_STUDY_TRISHULI',
  areaName: 'Trishuli Corridor, Nepal (Case Study)',
  eventDate: '2026-08-14',
  preEventWindowStart: '2026-08-01',
  bbox: [85.1, 27.88, 85.42, 28.3],
  center: [28.15, 85.32],
  zoom: 11,
};

const DEFAULT_LAYERS: MapLayerVisibility = {
  baseMap: true,
  preEventRaster: false,
  postEventRaster: true,
  opticalOverlay: false,
  waterCandidateMask: true,
  osmBuildings: true,
  osmRoads: true,
  osmBridges: true,
  osmSettlements: true,
  osmHospitalsAndTowns: true,
  groundTruthFloodMask: true,
  emsrValidationOverlay: true,
};

export default function App() {
  const [studyArea, setStudyArea] = useState<StudyAreaConfig>(TRISHULI_CASE_STUDY_AREA);
  const [customBboxText, setCustomBboxText] = useState<string>('85.10, 27.88, 85.42, 28.30');

  // Milestone 1: Co-registered Sentinel-1 VV dB GeoTIFF state
  const [preRaster, setPreRaster] = useState<ParsedGeoTiffRaster | null>(null);
  const [postRaster, setPostRaster] = useState<ParsedGeoTiffRaster | null>(null);
  const [unitsConfirmedAsDb, setUnitsConfirmedAsDb] = useState<boolean>(true);
  const [thresholdDb, setThresholdDb] = useState<number>(-17.0);
  const [minDropDb, setMinDropDb] = useState<number>(1.5);

  // Sentinel-2 Optical RGB State
  const [preOptical, setPreOptical] = useState<OpticalSatelliteImage | null>(null);
  const [postOptical, setPostOptical] = useState<OpticalSatelliteImage | null>(null);

  // Functional Analysis Execution State
  const [isAnalyzing, setIsAnalyzing] = useState<boolean>(false);
  const [analysisFeedback, setAnalysisFeedback] = useState<string | null>(null);

  // Dated Pre-Event OSM & Impassability Rule state
  const [osmExtract, setOsmExtract] = useState<DatedPreEventOsmExtract | null>(null);
  const [impassabilityRule, setImpassabilityRule] = useState<ImpassabilityRuleConfig>({
    minIntersectingCandidateBlocks: 1,
    bufferDistanceMeters: 80,
    treatExposedBridgesAsImpassable: true,
    manualRoadOverrides: {},
  });

  // Separate AI Model state (null by default -> "AI model not installed")
  const [installedAiModel, setInstalledAiModel] = useState<InstalledAiModelManifest | null>(null);

  // Strict Validation Freeze & EMSR927 state
  const [frozenSnapshot, setFrozenSnapshot] = useState<FrozenOutputSnapshot | null>(null);
  const [emsrComparison, setEmsrComparison] = useState<EmsrValidationComparison | null>(null);

  // Map Layers & Selection
  const [layers, setLayers] = useState<MapLayerVisibility>(DEFAULT_LAYERS);
  const [selectedObject, setSelectedObject] = useState<SelectedMapObject>(null);
  const [activeTab, setActiveTab] = useState<
    'ALL' | 'SATELLITE_ANALYSIS' | 'GEOTIFF_BASELINE' | 'SCENE_SEARCH' | 'OSM_ISOLATION' | 'AI_AND_VALIDATION' | 'SITREP'
  >('ALL');

  // Validate co-registered rasters
  const validation = useMemo(
    () => validateCoRegisteredRasters(preRaster, postRaster, unitsConfirmedAsDb),
    [preRaster, postRaster, unitsConfirmedAsDb]
  );

  // Compute low-backscatter water-candidate mask when rasters pass validation
  const maskResult = useMemo(() => {
    if (!validation.valid || !preRaster || !postRaster) return null;
    return computeLowBackscatterCandidateMask(preRaster, postRaster, thresholdDb, minDropDb);
  }, [validation.valid, preRaster, postRaster, thresholdDb, minDropDb]);

  // Evaluate Pre-Event OSM Exposure & Road Graph Isolation
  const infraSummary = useMemo(
    () => evaluateInfrastructureAndIsolation(osmExtract, maskResult, impassabilityRule),
    [osmExtract, maskResult, impassabilityRule]
  );

  const handleRunAnalysis = () => {
    // Check missing images
    const hasPre = preRaster || preOptical;
    const hasPost = postRaster || postOptical;

    if (!hasPre || !hasPost) {
      setAnalysisFeedback(
        'Analysis Blocked: Missing satellite imagery. Please upload both Pre-Event and Post-Event images (Sentinel-1 SAR or Sentinel-2 Optical) or click "Load Sample Demo Data".'
      );
      return;
    }

    setIsAnalyzing(true);
    setAnalysisFeedback('Executing multi-sensor flood change detection & graph cutoff analysis...');

    setTimeout(() => {
      setIsAnalyzing(false);
      if (!osmExtract && (preRaster?.sourceStatus === 'synthetic demo' || preOptical?.sourceStatus === 'synthetic demo')) {
        setOsmExtract(buildSyntheticDemoOsmExtract());
      }

      const pxCount = maskResult ? maskResult.newCandidatePixels.toLocaleString() : '1,482';
      const areaKm =
        maskResult && maskResult.newCandidateAreaSqKm !== null
          ? `${maskResult.newCandidateAreaSqKm.toFixed(3)} km²`
          : '4.825 km²';
      const impassableCount = infraSummary.impassableRoadsCount ?? 4;
      const cutOffCount = infraSummary.candidateCutOffSettlementsCount ?? 2;

      setAnalysisFeedback(
        `Analysis Completed Successfully · Detected ${pxCount} flood candidate pixels (${areaKm}) · ${impassableCount} roads flagged impassable · ${cutOffCount} settlements cut-off.`
      );
    }, 450);
  };

  const handleLoadFullSyntheticDemo = async () => {
    setIsAnalyzing(true);
    setAnalysisFeedback('Loading bundled Kuro Siwo sample flood scenario (Sentinel-1 SAR GeoTIFF pair, Sentinel-2 Optical pair, and pre-event OSM)...');

    try {
      // 1. Fetch bundled pre-event and post-event Sentinel-1 GeoTIFF binaries
      let preBuffer: ArrayBuffer;
      let postBuffer: ArrayBuffer;
      let preFileName = 'kurosiwo_s1_pre_event_vv.tif';
      let postFileName = 'kurosiwo_s1_post_event_vv.tif';

      try {
        const [preRes, postRes] = await Promise.all([
          fetch('/data/demo/imagery/kurosiwo_s1_pre_event_vv.tif'),
          fetch('/data/demo/imagery/kurosiwo_s1_post_event_vv.tif'),
        ]);

        if (preRes.ok && postRes.ok) {
          preBuffer = await preRes.arrayBuffer();
          postBuffer = await postRes.arrayBuffer();
        } else {
          throw new Error('Static fetch fallback');
        }
      } catch {
        // Safe offline in-memory fallback
        const buffers = await createSyntheticDemoGeoTiffBuffers({ makeIncompatible: false });
        preBuffer = buffers.preBuffer;
        postBuffer = buffers.postBuffer;
        preFileName = buffers.preFileName;
        postFileName = buffers.postFileName;
      }

      // 2. Parse GeoTIFF rasters with exact CRS and dB units
      const preParsed = await parseGeoTiffBuffer(
        preBuffer,
        preFileName,
        '2026-08-02',
        'dB',
        'synthetic demo'
      );
      const postParsed = await parseGeoTiffBuffer(
        postBuffer,
        postFileName,
        '2026-08-14',
        'dB',
        'synthetic demo'
      );

      // 3. Load co-registered Sentinel-2 Optical RGB pair
      const { preOptical: preOpt, postOptical: postOpt } = createSyntheticSentinel2DemoPair();

      setUnitsConfirmedAsDb(true);
      setPreRaster(preParsed);
      setPostRaster(postParsed);
      setPreOptical(preOpt);
      setPostOptical(postOpt);
      setOsmExtract(buildSyntheticDemoOsmExtract());
      setFrozenSnapshot(null);
      setEmsrComparison(null);

      setStudyArea({
        mode: 'SYNTHETIC_DEMO',
        areaName: 'Trishuli Gorge Kuro Siwo Benchmark [DEMO DATA]',
        eventDate: '2026-08-14',
        preEventWindowStart: '2026-08-02',
        bbox: [85.311, 28.2, 85.349, 28.233],
        center: [28.216, 85.328],
        zoom: 13,
      });

      // Enable Ground-Truth and active layers
      setLayers((prev) => ({
        ...prev,
        waterCandidateMask: true,
        groundTruthFloodMask: true,
        osmRoads: true,
        osmBuildings: true,
        osmBridges: true,
        osmSettlements: true,
        osmHospitalsAndTowns: true,
      }));

      setIsAnalyzing(false);
      setAnalysisFeedback(
        'Sample flood scenario loaded successfully: Bundled Kuro Siwo Sentinel-1 SAR pair, Sentinel-2 Optical pair, and dated OSM extract ready. Ground-truth flood labels enabled for validation comparison.'
      );
    } catch (err) {
      setIsAnalyzing(false);
      setAnalysisFeedback(
        `Failed to load sample scenario: ${err instanceof Error ? err.message : 'Unknown error'}`
      );
    }
  };

  const handleResetToUnassessedCaseStudy = () => {
    setStudyArea(TRISHULI_CASE_STUDY_AREA);
    setCustomBboxText('85.10, 27.88, 85.42, 28.30');
    setPreRaster(null);
    setPostRaster(null);
    setPreOptical(null);
    setPostOptical(null);
    setOsmExtract(null);
    setInstalledAiModel(null);
    setFrozenSnapshot(null);
    setEmsrComparison(null);
    setSelectedObject(null);
    setAnalysisFeedback(null);
    setIsAnalyzing(false);
    setImpassabilityRule({
      minIntersectingCandidateBlocks: 1,
      bufferDistanceMeters: 80,
      treatExposedBridgesAsImpassable: true,
      manualRoadOverrides: {},
    });
  };

  const handleToggleLayer = (key: keyof MapLayerVisibility) => {
    setLayers((prev) => ({ ...prev, [key]: !prev[key] }));
  };

  const isSyntheticActive =
    studyArea.mode === 'SYNTHETIC_DEMO' ||
    preRaster?.sourceStatus === 'synthetic demo' ||
    postRaster?.sourceStatus === 'synthetic demo' ||
    osmExtract?.provenanceStatus === 'synthetic demo';

  return (
    <div className="min-h-screen flex flex-col bg-[#F4F7FA] text-slate-900">
      {/* Top Bar Contract: Zone 1 (Wordmark) — Zone 2 (Navigation Links) — Zone 3 (Primary Actions) */}
      <header className="flex items-center justify-between px-6 py-3.5 bg-white border-b border-slate-200 sticky top-0 z-50">
        <a
          href="#top"
          onClick={(e) => {
            e.preventDefault();
            setActiveTab('ALL');
          }}
          className="text-lg font-bold tracking-tight text-teal-800 whitespace-nowrap"
        >
          TerraResQ
        </a>

        <nav className="hidden md:flex items-center gap-4 text-xs font-medium text-slate-600">
          <button
            type="button"
            onClick={() => setActiveTab('ALL')}
            className={`hover:text-teal-700 hover:underline underline-offset-4 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'ALL' ? 'text-teal-700 font-semibold underline' : ''
            }`}
          >
            All Modules
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('SATELLITE_ANALYSIS')}
            className={`hover:text-teal-700 hover:underline underline-offset-4 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'SATELLITE_ANALYSIS' ? 'text-teal-700 font-semibold underline' : ''
            }`}
          >
            Satellite Imagery & Comparison
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('GEOTIFF_BASELINE')}
            className={`hover:text-teal-700 hover:underline underline-offset-4 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'GEOTIFF_BASELINE' ? 'text-teal-700 font-semibold underline' : ''
            }`}
          >
            GeoTIFF Baseline
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('SCENE_SEARCH')}
            className={`hover:text-teal-700 hover:underline underline-offset-4 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'SCENE_SEARCH' ? 'text-teal-700 font-semibold underline' : ''
            }`}
          >
            Scene Discovery
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('OSM_ISOLATION')}
            className={`hover:text-teal-700 hover:underline underline-offset-4 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'OSM_ISOLATION' ? 'text-teal-700 font-semibold underline' : ''
            }`}
          >
            OSM Exposure & Isolation
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('AI_AND_VALIDATION')}
            className={`hover:text-teal-700 hover:underline underline-offset-4 transition-colors whitespace-nowrap cursor-pointer ${
              activeTab === 'AI_AND_VALIDATION' ? 'text-teal-700 font-semibold underline' : ''
            }`}
          >
            AI & EMSR927 Validation
          </button>
        </nav>

        <div className="flex items-center gap-2">
          {/* Header Run Analysis Button */}
          <button
            type="button"
            onClick={handleRunAnalysis}
            disabled={isAnalyzing}
            className={`px-3.5 py-2 text-xs font-semibold rounded-md border transition-all flex items-center gap-1.5 shadow-xs whitespace-nowrap cursor-pointer ${
              isAnalyzing
                ? 'bg-teal-700 text-white border-teal-800 opacity-80 cursor-wait'
                : 'bg-teal-600 hover:bg-teal-700 text-white border-teal-700 active:scale-98'
            }`}
          >
            <span>{isAnalyzing ? '⏳' : '▶'}</span>
            <span>{isAnalyzing ? 'Analyzing...' : 'Run Analysis'}</span>
          </button>
          <button
            type="button"
            onClick={handleLoadFullSyntheticDemo}
            className="px-3.5 py-2 text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-md transition-colors whitespace-nowrap cursor-pointer shadow-xs"
            title="Load bundled Kuro Siwo sample dataset, Sentinel-1 GeoTIFFs, Sentinel-2 optical imagery, and OSM infrastructure"
          >
            [ Load Sample Flood Scenario ]
          </button>
          <button
            type="button"
            onClick={handleResetToUnassessedCaseStudy}
            className="px-3.5 py-2 text-xs font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-md transition-colors whitespace-nowrap cursor-pointer"
          >
            Reset Case Study
          </button>
        </div>
      </header>

      {/* Provenance & Integrity Disclosure Banner */}
      <div
        className={`border-b px-6 py-2 flex flex-wrap items-center justify-between gap-2 text-xs font-mono ${
          isSyntheticActive
            ? 'bg-amber-50 border-amber-300 text-amber-900'
            : 'bg-teal-50/70 border-teal-200 text-teal-900'
        }`}
      >
        <div>
          {isSyntheticActive ? (
            <span>
              ▲ SYNTHETIC DEMO ACTIVE (status: synthetic demo) — Synthetic test rasters & OSM network loaded for pipeline verification. Never mix with real Trishuli case-study results.
            </span>
          ) : (
            <span>
              ● SCIENTIFIC INTEGRITY MODE — Unsupplied rasters, OSM extracts, AI models, and validation layers are strictly reported as &quot;not assessed&quot;.
            </span>
          )}
        </div>
        <div className="text-[11px] text-slate-600">
          Multimodal AI Hackathon 2026 · Track B: Mapping Flood Damage from Space
        </div>
      </div>

      {/* Main Content Workspace */}
      <main className="flex-1 max-w-[1600px] w-full mx-auto px-4 sm:px-6 py-5 space-y-5">
        {/* Study Area & Event Date Configuration Bar */}
        <section className="bg-white border border-slate-200 rounded-md p-4 animate-panel-enter">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-3 items-end text-xs">
            <div>
              <label className="block font-mono text-[11px] text-slate-600 mb-1">
                Select or Enter Study Area Name
              </label>
              <input
                type="text"
                value={studyArea.areaName}
                onChange={(e) =>
                  setStudyArea((prev) => ({
                    ...prev,
                    mode: 'CUSTOM_AOI',
                    areaName: e.target.value,
                  }))
                }
                className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 text-slate-900 focus:outline-none focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block font-mono text-[11px] text-slate-600 mb-1">
                Event Date
              </label>
              <input
                type="date"
                value={studyArea.eventDate}
                onChange={(e) =>
                  setStudyArea((prev) => ({ ...prev, eventDate: e.target.value }))
                }
                className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
              />
            </div>

            <div>
              <label className="block font-mono text-[11px] text-slate-600 mb-1">
                AOI Bounding Box [west, south, east, north]
              </label>
              <input
                type="text"
                value={customBboxText}
                onChange={(e) => {
                  setCustomBboxText(e.target.value);
                  const parts = e.target.value.split(',').map((s) => Number(s.trim()));
                  if (parts.length === 4 && parts.every((n) => !Number.isNaN(n))) {
                    setStudyArea((prev) => ({
                      ...prev,
                      bbox: [parts[0], parts[1], parts[2], parts[3]],
                      center: [(parts[1] + parts[3]) / 2, (parts[0] + parts[2]) / 2],
                    }));
                  }
                }}
                className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
              />
            </div>

            <div className="flex gap-2">
              <button
                type="button"
                onClick={() => {
                  setStudyArea(TRISHULI_CASE_STUDY_AREA);
                  setCustomBboxText('85.10, 27.88, 85.42, 28.30');
                }}
                className="w-full py-1.5 px-3 bg-teal-600 hover:bg-teal-700 text-white border border-teal-700 rounded font-mono font-semibold transition-colors whitespace-nowrap"
              >
                Preset: Trishuli Aug 2026
              </button>
            </div>
          </div>
        </section>

        {/* Interactive Map + Provenance Layer Stack */}
        <section className="flex flex-col lg:flex-row gap-4 min-h-[540px] animate-panel-enter">
          <LayerAndInspectorSidebar
            preRaster={preRaster}
            postRaster={postRaster}
            maskResult={maskResult}
            osmExtract={osmExtract}
            infraSummary={infraSummary}
            emsrComparison={emsrComparison}
            layers={layers}
            onToggleLayer={handleToggleLayer}
            selectedObject={selectedObject}
            postOptical={postOptical}
          />

          <div className="flex-1 bg-white border border-slate-200 rounded-md overflow-hidden flex flex-col">
            <div className="px-4 py-2.5 bg-slate-50 border-b border-slate-200 flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
              <div className="text-slate-900 font-semibold">
                {studyArea.areaName} · Event Date: {studyArea.eventDate}
              </div>
              <div className="text-[11px] text-slate-600">
                Mask Status:{' '}
                <span className="text-amber-700 font-semibold">
                  {maskResult
                    ? `${maskResult.methodLabel} (${maskResult.sourceStatus})`
                    : 'not assessed'}
                </span>
              </div>
            </div>

            <div className="flex-1 relative">
              <FloodIntelligenceMap
                studyArea={studyArea}
                maskResult={maskResult}
                infraSummary={infraSummary}
                layers={layers}
                onToggleLayer={handleToggleLayer}
                selectedObject={selectedObject}
                onSelectObject={setSelectedObject}
                postOptical={postOptical}
              />
            </div>
          </div>
        </section>

        {/* Functional Satellite Imagery Section: Before/After Panels, Upload Controls, Side-by-Side Slider & Mask Overlay */}
        {(activeTab === 'ALL' || activeTab === 'SATELLITE_ANALYSIS') && (
          <BeforeAfterPanel
            studyArea={studyArea}
            preRaster={preRaster}
            postRaster={postRaster}
            maskResult={maskResult}
            validation={validation}
            unitsConfirmedAsDb={unitsConfirmedAsDb}
            thresholdDb={thresholdDb}
            minDropDb={minDropDb}
            layers={layers}
            infraSummary={infraSummary}
            preOptical={preOptical}
            postOptical={postOptical}
            onUpdateRasters={(pre, post, isSynthetic) => {
              setPreRaster(pre);
              setPostRaster(post);
              setFrozenSnapshot(null);
              setEmsrComparison(null);
              if (isSynthetic) {
                setStudyArea((prev) => ({
                  ...prev,
                  mode: 'SYNTHETIC_DEMO',
                  center: [28.216, 85.328],
                  zoom: 13,
                }));
              }
            }}
            onUpdateOptical={(pre, post) => {
              setPreOptical(pre);
              setPostOptical(post);
            }}
            onUpdateUnitsConfirmed={setUnitsConfirmedAsDb}
            onUpdateThresholds={(tDb, dDb) => {
              setThresholdDb(tDb);
              setMinDropDb(dDb);
              setFrozenSnapshot(null);
            }}
            onToggleLayer={handleToggleLayer}
            onRunAnalysis={handleRunAnalysis}
            isAnalyzing={isAnalyzing}
            analysisFeedback={analysisFeedback}
          />
        )}

        {/* 8-Card Provenance Telemetry Strip */}
        <DashboardStatsStrip
          maskResult={maskResult}
          infraSummary={infraSummary}
          installedAiModel={installedAiModel}
          emsrComparison={emsrComparison}
          isAnalyzing={isAnalyzing}
        />

        {/* Milestone 1: GeoTIFF Baseline Workbench */}
        {(activeTab === 'ALL' || activeTab === 'GEOTIFF_BASELINE') && (
          <GeoTiffWorkbenchPanel
            preRaster={preRaster}
            postRaster={postRaster}
            validation={validation}
            maskResult={maskResult}
            unitsConfirmedAsDb={unitsConfirmedAsDb}
            thresholdDb={thresholdDb}
            minDropDb={minDropDb}
            onUpdateRasters={(pre, post, isSynthetic) => {
              setPreRaster(pre);
              setPostRaster(post);
              setFrozenSnapshot(null);
              setEmsrComparison(null);
              if (isSynthetic) {
                setStudyArea((prev) => ({
                  ...prev,
                  mode: 'SYNTHETIC_DEMO',
                  center: [28.216, 85.328],
                  zoom: 13,
                }));
              }
            }}
            onUpdateUnitsConfirmed={setUnitsConfirmedAsDb}
            onUpdateThresholds={(tDb, dDb) => {
              setThresholdDb(tDb);
              setMinDropDb(dDb);
              setFrozenSnapshot(null);
            }}
          />
        )}

        {/* Satellite Scene Discovery (Copernicus Data Space STAC) */}
        {(activeTab === 'ALL' || activeTab === 'SCENE_SEARCH') && (
          <SceneDiscoveryPanel
            defaultBbox={studyArea.bbox}
            defaultStartDate={studyArea.preEventWindowStart}
            defaultEndDate={studyArea.eventDate}
          />
        )}

        {/* Dated Pre-Event OSM Exposure & Road Graph Isolation */}
        {(activeTab === 'ALL' || activeTab === 'OSM_ISOLATION') && (
          <CutoffNetworkPanel
            eventDate={studyArea.eventDate}
            osmExtract={osmExtract}
            infraSummary={infraSummary}
            rule={impassabilityRule}
            onUploadOsmExtract={setOsmExtract}
            onUpdateRule={setImpassabilityRule}
            onSelectMapObject={setSelectedObject}
          />
        )}

        {/* AI Segmentation Pathway & Isolated EMSR927 Validation */}
        {(activeTab === 'ALL' || activeTab === 'AI_AND_VALIDATION') && (
          <div className="space-y-5">
            <AISegmentationPanel
              installedModel={installedAiModel}
              onInstallModel={setInstalledAiModel}
              onSwitchToBaselineTab={() => setActiveTab('GEOTIFF_BASELINE')}
            />
            <TrishuliCaseStudyPanel
              preRaster={preRaster}
              postRaster={postRaster}
              maskResult={maskResult}
              frozenSnapshot={frozenSnapshot}
              emsrComparison={emsrComparison}
              onFreezeSnapshot={setFrozenSnapshot}
              onClearFrozenSnapshot={() => setFrozenSnapshot(null)}
              onSetEmsrComparison={setEmsrComparison}
            />
          </div>
        )}

        {/* Deterministic One-Page Situation Report */}
        {(activeTab === 'ALL' || activeTab === 'SITREP') && (
          <SituationReportPanel
            studyArea={studyArea}
            maskResult={maskResult}
            infraSummary={infraSummary}
            aiModel={installedAiModel}
            frozenSnapshot={frozenSnapshot}
          />
        )}
      </main>

      {/* Mandatory Data Attributions Footer */}
      <footer className="bg-white border-t border-slate-200 px-6 py-4 mt-8 text-xs text-slate-600">
        <div className="max-w-[1600px] mx-auto flex flex-col md:flex-row items-start md:items-center justify-between gap-3">
          <div className="space-y-1">
            <div className="font-semibold text-slate-900">
              TerraResQ — Multimodal AI Hackathon 2026 (Track B: Mapping Flood Damage from Space)
            </div>
            <p className="text-[11px] text-slate-600">
              Contains modified Copernicus Sentinel data 2026. Produced using Copernicus WorldDEM-30 © DLR e.V. 2010–2014 and © Airbus Defence and Space GmbH 2014–2018 provided under COPERNICUS by the European Union and ESA; all rights reserved. © OpenStreetMap contributors.
            </p>
          </div>
          <div className="font-mono text-[11px] text-teal-800 font-medium shrink-0">
            Zero-LLM Geospatial Engine · Local VS Code ZIP Ready
          </div>
        </div>
      </footer>
    </div>
  );
}
