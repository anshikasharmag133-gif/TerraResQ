import React, { useRef, useState } from 'react';
import { InstalledAiModelManifest } from '../types/terraresq';

interface AISegmentationPanelProps {
  installedModel: InstalledAiModelManifest | null;
  onInstallModel: (manifest: InstalledAiModelManifest | null) => void;
  onSwitchToBaselineTab: () => void;
}

export const AISegmentationPanel: React.FC<AISegmentationPanelProps> = ({
  installedModel,
  onInstallModel,
  onSwitchToBaselineTab,
}) => {
  const [weightsFile, setWeightsFile] = useState<File | null>(null);
  const [metadataError, setMetadataError] = useState<string | null>(null);

  const weightsInputRef = useRef<HTMLInputElement | null>(null);
  const metadataInputRef = useRef<HTMLInputElement | null>(null);

  const handleMetadataUpload = async (metaFile: File) => {
    setMetadataError(null);
    if (!weightsFile) {
      setMetadataError(
        'Please select your exported model weights file (.onnx or .pt) first, then upload its companion model_metadata.json manifest.'
      );
      return;
    }

    try {
      const text = await metaFile.text();
      const json = JSON.parse(text);

      const datasetSource = String(json.dataset_source || '').trim();
      const datasetLicense = String(json.dataset_license || '').trim();
      const sensor = String(json.sensor || '').trim();

      if (!datasetSource || !datasetLicense || !sensor) {
        throw new Error(
          'Rejected model_metadata.json: Missing required provenance fields ("sensor", "dataset_source", or "dataset_license").'
        );
      }

      const lowerDataset = datasetSource.toLowerCase();
      if (
        lowerDataset.includes('emsr') ||
        lowerDataset.includes('unosat') ||
        lowerDataset.includes('copernicus ems') ||
        lowerDataset.includes('post-event osm')
      ) {
        throw new Error(
          `Rejected model_metadata.json: Dataset source "${datasetSource}" violates data integrity rules. EMSR927, Copernicus EMS, UNOSAT, and post-event OSM are strictly prohibited from model training, tuning, or inputs.`
        );
      }

      const splitInfo = json.split_verification || {};
      if (!splitInfo.verified_disjoint) {
        throw new Error(
          'Rejected model_metadata.json: "split_verification.verified_disjoint" must be true. Train, validation, and held-out test splits must be partitioned by geographic event/scene without random patch mixing.'
        );
      }

      const metrics = json.held_out_test_metrics || {};

      const manifest: InstalledAiModelManifest = {
        weightsFileName: weightsFile.name,
        weightsByteSize: weightsFile.size,
        metadataFileName: metaFile.name,
        uploadedAtIso: new Date().toISOString(),
        provenanceStatus: 'uploaded',
        modelName: String(json.model_name || 'SmallFloodUNet'),
        sensor,
        polarizationsOrBands: Array.isArray(json.polarizations_or_bands)
          ? json.polarizations_or_bands.map(String)
          : ['VV (dB)'],
        preprocessingSteps: Array.isArray(json.preprocessing_steps)
          ? json.preprocessing_steps.map(String)
          : ['Radiometric calibration to Sigma0 (dB)'],
        datasetSource,
        datasetLicense,
        splitStrategy: String(
          splitInfo.split_strategy || 'Geographic / Event-Based Disjoint Splits'
        ),
        splitVerifiedDisjoint: Boolean(splitInfo.verified_disjoint),
        heldOutMetrics: {
          iou: typeof metrics.iou === 'number' ? metrics.iou : null,
          f1Score: typeof metrics.f1_score === 'number' ? metrics.f1_score : null,
          precision: typeof metrics.precision === 'number' ? metrics.precision : null,
          recall: typeof metrics.recall === 'number' ? metrics.recall : null,
        },
        limitations: Array.isArray(json.limitations)
          ? json.limitations.map(String)
          : ['Subject to SAR radar shadow and layover in steep mountain gorges.'],
      };

      onInstallModel(manifest);
    } catch (err) {
      setMetadataError(
        err instanceof Error ? err.message : 'Invalid model_metadata.json file.'
      );
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-5 animate-panel-enter">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <div className="text-xs font-mono text-teal-700 font-semibold">
            MODULAR AI FLOOD SEGMENTATION PATHWAY · SEPARATE FROM dB THRESHOLD BASELINE
          </div>
          <h2 className="text-base font-semibold text-slate-900 mt-0.5">
            U-Net Flood Segmentation Model & Provenance Registry
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Offline Python training workflow located in <code className="text-teal-700 font-semibold">training/</code> (`train_unet.py`, `dataset_splits.py`, `inference_cli.py`).
          </p>
        </div>

        <div className="flex items-center gap-2">
          <span
            className={`px-2.5 py-1 rounded text-xs font-mono border ${
              installedModel
                ? 'bg-teal-50 text-teal-800 border-teal-300'
                : 'bg-amber-50 text-amber-800 border-amber-300'
            }`}
          >
            {installedModel
              ? `● AI Model Installed (${installedModel.provenanceStatus})`
              : '○ AI model not installed (status: not assessed)'}
          </span>
        </div>
      </div>

      {/* Default State when NO trained model is supplied */}
      {!installedModel && (
        <div className="bg-slate-50 border border-slate-200 rounded-md p-5 space-y-4 animate-card-enter">
          <div className="flex flex-wrap items-center justify-between gap-4">
            <div className="space-y-1 max-w-2xl">
              <div className="text-sm font-semibold text-amber-800 font-mono">
                AI model not installed — Status: not assessed
              </div>
              <p className="text-xs text-slate-600 leading-relaxed">
                No exported U-Net model checkpoint (`.onnx` / `.pt`) and provenance manifest (`model_metadata.json`) have been supplied in this session. Per strict scientific integrity rules, TerraResQ never fabricates model weights, IoU/F1 accuracy numbers, or trained-model predictions.
              </p>
            </div>

            <button
              type="button"
              onClick={onSwitchToBaselineTab}
              className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded-md transition-colors whitespace-nowrap"
            >
              Use Separate dB Threshold Baseline →
            </button>
          </div>

          {/* Upload Exported Model & Provenance Manifest */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 pt-3 border-t border-slate-200">
            <div className="bg-white border border-slate-200 rounded p-3.5 space-y-2">
              <div className="text-xs font-semibold text-slate-800">
                Step 1: Supply Exported Model File (.onnx / .pt)
              </div>
              <input
                ref={weightsInputRef}
                type="file"
                accept=".onnx,.pt,.pth,.bin"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) setWeightsFile(f);
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => weightsInputRef.current?.click()}
                className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors"
              >
                {weightsFile
                  ? `Selected Weights: ${weightsFile.name} (${(weightsFile.size / 1024).toFixed(1)} KB)`
                  : 'Select Exported Model Weights (.onnx / .pt)'}
              </button>
            </div>

            <div className="bg-white border border-slate-200 rounded p-3.5 space-y-2">
              <div className="text-xs font-semibold text-slate-800">
                Step 2: Supply Recorded Provenance (`model_metadata.json`)
              </div>
              <input
                ref={metadataInputRef}
                type="file"
                accept=".json"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleMetadataUpload(f);
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => metadataInputRef.current?.click()}
                className="w-full py-2 px-3 bg-slate-100 hover:bg-slate-200 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors"
              >
                Upload model_metadata.json Manifest
              </button>
            </div>
          </div>

          {metadataError && (
            <div className="bg-rose-50 border border-rose-300 rounded p-3 text-xs font-mono text-rose-800">
              ✖ {metadataError}
            </div>
          )}

          {/* Training Folder Architecture Summary */}
          <div className="bg-white border border-slate-200 rounded p-3.5 text-xs space-y-2">
            <div className="font-semibold text-slate-900">
              Offline Python Training Workflow (`training/` Folder Specification)
            </div>
            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono text-[11px] text-slate-600">
              <div>
                <div className="text-teal-700 font-semibold">training/dataset_splits.py</div>
                <p className="mt-0.5">
                  Enforces geographic & event-based disjoint train/val/test splits. Rejects random patch mixing from the same scene.
                </p>
              </div>
              <div>
                <div className="text-teal-700 font-semibold">training/train_unet.py</div>
                <p className="mt-0.5">
                  Trains SmallFloodUNet on permitted datasets (Sen1Floods11 / Kuro Siwo) and exports model_metadata.json.
                </p>
              </div>
              <div>
                <div className="text-teal-700 font-semibold">training/inference_cli.py</div>
                <p className="mt-0.5">
                  Runs reproducible inference with SHA-256 input/output provenance hashes.
                </p>
              </div>
            </div>
          </div>
        </div>
      )}

      {/* Installed Model View (Only shown when user supplies valid model + metadata) */}
      {installedModel && (
        <div className="bg-teal-50/50 border border-teal-300 rounded-md p-4 space-y-4 text-xs animate-card-enter">
          <div className="flex items-center justify-between border-b border-teal-200 pb-2.5">
            <div>
              <span className="font-semibold text-slate-900 text-sm">
                {installedModel.modelName}
              </span>
              <span className="ml-2 font-mono text-teal-700 font-semibold">
                [Status: {installedModel.provenanceStatus}]
              </span>
            </div>
            <button
              type="button"
              onClick={() => {
                setWeightsFile(null);
                onInstallModel(null);
              }}
              className="px-2.5 py-1 bg-white hover:bg-rose-50 text-rose-700 border border-rose-200 rounded font-mono text-[11px]"
            >
              Unload AI Model
            </button>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-3 font-mono">
            <div className="bg-white border border-slate-200 rounded p-3">
              <div className="text-slate-500">Sensor & Bands</div>
              <div className="text-slate-900 mt-1">{installedModel.sensor}</div>
              <div className="text-teal-700 text-[11px] mt-0.5">
                {installedModel.polarizationsOrBands.join(', ')}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-3">
              <div className="text-slate-500">Dataset & License</div>
              <div className="text-slate-900 mt-1">{installedModel.datasetSource}</div>
              <div className="text-slate-500 text-[11px] mt-0.5">
                {installedModel.datasetLicense}
              </div>
            </div>

            <div className="bg-white border border-slate-200 rounded p-3">
              <div className="text-slate-500">Held-Out Test Metrics</div>
              <div className="text-teal-700 font-semibold mt-1">
                IoU: {installedModel.heldOutMetrics.iou ?? 'not assessed'} · F1:{' '}
                {installedModel.heldOutMetrics.f1Score ?? 'not assessed'}
              </div>
              <div className="text-slate-500 text-[11px] mt-0.5">
                Split: {installedModel.splitStrategy}
              </div>
            </div>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            <div className="bg-white border border-slate-200 rounded p-3">
              <div className="font-semibold text-slate-900 mb-1">Recorded Preprocessing</div>
              <ul className="list-disc list-inside text-slate-600 font-mono text-[11px] space-y-0.5">
                {installedModel.preprocessingSteps.map((s, i) => (
                  <li key={i}>{s}</li>
                ))}
              </ul>
            </div>
            <div className="bg-white border border-slate-200 rounded p-3">
              <div className="font-semibold text-slate-900 mb-1">Recorded Limitations</div>
              <ul className="list-disc list-inside text-slate-600 font-mono text-[11px] space-y-0.5">
                {installedModel.limitations.map((l, i) => (
                  <li key={i}>{l}</li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
