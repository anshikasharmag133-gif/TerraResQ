import React, { useRef, useState } from 'react';
import {
  DatedPreEventOsmExtract,
  ImpassabilityRuleConfig,
  InfrastructureAndIsolationSummary,
  SelectedMapObject,
} from '../types/terraresq';
import {
  buildSyntheticDemoOsmExtract,
  parseDatedPreEventOsmGeoJson,
} from '../services/geospatialPipeline';

interface CutoffNetworkPanelProps {
  eventDate: string;
  osmExtract: DatedPreEventOsmExtract | null;
  infraSummary: InfrastructureAndIsolationSummary;
  rule: ImpassabilityRuleConfig;
  onUploadOsmExtract: (extract: DatedPreEventOsmExtract | null) => void;
  onUpdateRule: (nextRule: ImpassabilityRuleConfig) => void;
  onSelectMapObject: (obj: SelectedMapObject) => void;
}

export const CutoffNetworkPanel: React.FC<CutoffNetworkPanelProps> = ({
  eventDate,
  osmExtract,
  infraSummary,
  rule,
  onUploadOsmExtract,
  onUpdateRule,
  onSelectMapObject,
}) => {
  const [osmError, setOsmError] = useState<string | null>(null);
  const osmInputRef = useRef<HTMLInputElement | null>(null);

  const handleOsmFileSelect = async (file: File) => {
    setOsmError(null);
    try {
      const text = await file.text();
      const parsed = parseDatedPreEventOsmGeoJson(text, file.name, eventDate);
      onUploadOsmExtract(parsed);
    } catch (err) {
      setOsmError(err instanceof Error ? err.message : 'Failed to parse dated pre-event OSM file.');
    }
  };

  const handleDownloadSampleOsmFile = () => {
    const sample = buildSyntheticDemoOsmExtract();
    const jsonPayload = {
      extract_date: '2026-08-01T00:00:00Z',
      source_label: 'Dated Pre-Event OpenStreetMap Extract (Template)',
      note: 'Confirm extract_date is prior to flood event date.',
      settlements: sample.settlements,
      roads: sample.roads,
      bridges: sample.bridges,
      buildings: sample.buildings,
    };
    const blob = new Blob([JSON.stringify(jsonPayload, null, 2)], {
      type: 'application/json',
    });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = 'pre_event_osm_extract_2026-08-01.json';
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-5 animate-panel-enter">
      {/* Header & Provenance Badge */}
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <div className="text-xs font-mono text-teal-700 font-semibold">
            DATED PRE-EVENT OPENSTREETMAP · EXPOSURE & GRAPH ISOLATION ANALYSIS
          </div>
          <h2 className="text-base font-semibold text-slate-900 mt-0.5">
            Infrastructure Exposure & Candidate Settlement Isolation
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Intersection indicates <strong className="text-slate-900">exposure</strong>, not confirmed structural damage. Connectivity results are estimates based on the supplied road graph and impassability assumptions.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <span className="px-2.5 py-1 bg-slate-50 border border-slate-200 rounded text-xs font-mono text-slate-700">
            Status: <strong className="text-amber-700">{infraSummary.status}</strong>
          </span>
          <input
            ref={osmInputRef}
            type="file"
            accept=".json,.geojson"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleOsmFileSelect(f);
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => osmInputRef.current?.click()}
            className="px-3 py-1.5 text-xs font-mono bg-teal-50 hover:bg-teal-100 text-teal-800 border border-teal-300 rounded transition-colors whitespace-nowrap"
          >
            Upload Dated Pre-Event OSM (.json/.geojson)
          </button>
          <button
            type="button"
            onClick={() => {
              setOsmError(null);
              onUploadOsmExtract(buildSyntheticDemoOsmExtract());
            }}
            className="px-3 py-1.5 text-xs font-mono bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded transition-colors whitespace-nowrap"
          >
            Load Synthetic Demo OSM [synthetic demo]
          </button>
          <button
            type="button"
            onClick={handleDownloadSampleOsmFile}
            className="px-2.5 py-1.5 text-xs font-mono bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded transition-colors whitespace-nowrap"
          >
            Download Sample OSM JSON
          </button>
        </div>
      </div>

      {osmError && (
        <div className="bg-rose-50 border border-rose-300 rounded p-3 text-xs font-mono text-rose-800">
          ✖ {osmError}
        </div>
      )}

      {/* Unassessed Notice when no Dated Pre-Event OSM Extract is Supplied */}
      {!osmExtract && (
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 text-xs space-y-1.5">
          <div className="font-mono font-semibold text-amber-700">
            Infrastructure & Isolation Analysis Unavailable — Status: not assessed
          </div>
          <p className="text-slate-600">
            Current or undated OpenStreetMap data is never described as pre-event OSM. Please upload a dated pre-event OSM extract (with <code className="text-slate-900">extract_date</code> prior to <code className="text-slate-900">{eventDate}</code>) or load the explicitly marked <code className="text-amber-700">synthetic demo</code> network above to evaluate exposure and road-graph isolation.
          </p>
        </div>
      )}

      {/* Explicit, Adjustable Impassability Rule Configuration */}
      <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3 animate-card-enter">
        <div className="flex flex-wrap items-center justify-between gap-2">
          <div className="text-xs font-semibold text-slate-900">
            Explicit Road Impassability Rule (Graph Assumption)
          </div>
          <span className="text-[11px] font-mono text-amber-700 font-medium">
            Assumption only · Does not represent live road conditions
          </span>
        </div>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-4 text-xs">
          <div>
            <div className="flex justify-between font-mono mb-1">
              <span className="text-slate-600">Min Intersecting Candidate Blocks:</span>
              <span className="text-teal-700 font-semibold">{rule.minIntersectingCandidateBlocks} block(s)</span>
            </div>
            <input
              type="range"
              min={1}
              max={6}
              step={1}
              value={rule.minIntersectingCandidateBlocks}
              onChange={(e) =>
                onUpdateRule({
                  ...rule,
                  minIntersectingCandidateBlocks: Number(e.target.value),
                })
              }
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>

          <div>
            <div className="flex justify-between font-mono mb-1">
              <span className="text-slate-600">Candidate Proximity Buffer:</span>
              <span className="text-teal-700 font-semibold">{rule.bufferDistanceMeters} m</span>
            </div>
            <input
              type="range"
              min={20}
              max={200}
              step={20}
              value={rule.bufferDistanceMeters}
              onChange={(e) =>
                onUpdateRule({
                  ...rule,
                  bufferDistanceMeters: Number(e.target.value),
                })
              }
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>

          <div className="flex items-center">
            <label className="flex items-center gap-2 text-xs text-slate-800 cursor-pointer">
              <input
                type="checkbox"
                checked={rule.treatExposedBridgesAsImpassable}
                onChange={(e) =>
                  onUpdateRule({
                    ...rule,
                    treatExposedBridgesAsImpassable: e.target.checked,
                  })
                }
                className="accent-teal-600"
              />
              <span>Mark road impassable if an on-corridor bridge is exposed</span>
            </label>
          </div>
        </div>

        <div className="text-[11px] font-mono text-slate-600 border-t border-slate-200 pt-2">
          Active Rule: {infraSummary.ruleDescription}
        </div>
      </div>

      {/* Evaluated Settlements & Road Segments when OSM Extract is Loaded */}
      {osmExtract && (
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 animate-card-enter">
          {/* Candidate Settlement Isolation Table */}
          <div className="lg:col-span-7 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-900">
                Settlement Connectivity Estimates (Source: {osmExtract.sourceLabel})
              </span>
              <span className="font-mono text-slate-500">
                Extract Date: {osmExtract.extractTimestampIso.slice(0, 10)}
              </span>
            </div>

            <div className="overflow-x-auto border border-slate-200 rounded-md">
              <table className="w-full text-left border-collapse text-xs">
                <thead>
                  <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-mono text-[11px]">
                    <th className="py-2 px-3">Node Name & Type</th>
                    <th className="py-2 px-3">Nearest Supplied Town / Hospital</th>
                    <th className="py-2 px-3">Graph Estimate Status</th>
                    <th className="py-2 px-3">Limiting Corridor / Assumption</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-slate-200">
                  {infraSummary.settlements.map((s) => {
                    const isCutOff = s.isolationStatus === 'CANDIDATE_CUT_OFF';
                    const isUnassessed = s.isolationStatus === 'NOT_ASSESSED';
                    return (
                      <tr
                        key={s.id}
                        onClick={() => onSelectMapObject({ kind: 'settlement', data: s })}
                        className={`cursor-pointer ${
                          isCutOff
                            ? 'bg-rose-50/70 hover:bg-rose-100/70'
                            : 'hover:bg-slate-50'
                        }`}
                      >
                        <td className="py-2 px-3 font-medium text-slate-900">
                          <div>{s.name}</div>
                          <div className="font-mono text-[11px] text-slate-500">
                            {s.placeType} · Status: {s.provenanceStatus}
                          </div>
                        </td>
                        <td className="py-2 px-3 font-mono text-[11px] text-slate-700">
                          <div>Town: {s.nearestTownName || 'not assessed'}</div>
                          <div>Hosp: {s.nearestHospitalName || 'not assessed'}</div>
                        </td>
                        <td className="py-2 px-3 font-mono whitespace-nowrap">
                          {isUnassessed ? (
                            <span className="text-slate-500">not assessed</span>
                          ) : isCutOff ? (
                            <span className="text-rose-600 font-semibold">
                              ✖ CANDIDATE CUT OFF
                            </span>
                          ) : (
                            <span className="text-teal-700 font-semibold">
                              ● REACHABLE ESTIMATE ({s.postEventHospitalDistKm} km)
                            </span>
                          )}
                        </td>
                        <td className="py-2 px-3 text-[11px] text-slate-600">
                          {s.limitingCorridor || s.assumptionNote}
                        </td>
                      </tr>
                    );
                  })}
                </tbody>
              </table>
            </div>
          </div>

          {/* Road Exposure & Assumption Override List */}
          <div className="lg:col-span-5 space-y-2">
            <div className="flex items-center justify-between text-xs">
              <span className="font-semibold text-slate-900">
                Road Segment Exposure & Rule Overrides
              </span>
              {Object.keys(rule.manualRoadOverrides).length > 0 && (
                <button
                  type="button"
                  onClick={() => onUpdateRule({ ...rule, manualRoadOverrides: {} })}
                  className="font-mono text-[11px] text-amber-700 underline"
                >
                  Clear Overrides
                </button>
              )}
            </div>

            <div className="space-y-2 max-h-[260px] overflow-y-auto pr-1">
              {infraSummary.roads.map((r) => (
                <div
                  key={r.id}
                  onClick={() => onSelectMapObject({ kind: 'road', data: r })}
                  className="p-2.5 bg-slate-50 border border-slate-200 rounded text-xs space-y-1 cursor-pointer hover:border-slate-300"
                >
                  <div className="flex items-center justify-between gap-2">
                    <span className="font-medium text-slate-900">{r.name}</span>
                    <span
                      className={`font-mono text-[11px] font-semibold ${
                        r.markedImpassableByRule ? 'text-rose-600' : 'text-teal-700'
                      }`}
                    >
                      {r.markedImpassableByRule ? 'Assumed Impassable' : 'Assumed Passable'}
                    </span>
                  </div>
                  <div className="flex items-center justify-between font-mono text-[11px] text-slate-600">
                    <span>
                      Exposure: {r.exposed ? `EXPOSED (${r.intersectingCandidateUnits} blocks)` : 'Not exposed'}
                    </span>
                    <button
                      type="button"
                      onClick={(e) => {
                        e.stopPropagation();
                        onUpdateRule({
                          ...rule,
                          manualRoadOverrides: {
                            ...rule.manualRoadOverrides,
                            [r.id]: !r.markedImpassableByRule,
                          },
                        });
                      }}
                      className="px-2 py-0.5 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded"
                    >
                      Toggle Assumption
                    </button>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
