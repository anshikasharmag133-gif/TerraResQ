import React, { useRef, useState } from 'react';
import {
  ParsedGeoTiffRaster,
  RasterValidationResult,
  WaterCandidateMaskResult,
} from '../types/terraresq';
import {
  createSyntheticDemoGeoTiffBuffers,
  exportCandidateMaskGeoTiff,
  parseGeoTiffBuffer,
} from '../services/geotiffProcessor';

interface GeoTiffWorkbenchPanelProps {
  preRaster: ParsedGeoTiffRaster | null;
  postRaster: ParsedGeoTiffRaster | null;
  validation: RasterValidationResult;
  maskResult: WaterCandidateMaskResult | null;
  unitsConfirmedAsDb: boolean;
  thresholdDb: number;
  minDropDb: number;
  onUpdateRasters: (
    pre: ParsedGeoTiffRaster | null,
    post: ParsedGeoTiffRaster | null,
    isSynthetic: boolean
  ) => void;
  onUpdateUnitsConfirmed: (confirmed: boolean) => void;
  onUpdateThresholds: (thresholdDb: number, minDropDb: number) => void;
}

export const GeoTiffWorkbenchPanel: React.FC<GeoTiffWorkbenchPanelProps> = ({
  preRaster,
  postRaster,
  validation,
  maskResult,
  unitsConfirmedAsDb,
  thresholdDb,
  minDropDb,
  onUpdateRasters,
  onUpdateUnitsConfirmed,
  onUpdateThresholds,
}) => {
  const [uploadError, setUploadError] = useState<string | null>(null);
  const [isExporting, setIsExporting] = useState(false);
  const [swipePercent, setSwipePercent] = useState(50);

  const preInputRef = useRef<HTMLInputElement | null>(null);
  const postInputRef = useRef<HTMLInputElement | null>(null);

  const handleFileUpload = async (file: File, role: 'PRE' | 'POST') => {
    setUploadError(null);
    try {
      const buffer = await file.arrayBuffer();
      const parsed = await parseGeoTiffBuffer(
        buffer,
        file.name,
        new Date(file.lastModified).toISOString().slice(0, 10),
        unitsConfirmedAsDb ? 'dB' : 'unconfirmed',
        'uploaded'
      );
      if (role === 'PRE') {
        onUpdateRasters(parsed, postRaster, false);
      } else {
        onUpdateRasters(preRaster, parsed, false);
      }
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to parse GeoTIFF file.');
    }
  };

  const handleLoadSyntheticDemoPair = async () => {
    setUploadError(null);
    try {
      const { preBuffer, postBuffer, preFileName, postFileName } =
        await createSyntheticDemoGeoTiffBuffers({ makeIncompatible: false });
      const preParsed = await parseGeoTiffBuffer(
        preBuffer,
        preFileName,
        '2026-08-02',
        'dB',
        'synthetic demo'
      );
      const postParsed = await parseGeoTiffBuffer(
        postBuffer,
        postFileName,
        '2026-08-14',
        'dB',
        'synthetic demo'
      );
      onUpdateUnitsConfirmed(true);
      onUpdateRasters(preParsed, postParsed, true);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Error creating synthetic GeoTIFFs.');
    }
  };

  const handleTestIncompatibleRasters = async () => {
    setUploadError(null);
    try {
      const { preBuffer, postBuffer, preFileName, postFileName } =
        await createSyntheticDemoGeoTiffBuffers({ makeIncompatible: true });
      const preParsed = await parseGeoTiffBuffer(
        preBuffer,
        preFileName,
        '2026-08-02',
        'dB',
        'synthetic demo'
      );
      const postParsed = await parseGeoTiffBuffer(
        postBuffer,
        postFileName,
        '2026-08-14',
        'dB',
        'synthetic demo'
      );
      onUpdateRasters(preParsed, postParsed, true);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Error testing incompatible rasters.');
    }
  };

  const handleDownloadSampleTifs = async () => {
    const { preBuffer, postBuffer, preFileName, postFileName } =
      await createSyntheticDemoGeoTiffBuffers({ makeIncompatible: false });

    const downloadBuffer = (buf: ArrayBuffer, name: string) => {
      const blob = new Blob([buf], { type: 'image/tiff' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = name;
      a.click();
      URL.revokeObjectURL(url);
    };

    downloadBuffer(preBuffer, preFileName);
    setTimeout(() => downloadBuffer(postBuffer, postFileName), 250);
  };

  const handleExportMaskGeoTiff = async () => {
    if (!maskResult) return;
    setIsExporting(true);
    try {
      const arrayBuffer = await exportCandidateMaskGeoTiff(maskResult);
      const blob = new Blob([arrayBuffer], { type: 'image/tiff' });
      const url = URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = `TerraResQ_WaterCandidateMask_${maskResult.thresholdDb}dB_EPSG${
        maskResult.crsCode || 'Unknown'
      }.tif`;
      a.click();
      URL.revokeObjectURL(url);
    } catch (err) {
      setUploadError(
        err instanceof Error ? err.message : 'Failed to write georeferenced GeoTIFF.'
      );
    } finally {
      setIsExporting(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-5 animate-panel-enter">
      {/* Header & Mandatory Baseline Method Label */}
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <div className="text-xs font-mono text-teal-700 font-semibold">
            MILESTONE 1 · CO-REGISTERED SENTINEL-1 VV GEOTIFF WORKBENCH (dB)
          </div>
          <h2 className="text-base font-semibold text-slate-900 mt-0.5">
            Low-Backscatter Water-Candidate Thresholding & GeoTIFF Validator
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Method classification:{' '}
            <span className="font-mono text-amber-700 font-semibold">
              baseline only, not AI and not validated
            </span>{' '}
            — Do not present as an operational flood assessment.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleLoadSyntheticDemoPair}
            className="px-3 py-1.5 text-xs font-mono bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded transition-colors whitespace-nowrap"
          >
            Load Synthetic Demo Rasters [synthetic demo]
          </button>
          <button
            type="button"
            onClick={handleTestIncompatibleRasters}
            className="px-3 py-1.5 text-xs font-mono bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded transition-colors whitespace-nowrap"
          >
            Test Incompatible Raster Rejection
          </button>
          <button
            type="button"
            onClick={handleDownloadSampleTifs}
            className="px-3 py-1.5 text-xs font-mono bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded transition-colors whitespace-nowrap"
          >
            Download Sample .tif Pair
          </button>
        </div>
      </div>

      {/* Upload Controls & Units Declaration */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-4 animate-card-enter">
        {/* 1. Pre-Event GeoTIFF Upload */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-3.5 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-800">1. Pre-Event Sentinel-1 VV (.tif)</span>
            <span className="font-mono text-[11px] text-slate-500">
              Status: {preRaster ? preRaster.sourceStatus : 'not assessed'}
            </span>
          </div>
          <input
            ref={preInputRef}
            type="file"
            accept=".tif,.tiff"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFileUpload(f, 'PRE');
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => preInputRef.current?.click()}
            className="w-full py-2 px-3 bg-white hover:bg-teal-50 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors truncate"
          >
            {preRaster ? `Loaded: ${preRaster.fileName}` : 'Select Pre-Event GeoTIFF (.tif)'}
          </button>
          {preRaster && (
            <div className="text-[11px] font-mono text-slate-600 space-y-0.5 pt-1">
              <div>
                Grid: {preRaster.width}×{preRaster.height} · Bands: {preRaster.bandCount} · CRS:{' '}
                {preRaster.crsCode ? `EPSG:${preRaster.crsCode}` : 'Missing'}
              </div>
              <div>
                Range: [{preRaster.minDb}, {preRaster.maxDb}] dB · Valid:{' '}
                {preRaster.validPixelCount.toLocaleString()} px
              </div>
            </div>
          )}
        </div>

        {/* 2. Post-Event GeoTIFF Upload */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-3.5 space-y-2">
          <div className="flex items-center justify-between text-xs">
            <span className="font-semibold text-slate-800">2. Post-Event Sentinel-1 VV (.tif)</span>
            <span className="font-mono text-[11px] text-slate-500">
              Status: {postRaster ? postRaster.sourceStatus : 'not assessed'}
            </span>
          </div>
          <input
            ref={postInputRef}
            type="file"
            accept=".tif,.tiff"
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleFileUpload(f, 'POST');
            }}
            className="hidden"
          />
          <button
            type="button"
            onClick={() => postInputRef.current?.click()}
            className="w-full py-2 px-3 bg-white hover:bg-teal-50 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors truncate"
          >
            {postRaster ? `Loaded: ${postRaster.fileName}` : 'Select Post-Event GeoTIFF (.tif)'}
          </button>
          {postRaster && (
            <div className="text-[11px] font-mono text-slate-600 space-y-0.5 pt-1">
              <div>
                Grid: {postRaster.width}×{postRaster.height} · Bands: {postRaster.bandCount} · CRS:{' '}
                {postRaster.crsCode ? `EPSG:${postRaster.crsCode}` : 'Missing'}
              </div>
              <div>
                Range: [{postRaster.minDb}, {postRaster.maxDb}] dB · Valid:{' '}
                {postRaster.validPixelCount.toLocaleString()} px
              </div>
            </div>
          )}
        </div>

        {/* 3. Declared Units & Threshold Calibration */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-3.5 space-y-2.5">
          <label className="flex items-start gap-2 text-xs text-slate-800 cursor-pointer">
            <input
              type="checkbox"
              checked={unitsConfirmedAsDb}
              onChange={(e) => onUpdateUnitsConfirmed(e.target.checked)}
              className="mt-0.5 accent-teal-600"
            />
            <span>
              Confirm both uploaded Sentinel-1 VV rasters are calibrated in{' '}
              <strong className="font-mono text-teal-700">decibels (dB)</strong>
            </span>
          </label>

          <div className="space-y-1 pt-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-600">Low-Backscatter Threshold:</span>
              <span className="text-teal-700 font-semibold">{thresholdDb.toFixed(1)} dB</span>
            </div>
            <input
              type="range"
              min={-24.0}
              max={-12.0}
              step={0.5}
              value={thresholdDb}
              onChange={(e) => onUpdateThresholds(Number(e.target.value), minDropDb)}
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>

          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-600">Min Post-Event Drop (ΔdB):</span>
              <span className="text-teal-700 font-semibold">-{minDropDb.toFixed(1)} dB</span>
            </div>
            <input
              type="range"
              min={0.0}
              max={6.0}
              step={0.5}
              value={minDropDb}
              onChange={(e) => onUpdateThresholds(thresholdDb, Number(e.target.value))}
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>
        </div>
      </div>

      {/* Plain-Language Validation Status & Errors */}
      {uploadError && (
        <div className="bg-rose-50 border border-rose-300 rounded-md p-3.5 text-xs text-rose-800 font-mono">
          ✖ Upload Rejection Error: {uploadError}
        </div>
      )}

      {(preRaster || postRaster) && (
        <div
          className={`border rounded-md p-3.5 text-xs space-y-2 ${
            validation.valid
              ? 'bg-teal-50/70 border-teal-300'
              : 'bg-rose-50 border-rose-300'
          }`}
        >
          <div className="flex flex-wrap items-center justify-between gap-2 font-mono">
            <span className={validation.valid ? 'text-teal-800 font-semibold' : 'text-rose-700 font-semibold'}>
              {validation.valid
                ? '● CO-REGISTRATION & METADATA VALIDATION PASSED'
                : '✖ INCOMPATIBLE RASTERS REJECTED — PLAIN-LANGUAGE DIAGNOSTICS:'}
            </span>
            <div className="flex flex-wrap items-center gap-3 text-[11px] text-slate-700">
              <span>FileType: {validation.checks.fileTypeOk ? 'OK' : 'FAIL'}</span>
              <span>CRS: {validation.checks.crsOk ? 'OK' : 'FAIL'}</span>
              <span>Transform: {validation.checks.transformOk ? 'OK' : 'FAIL'}</span>
              <span>Dimensions: {validation.checks.dimensionsMatch ? 'OK' : 'FAIL'}</span>
              <span>Bands(1): {validation.checks.bandCountOk ? 'OK' : 'FAIL'}</span>
              <span>Nodata: {validation.checks.nodataChecked ? 'OK' : 'FAIL'}</span>
              <span>Units(dB): {validation.checks.unitsOk ? 'OK' : 'FAIL'}</span>
            </div>
          </div>

          {validation.errors.length > 0 && (
            <ul className="list-disc list-inside space-y-1 text-rose-800 font-mono">
              {validation.errors.map((err, i) => (
                <li key={i}>{err}</li>
              ))}
            </ul>
          )}

          {validation.warnings.length > 0 && (
            <ul className="list-disc list-inside space-y-1 text-amber-800 font-mono">
              {validation.warnings.map((w, i) => (
                <li key={i}>{w}</li>
              ))}
            </ul>
          )}
        </div>
      )}

      {/* Results & Before/After/Candidate Mask Inspector when Valid */}
      {maskResult && validation.valid && (
        <div className="space-y-4 pt-2 border-t border-slate-200">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3 bg-slate-50 border border-slate-200 rounded-md p-3.5">
            <div>
              <div className="text-xs text-slate-500 font-medium">New Water-Candidate Pixels</div>
              <div className="text-xl font-mono font-semibold tabular-nums text-teal-700 mt-0.5">
                {maskResult.newCandidatePixels.toLocaleString()}
                <span className="text-xs text-slate-500 ml-1.5">px</span>
              </div>
              <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                of {maskResult.validEvaluatedPixels.toLocaleString()} valid px
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 font-medium">Defensible Candidate Area</div>
              <div className="text-xl font-mono font-semibold tabular-nums text-blue-700 mt-0.5">
                {maskResult.areaDefensible && maskResult.newCandidateAreaSqKm !== null
                  ? `${maskResult.newCandidateAreaSqKm.toFixed(4)} sq km`
                  : 'not assessed'}
              </div>
              <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                {maskResult.areaDefensible && maskResult.newCandidateAreaSqM !== null
                  ? `${maskResult.newCandidateAreaSqM.toLocaleString()} m² (${maskResult.pixelAreaSqM} m²/px)`
                  : 'Requires metric projected CRS'}
              </div>
            </div>

            <div>
              <div className="text-xs text-slate-500 font-medium">Method & Provenance Status</div>
              <div className="text-xs font-mono font-semibold text-amber-700 mt-1">
                {maskResult.methodLabel}
              </div>
              <div className="text-[11px] font-mono text-slate-500 mt-0.5">
                Status: {maskResult.sourceStatus}
              </div>
            </div>

            <div className="flex flex-col justify-center">
              <button
                type="button"
                onClick={handleExportMaskGeoTiff}
                disabled={isExporting}
                className="w-full py-2 px-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold text-xs rounded transition-colors whitespace-nowrap"
              >
                {isExporting
                  ? 'Writing GeoTIFF...'
                  : 'Export Georeferenced Mask (.tif)'}
              </button>
              <div className="text-[10px] font-mono text-slate-500 text-center mt-1">
                Preserves EPSG:{maskResult.crsCode} & affine tiepoints
              </div>
            </div>
          </div>

          {/* 3-Panel & Swipe Visual Inspector of actual parsed GeoTIFF arrays */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-slate-50 border border-slate-200 rounded-md p-3 space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-800 font-semibold">BEFORE (Pre-Event VV dB)</span>
                <span className="text-slate-500">{preRaster?.acquisitionDate}</span>
              </div>
              <img
                src={maskResult.beforeDataUrl}
                alt="Pre-event Sentinel-1 VV dB raster"
                referrerPolicy="no-referrer"
                className="w-full h-48 object-contain bg-slate-900 border border-slate-300 rounded"
              />
              <div className="text-[11px] font-mono text-slate-600">
                Pre-event pixels ≤ {maskResult.thresholdDb} dB: {maskResult.preWaterPixels.toLocaleString()} px
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-md p-3 space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-slate-800 font-semibold">AFTER (Post-Event VV dB)</span>
                <span className="text-slate-500">{postRaster?.acquisitionDate}</span>
              </div>
              <img
                src={maskResult.afterDataUrl}
                alt="Post-event Sentinel-1 VV dB raster"
                referrerPolicy="no-referrer"
                className="w-full h-48 object-contain bg-slate-900 border border-slate-300 rounded"
              />
              <div className="text-[11px] font-mono text-slate-600">
                Post-event pixels ≤ {maskResult.thresholdDb} dB: {maskResult.postWaterPixels.toLocaleString()} px
              </div>
            </div>

            <div className="bg-slate-50 border border-slate-200 rounded-md p-3 space-y-2">
              <div className="flex justify-between text-xs font-mono">
                <span className="text-teal-700 font-semibold">CANDIDATE MASK (Swipe Overlay)</span>
                <span className="text-amber-700">{swipePercent}%</span>
              </div>
              <div className="relative w-full h-48 bg-slate-900 border border-slate-300 rounded overflow-hidden">
                <img
                  src={maskResult.afterDataUrl}
                  alt="Post-event base"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
                <img
                  src={maskResult.maskDataUrl}
                  alt="New low-backscatter water-candidate mask"
                  referrerPolicy="no-referrer"
                  className="absolute inset-0 w-full h-full object-contain"
                  style={{ clipPath: `inset(0 ${100 - swipePercent}% 0 0)` }}
                />
              </div>
              <input
                type="range"
                min={0}
                max={100}
                value={swipePercent}
                onChange={(e) => setSwipePercent(Number(e.target.value))}
                className="w-full accent-teal-600 cursor-pointer"
                aria-label="Candidate Mask Swipe Slider"
              />
            </div>
          </div>
        </div>
      )}
    </div>
  );
};
