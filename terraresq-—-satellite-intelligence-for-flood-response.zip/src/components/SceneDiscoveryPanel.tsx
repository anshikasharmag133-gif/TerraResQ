import React, { useState } from 'react';
import { CopernicusCatalogScene } from '../types/terraresq';

interface SceneDiscoveryPanelProps {
  defaultBbox: [number, number, number, number];
  defaultStartDate: string;
  defaultEndDate: string;
  onSelectCatalogSceneInfo?: (scene: CopernicusCatalogScene) => void;
}

export const SceneDiscoveryPanel: React.FC<SceneDiscoveryPanelProps> = ({
  defaultBbox,
  defaultStartDate,
  defaultEndDate,
  onSelectCatalogSceneInfo,
}) => {
  const [bboxStr, setBboxStr] = useState<string>(defaultBbox.join(', '));
  const [startDate, setStartDate] = useState<string>(defaultStartDate);
  const [endDate, setEndDate] = useState<string>(defaultEndDate);
  const [sensor, setSensor] = useState<'SENTINEL-1' | 'SENTINEL-2'>('SENTINEL-1');
  const [polarization, setPolarization] = useState<'VV' | 'VH' | 'ANY'>('VV');

  const [isSearching, setIsSearching] = useState(false);
  const [searchError, setSearchError] = useState<string | null>(null);
  const [scenes, setScenes] = useState<CopernicusCatalogScene[]>([]);
  const [hasSearched, setHasSearched] = useState(false);
  const [credentialsConfigured, setCredentialsConfigured] = useState<boolean>(false);
  const [selectedSceneId, setSelectedSceneId] = useState<string | null>(null);

  const handleRunSearch = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSearching(true);
    setSearchError(null);
    setHasSearched(true);

    const parsedBbox = bboxStr
      .split(',')
      .map((s) => Number(s.trim()))
      .filter((n) => !Number.isNaN(n));

    if (parsedBbox.length !== 4) {
      setSearchError(
        'Invalid bounding box format. Enter 4 comma-separated WGS84 numbers: westLng, southLat, eastLng, northLat.'
      );
      setIsSearching(false);
      return;
    }

    try {
      const response = await fetch('/api/copernicus/search', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          bbox: parsedBbox,
          startDate,
          endDate,
          sensor,
          polarization,
          limit: 12,
        }),
      });

      const data = await response.json();
      if (!response.ok) {
        setSearchError(
          data.error ||
            'Copernicus Data Space STAC search returned an error. Local GeoTIFF upload remains available.'
        );
        setScenes([]);
      } else {
        setScenes(data.scenes || []);
        setCredentialsConfigured(Boolean(data.copernicusCredentialsConfigured));
      }
    } catch {
      setSearchError(
        'Could not reach Copernicus Data Space catalogue endpoint. Local GeoTIFF upload workflow remains usable.'
      );
    } finally {
      setIsSearching(false);
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-4 animate-panel-enter">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <div className="text-xs font-mono text-teal-700 font-semibold">
            COPERNICUS DATA SPACE ECOSYSTEM (CDSE) · METADATA CATALOGUE DISCOVERY
          </div>
          <h2 className="text-base font-semibold text-slate-900 mt-0.5">
            Satellite Scene Discovery (Sentinel-1 SAR & Sentinel-2 MSI)
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Queries the official Copernicus STAC catalogue (`catalogue.dataspace.copernicus.eu`). Large scenes are never downloaded automatically.
          </p>
        </div>

        <div className="text-xs font-mono text-slate-700 bg-slate-50 border border-slate-200 px-2.5 py-1 rounded">
          Provenance label: <span className="text-teal-700 font-semibold">catalog result</span>
        </div>
      </div>

      {/* Search Form */}
      <form onSubmit={handleRunSearch} className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-6 gap-3 text-xs">
        <div className="lg:col-span-2">
          <label className="block font-mono text-[11px] text-slate-600 mb-1">
            Bounding Box [west, south, east, north]
          </label>
          <input
            type="text"
            value={bboxStr}
            onChange={(e) => setBboxStr(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
            placeholder="85.10, 27.88, 85.42, 28.30"
          />
        </div>

        <div>
          <label className="block font-mono text-[11px] text-slate-600 mb-1">
            Start Date (UTC)
          </label>
          <input
            type="date"
            value={startDate}
            onChange={(e) => setStartDate(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
          />
        </div>

        <div>
          <label className="block font-mono text-[11px] text-slate-600 mb-1">
            End Date (UTC)
          </label>
          <input
            type="date"
            value={endDate}
            onChange={(e) => setEndDate(e.target.value)}
            className="w-full bg-slate-50 border border-slate-300 rounded px-2.5 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
          />
        </div>

        <div>
          <label className="block font-mono text-[11px] text-slate-600 mb-1">
            Sensor & Polarization
          </label>
          <div className="flex gap-1.5">
            <select
              value={sensor}
              onChange={(e) => setSensor(e.target.value as 'SENTINEL-1' | 'SENTINEL-2')}
              className="w-full bg-slate-50 border border-slate-300 rounded px-2 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
            >
              <option value="SENTINEL-1">Sentinel-1</option>
              <option value="SENTINEL-2">Sentinel-2</option>
            </select>
            {sensor === 'SENTINEL-1' && (
              <select
                value={polarization}
                onChange={(e) => setPolarization(e.target.value as 'VV' | 'VH' | 'ANY')}
                className="bg-slate-50 border border-slate-300 rounded px-2 py-1.5 font-mono text-slate-900 focus:outline-none focus:border-teal-600"
              >
                <option value="VV">VV</option>
                <option value="VH">VH</option>
                <option value="ANY">Any</option>
              </select>
            )}
          </div>
        </div>

        <div className="flex items-end">
          <button
            type="submit"
            disabled={isSearching}
            className="w-full py-1.5 px-3 bg-teal-600 hover:bg-teal-700 disabled:opacity-50 text-white font-semibold rounded transition-colors whitespace-nowrap"
          >
            {isSearching ? 'Querying CDSE STAC...' : 'Search Catalogue'}
          </button>
        </div>
      </form>

      {/* Preset Date Helper Note */}
      <div className="flex flex-wrap items-center justify-between gap-2 text-[11px] font-mono text-slate-600 bg-slate-50 border border-slate-200 rounded px-3 py-2">
        <div>
          Tip: To test live archival scenes over the Trishuli Corridor right now, try searching{' '}
          <button
            type="button"
            onClick={() => {
              setBboxStr('85.10, 27.88, 85.42, 28.30');
              setStartDate('2024-08-01');
              setEndDate('2024-08-31');
            }}
            className="text-teal-700 font-semibold underline hover:text-teal-800"
          >
            2024-08-01 to 2024-08-31 (Trishuli Monsoon Archive)
          </button>{' '}
          or your target 2026 window.
        </div>
        <div>
          Download Auth:{' '}
          {credentialsConfigured ? (
            <span className="text-teal-700 font-semibold">Server OAuth2 Configured</span>
          ) : (
            <span className="text-amber-700">
              Metadata-Only (Set COPERNICUS_CLIENT_ID / SECRET in server Secrets for full download)
            </span>
          )}
        </div>
      </div>

      {searchError && (
        <div className="bg-rose-50 border border-rose-300 rounded p-3 text-xs font-mono text-rose-800">
          {searchError}
        </div>
      )}

      {hasSearched && !isSearching && scenes.length === 0 && !searchError && (
        <div className="bg-slate-50 border border-slate-200 rounded p-4 text-xs font-mono text-slate-600">
          0 scenes returned by Copernicus Data Space STAC for the selected date range and bounding box. (Note: Future or unacquired dates return 0 scenes; try an archival window or upload local GeoTIFF tiles directly.)
        </div>
      )}

      {scenes.length > 0 && (
        <div className="overflow-x-auto border border-slate-200 rounded-md animate-card-enter">
          <table className="w-full text-left border-collapse text-xs">
            <thead>
              <tr className="bg-slate-50 border-b border-slate-200 text-slate-600 font-mono text-[11px]">
                <th className="py-2 px-3">Scene Identifier</th>
                <th className="py-2 px-3">Acquisition Date (UTC)</th>
                <th className="py-2 px-3">Sensor & Polarization</th>
                <th className="py-2 px-3">Orbit Dir / Track</th>
                <th className="py-2 px-3">BBox Coverage</th>
                <th className="py-2 px-3">Access & Status</th>
                <th className="py-2 px-3">Action</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-200 font-mono">
              {scenes.map((sc) => {
                const isSelected = selectedSceneId === sc.id;
                return (
                  <tr
                    key={sc.id}
                    className={isSelected ? 'bg-teal-50' : 'hover:bg-slate-50'}
                  >
                    <td className="py-2 px-3 text-slate-900 max-w-[240px] truncate" title={sc.id}>
                      {sc.id}
                    </td>
                    <td className="py-2 px-3 text-slate-700 whitespace-nowrap">
                      {sc.acquisitionDate.slice(0, 19).replace('T', ' ')}
                    </td>
                    <td className="py-2 px-3 text-teal-700 font-semibold whitespace-nowrap">
                      {sc.sensor} · {sc.polarization}
                    </td>
                    <td className="py-2 px-3 text-slate-700 whitespace-nowrap">
                      {sc.orbitDirection} / #{sc.relativeOrbitTrack}
                    </td>
                    <td className="py-2 px-3 text-slate-500 text-[11px] whitespace-nowrap">
                      {sc.footprintCoverageNote}
                    </td>
                    <td className="py-2 px-3 text-[11px]">
                      <span className="text-teal-700 font-semibold">{sc.provenanceStatus}</span>
                    </td>
                    <td className="py-2 px-3 whitespace-nowrap">
                      <button
                        type="button"
                        onClick={() => {
                          setSelectedSceneId(sc.id);
                          onSelectCatalogSceneInfo?.(sc);
                        }}
                        className="px-2.5 py-1 bg-white hover:bg-slate-100 text-slate-800 border border-slate-300 rounded text-[11px]"
                      >
                        {isSelected ? 'Selected' : 'Inspect Scene'}
                      </button>
                    </td>
                  </tr>
                );
              })}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
};
