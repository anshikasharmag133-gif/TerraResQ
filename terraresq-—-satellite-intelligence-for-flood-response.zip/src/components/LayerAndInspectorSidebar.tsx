import React from 'react';
import {
  DatedPreEventOsmExtract,
  EmsrValidationComparison,
  InfrastructureAndIsolationSummary,
  MapLayerVisibility,
  OpticalSatelliteImage,
  ParsedGeoTiffRaster,
  SelectedMapObject,
  WaterCandidateMaskResult,
} from '../types/terraresq';

interface LayerAndInspectorSidebarProps {
  preRaster: ParsedGeoTiffRaster | null;
  postRaster: ParsedGeoTiffRaster | null;
  maskResult: WaterCandidateMaskResult | null;
  osmExtract: DatedPreEventOsmExtract | null;
  infraSummary: InfrastructureAndIsolationSummary;
  emsrComparison: EmsrValidationComparison | null;
  layers: MapLayerVisibility;
  onToggleLayer: (key: keyof MapLayerVisibility) => void;
  selectedObject: SelectedMapObject;
  postOptical?: OpticalSatelliteImage | null;
}

export const LayerAndInspectorSidebar: React.FC<LayerAndInspectorSidebarProps> = ({
  preRaster,
  postRaster,
  maskResult,
  osmExtract,
  infraSummary,
  emsrComparison,
  layers,
  onToggleLayer,
  selectedObject,
  postOptical,
}) => {
  const layerItems: {
    key: keyof MapLayerVisibility;
    label: string;
    source: string;
    date: string;
    status: string;
  }[] = [
    {
      key: 'baseMap',
      label: '01. Cartographic Base Map',
      source: 'OSM / CARTO Voyager',
      date: 'Reference',
      status: 'reference',
    },
    {
      key: 'preEventRaster',
      label: '02. Pre-Event Sentinel-1 VV (dB)',
      source: preRaster ? preRaster.fileName : 'None',
      date: preRaster ? preRaster.acquisitionDate : 'N/A',
      status: preRaster ? preRaster.sourceStatus : 'not assessed',
    },
    {
      key: 'postEventRaster',
      label: '03. Post-Event Sentinel-1 VV (dB)',
      source: postRaster ? postRaster.fileName : 'None',
      date: postRaster ? postRaster.acquisitionDate : 'N/A',
      status: postRaster ? postRaster.sourceStatus : 'not assessed',
    },
    {
      key: 'opticalOverlay',
      label: '03b. Sentinel-2 Optical (RGB)',
      source: postOptical ? postOptical.fileName : 'None',
      date: postOptical ? postOptical.acquisitionDate : 'N/A',
      status: postOptical ? postOptical.sourceStatus : 'not assessed',
    },
    {
      key: 'waterCandidateMask',
      label: '04. Water-Candidate Mask (Baseline)',
      source: maskResult ? `Threshold <= ${maskResult.thresholdDb} dB` : 'None',
      date: postRaster ? postRaster.acquisitionDate : 'N/A',
      status: maskResult ? maskResult.sourceStatus : 'not assessed',
    },
    {
      key: 'osmBuildings',
      label: '05. Pre-Event OSM Buildings',
      source: osmExtract ? osmExtract.fileName : 'None',
      date: osmExtract ? osmExtract.extractTimestampIso.slice(0, 10) : 'N/A',
      status: infraSummary.status,
    },
    {
      key: 'osmRoads',
      label: '06. Pre-Event OSM Road Graph',
      source: osmExtract ? osmExtract.fileName : 'None',
      date: osmExtract ? osmExtract.extractTimestampIso.slice(0, 10) : 'N/A',
      status: infraSummary.status,
    },
    {
      key: 'osmBridges',
      label: '07. Pre-Event OSM Bridges',
      source: osmExtract ? osmExtract.fileName : 'None',
      date: osmExtract ? osmExtract.extractTimestampIso.slice(0, 10) : 'N/A',
      status: infraSummary.status,
    },
    {
      key: 'osmSettlements',
      label: '08. Pre-Event Settlements',
      source: osmExtract ? osmExtract.fileName : 'None',
      date: osmExtract ? osmExtract.extractTimestampIso.slice(0, 10) : 'N/A',
      status: infraSummary.status,
    },
    {
      key: 'osmHospitalsAndTowns',
      label: '09. Pre-Event Towns & Hospitals',
      source: osmExtract ? osmExtract.fileName : 'None',
      date: osmExtract ? osmExtract.extractTimestampIso.slice(0, 10) : 'N/A',
      status: infraSummary.status,
    },
    {
      key: 'groundTruthFloodMask',
      label: '10. Ground-Truth Flood Labels',
      source: 'Kuro Siwo Reference Annotations',
      date: '2026-08-14',
      status: 'ground-truth reference',
    },
    {
      key: 'emsrValidationOverlay',
      label: '11. EMSR927 Validation (Isolated)',
      source: emsrComparison ? emsrComparison.referenceFileName : 'None',
      date: emsrComparison ? emsrComparison.comparedAtIso.slice(0, 10) : 'N/A',
      status: emsrComparison ? 'uploaded' : 'not assessed',
    },
  ];

  return (
    <aside className="w-full lg:w-[360px] shrink-0 flex flex-col gap-4">
      {/* Layer Stack with Source, Date, and Status on every layer */}
      <div className="bg-white border border-slate-200 rounded-md p-4 space-y-2.5 animate-card-enter">
        <div className="flex items-center justify-between border-b border-slate-200 pb-2">
          <h2 className="text-xs font-semibold text-slate-900">
            Map Layers (Source · Date · Status)
          </h2>
          <span className="text-[11px] font-mono text-teal-700 font-medium">
            Provenance Verified
          </span>
        </div>

        <div className="space-y-1.5 max-h-[340px] overflow-y-auto pr-1">
          {layerItems.map((item) => {
            const active = layers[item.key];
            return (
              <button
                key={item.key}
                type="button"
                onClick={() => onToggleLayer(item.key)}
                className={`w-full text-left p-2 rounded border transition-colors text-xs ${
                  active
                    ? 'bg-slate-50 border-slate-300 text-slate-900'
                    : 'bg-transparent border-transparent text-slate-400 hover:text-slate-700'
                }`}
              >
                <div className="flex items-center justify-between gap-2">
                  <span className="font-medium truncate">{item.label}</span>
                  <span className="font-mono text-[10px] shrink-0 text-teal-700 font-semibold">
                    {active ? 'VISIBLE' : 'HIDDEN'}
                  </span>
                </div>
                <div className="text-[10px] font-mono text-slate-500 mt-0.5 truncate">
                  Status: <span className="text-amber-700 font-medium">{item.status}</span> · Date: {item.date} · Src: {item.source}
                </div>
              </button>
            );
          })}
        </div>
      </div>

      {/* Selected Feature Inspector */}
      <div className="bg-white border border-slate-200 rounded-md p-4 space-y-2.5 flex-1 animate-card-enter">
        <div className="border-b border-slate-200 pb-2 flex items-center justify-between">
          <h2 className="text-xs font-semibold text-slate-900">
            Object Provenance & Exposure Inspector
          </h2>
          <span className="text-[10px] font-mono text-teal-700 font-semibold">
            {selectedObject ? selectedObject.kind.toUpperCase() : 'NONE SELECTED'}
          </span>
        </div>

        {!selectedObject && (
          <p className="text-xs text-slate-600 py-2 leading-relaxed">
            Click any settlement, road segment, bridge, or building on the map or table to view its source, date, exposure status, and road-graph assumptions.
          </p>
        )}

        {selectedObject?.kind === 'settlement' && (
          <div className="space-y-1.5 text-xs font-mono text-slate-700">
            <div className="font-sans font-semibold text-slate-900">
              {selectedObject.data.name}
            </div>
            <div>Status: {selectedObject.data.provenanceStatus}</div>
            <div>Isolation: {selectedObject.data.isolationStatus}</div>
            <div>Nearest Town: {selectedObject.data.nearestTownName || 'not assessed'}</div>
            <div>Nearest Hospital: {selectedObject.data.nearestHospitalName || 'not assessed'}</div>
            <div className="text-[11px] text-slate-500 pt-1">
              {selectedObject.data.assumptionNote}
            </div>
          </div>
        )}

        {selectedObject?.kind === 'road' && (
          <div className="space-y-1.5 text-xs font-mono text-slate-700">
            <div className="font-sans font-semibold text-slate-900">
              {selectedObject.data.name}
            </div>
            <div>Status: {selectedObject.data.provenanceStatus}</div>
            <div>
              Exposure: {selectedObject.data.exposed ? 'EXPOSED' : 'Not Exposed'} (
              {selectedObject.data.intersectingCandidateUnits} blocks)
            </div>
            <div>
              Graph Rule:{' '}
              {selectedObject.data.markedImpassableByRule
                ? 'Assumed Impassable'
                : 'Assumed Passable'}
            </div>
            <div className="text-[11px] text-slate-500 pt-1">
              {selectedObject.data.ruleReason}
            </div>
          </div>
        )}

        {selectedObject?.kind === 'bridge' && (
          <div className="space-y-1.5 text-xs font-mono text-slate-700">
            <div className="font-sans font-semibold text-slate-900">
              {selectedObject.data.name}
            </div>
            <div>Status: {selectedObject.data.provenanceStatus}</div>
            <div>Exposure: {selectedObject.data.exposed ? 'EXPOSED' : 'Not Exposed'}</div>
            <div className="text-[11px] text-slate-500 pt-1">
              {selectedObject.data.exposureBasis}
            </div>
          </div>
        )}

        {selectedObject?.kind === 'building' && (
          <div className="space-y-1.5 text-xs font-mono text-slate-700">
            <div className="font-sans font-semibold text-slate-900">
              {selectedObject.data.name}
            </div>
            <div>Status: {selectedObject.data.provenanceStatus}</div>
            <div>
              Exposure: {selectedObject.data.exposed ? 'EXPOSED (Candidate Overlap)' : 'Not Exposed'}
            </div>
            <div className="text-[11px] text-slate-500 pt-1">
              Exposure does not prove structural damage.
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
