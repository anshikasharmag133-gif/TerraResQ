import React, { useRef, useState } from 'react';
import {
  EmsrValidationComparison,
  FrozenOutputSnapshot,
  ParsedGeoTiffRaster,
  WaterCandidateMaskResult,
} from '../types/terraresq';
import { haversineMeters } from '../services/geospatialPipeline';

interface TrishuliCaseStudyPanelProps {
  preRaster: ParsedGeoTiffRaster | null;
  postRaster: ParsedGeoTiffRaster | null;
  maskResult: WaterCandidateMaskResult | null;
  frozenSnapshot: FrozenOutputSnapshot | null;
  emsrComparison: EmsrValidationComparison | null;
  onFreezeSnapshot: (snapshot: FrozenOutputSnapshot) => void;
  onClearFrozenSnapshot: () => void;
  onSetEmsrComparison: (comp: EmsrValidationComparison | null) => void;
}

export const TrishuliCaseStudyPanel: React.FC<TrishuliCaseStudyPanelProps> = ({
  preRaster,
  postRaster,
  maskResult,
  frozenSnapshot,
  emsrComparison,
  onFreezeSnapshot,
  onClearFrozenSnapshot,
  onSetEmsrComparison,
}) => {
  const [validationError, setValidationError] = useState<string | null>(null);
  const emsrInputRef = useRef<HTMLInputElement | null>(null);

  const handleFreezeOutputs = () => {
    setValidationError(null);
    if (!maskResult || !preRaster || !postRaster) {
      setValidationError(
        'Cannot freeze outputs: Upload and validate pre-event and post-event Sentinel-1 GeoTIFFs first.'
      );
      return;
    }

    if (maskResult.sourceStatus === 'synthetic demo') {
      setValidationError(
        'Validation integrity guard: Active rasters are marked "synthetic demo". Synthetic demo outputs must never be mixed with real EMSR927 case-study validation. Upload real Trishuli Sentinel-1 GeoTIFFs to freeze for EMSR927 comparison.'
      );
      return;
    }

    const hashInput = `${preRaster.fileName}|${postRaster.fileName}|${maskResult.thresholdDb}|${maskResult.minDropDb}|${maskResult.newCandidatePixels}`;
    let hashNum = 5381;
    for (let i = 0; i < hashInput.length; i++) {
      hashNum = (hashNum * 33) ^ hashInput.charCodeAt(i);
    }
    const frozenHash = `TRQ-FROZEN-${(hashNum >>> 0).toString(16).toUpperCase()}`;

    onFreezeSnapshot({
      frozenAtIso: new Date().toISOString(),
      frozenHash,
      pathwayType: maskResult.methodLabel,
      preRasterFile: preRaster.fileName,
      postRasterFile: postRaster.fileName,
      thresholdDb: maskResult.thresholdDb,
      minDropDb: maskResult.minDropDb,
      candidatePixels: maskResult.newCandidatePixels,
      candidateAreaSqKm: maskResult.newCandidateAreaSqKm,
      candidatePolygonsWgs84: maskResult.candidatePolygonsWgs84,
    });
  };

  const handleEmsrUpload = async (file: File) => {
    setValidationError(null);
    if (!frozenSnapshot) {
      setValidationError('Freeze model/baseline outputs and parameters before loading EMSR927.');
      return;
    }

    try {
      const text = await file.text();
      const geojson = JSON.parse(text);
      const features = Array.isArray(geojson.features) ? geojson.features : [];
      if (features.length === 0) {
        throw new Error(
          `No GeoJSON features found in "${file.name}". Please upload a valid EMSR927 Observed Event / Flood Extent vector GeoJSON.`
        );
      }

      // Extract centroid coordinates from EMSR927 features for overlap check against frozen candidate blocks
      const refCentroids: [number, number][] = [];
      for (const feat of features) {
        const geom = feat?.geometry;
        if (!geom) continue;
        if (geom.type === 'Point' && Array.isArray(geom.coordinates)) {
          refCentroids.push([Number(geom.coordinates[1]), Number(geom.coordinates[0])]);
        } else if (geom.type === 'Polygon' && Array.isArray(geom.coordinates?.[0]?.[0])) {
          const ring = geom.coordinates[0];
          const pt = ring[0];
          refCentroids.push([Number(pt[1]), Number(pt[0])]);
        } else if (
          geom.type === 'MultiPolygon' &&
          Array.isArray(geom.coordinates?.[0]?.[0]?.[0])
        ) {
          const pt = geom.coordinates[0][0][0];
          refCentroids.push([Number(pt[1]), Number(pt[0])]);
        }
      }

      let overlappingBlocks = 0;
      for (const block of frozenSnapshot.candidatePolygonsWgs84) {
        const bLat = (block[0][0] + block[2][0]) / 2;
        const bLng = (block[0][1] + block[2][1]) / 2;
        const match = refCentroids.some(
          ([rLat, rLng]) => haversineMeters(bLat, bLng, rLat, rLng) <= 500
        );
        if (match) overlappingBlocks++;
      }

      const totalBlocks = Math.max(1, frozenSnapshot.candidatePolygonsWgs84.length);
      const overlapRatio = Number((overlappingBlocks / totalBlocks).toFixed(4));

      onSetEmsrComparison({
        referenceFileName: file.name,
        referenceProductCode: 'EMSR927',
        comparedAgainstFrozenHash: frozenSnapshot.frozenHash,
        comparedAtIso: new Date().toISOString(),
        referencePolygonCount: features.length,
        frozenCandidateBlocksCount: frozenSnapshot.candidatePolygonsWgs84.length,
        overlappingCandidateBlocksCount: overlappingBlocks,
        overlapRatioEstimate: overlapRatio,
        notes: [
          `Compared strictly against frozen output snapshot ${frozenSnapshot.frozenHash} (threshold=${frozenSnapshot.thresholdDb} dB).`,
          'EMSR927 features were never passed to training, hyperparameter tuning, or inference.',
        ],
      });
    } catch (err) {
      setValidationError(
        err instanceof Error ? err.message : 'Failed to parse EMSR927 GeoJSON file.'
      );
    }
  };

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-5 animate-panel-enter">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <div className="text-xs font-mono text-teal-700 font-semibold">
            CASE STUDY & STRICT VALIDATION PROTOCOL · TRISHULI CORRIDOR, NEPAL (AUGUST 2026)
          </div>
          <h2 className="text-base font-semibold text-slate-900 mt-0.5">
            Trishuli Corridor Case Study & Isolated EMSR927 Validation Gate
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            EMSR927 is for validation only. Never used as model inputs, training labels, tuning data, or inference features.
          </p>
        </div>

        <div className="text-xs font-mono bg-slate-50 border border-slate-200 px-2.5 py-1 rounded text-slate-700">
          Validation Status:{' '}
          <span className="text-amber-700 font-semibold">
            {emsrComparison ? 'uploaded & compared (post-freeze)' : 'not assessed'}
          </span>
        </div>
      </div>

      {/* Two-Stage Freeze-Before-Validation Gate */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs animate-card-enter">
        {/* Stage 1: Freeze Outputs */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-900">
              Step 1: Freeze Outputs & Parameters
            </span>
            <span className="font-mono text-[11px] text-teal-700 font-semibold">
              {frozenSnapshot ? `FROZEN (${frozenSnapshot.frozenHash})` : 'UNLOCKED'}
            </span>
          </div>
          <p className="text-slate-600 leading-relaxed">
            Before loading any EMSR927 validation layer, you must freeze your uploaded Sentinel-1 candidate mask and threshold parameters so EMSR927 cannot influence parameter tuning.
          </p>

          {!frozenSnapshot ? (
            <button
              type="button"
              onClick={handleFreezeOutputs}
              className="w-full py-2 px-3 bg-teal-600 hover:bg-teal-700 text-white font-semibold rounded transition-colors"
            >
              Freeze Current Outputs & Parameters for Validation
            </button>
          ) : (
            <div className="space-y-2 font-mono text-[11px] bg-white border border-teal-300 rounded p-3 text-slate-700">
              <div className="text-teal-800 font-semibold">
                ● Snapshot Locked: {frozenSnapshot.frozenHash}
              </div>
              <div>Frozen At: {frozenSnapshot.frozenAtIso}</div>
              <div>
                Params: Threshold = {frozenSnapshot.thresholdDb} dB, MinDrop = -
                {frozenSnapshot.minDropDb} dB
              </div>
              <div>
                Frozen Candidate Pixels: {frozenSnapshot.candidatePixels.toLocaleString()} px
              </div>
              <button
                type="button"
                onClick={() => {
                  onClearFrozenSnapshot();
                  onSetEmsrComparison(null);
                }}
                className="mt-1 px-2.5 py-1 bg-rose-50 hover:bg-rose-100 text-rose-700 border border-rose-200 rounded"
              >
                Unfreeze & Reset Validation
              </button>
            </div>
          )}
        </div>

        {/* Stage 2: Compare with EMSR927 */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3">
          <div className="flex items-center justify-between">
            <span className="font-semibold text-slate-900">
              Step 2: Compare Frozen Outputs with EMSR927
            </span>
            <span className="font-mono text-[11px] text-amber-700 font-semibold">
              {frozenSnapshot ? 'READY FOR EMSR927 UPLOAD' : 'LOCKED UNTIL STEP 1 FROZEN'}
            </span>
          </div>
          <p className="text-slate-600 leading-relaxed">
            Upload an official EMSR927 vector GeoJSON file only after freezing Step 1. If no EMSR927 file is supplied, validation remains strictly reported as <code className="text-amber-700 font-semibold">not assessed</code>.
          </p>

          <input
            ref={emsrInputRef}
            type="file"
            accept=".json,.geojson"
            disabled={!frozenSnapshot}
            onChange={(e) => {
              const f = e.target.files?.[0];
              if (f) handleEmsrUpload(f);
            }}
            className="hidden"
          />
          <button
            type="button"
            disabled={!frozenSnapshot}
            onClick={() => emsrInputRef.current?.click()}
            className="w-full py-2 px-3 bg-amber-50 hover:bg-amber-100 disabled:opacity-50 text-amber-800 border border-amber-300 font-mono rounded transition-colors"
          >
            {frozenSnapshot
              ? 'Upload EMSR927 Reference GeoJSON (Post-Freeze Validation Only)'
              : 'Locked — Freeze Step 1 Outputs First'}
          </button>

          {emsrComparison && (
            <div className="bg-white border border-amber-300 rounded p-3 font-mono text-[11px] text-slate-700 space-y-1">
              <div className="text-amber-800 font-semibold">
                EMSR927 Validation Summary ({emsrComparison.referenceFileName})
              </div>
              <div>Compared Hash: {emsrComparison.comparedAgainstFrozenHash}</div>
              <div>EMSR927 Features Loaded: {emsrComparison.referencePolygonCount}</div>
              <div>
                Overlapping Candidate Blocks: {emsrComparison.overlappingCandidateBlocksCount} /{' '}
                {emsrComparison.frozenCandidateBlocksCount} (
                {(emsrComparison.overlapRatioEstimate * 100).toFixed(1)}%)
              </div>
            </div>
          )}
        </div>
      </div>

      {validationError && (
        <div className="bg-rose-50 border border-rose-300 rounded p-3 text-xs font-mono text-rose-800">
          ✖ {validationError}
        </div>
      )}
    </div>
  );
};
