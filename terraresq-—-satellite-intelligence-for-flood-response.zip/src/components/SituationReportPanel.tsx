import React from 'react';
import { jsPDF } from 'jspdf';
import {
  FrozenOutputSnapshot,
  InfrastructureAndIsolationSummary,
  InstalledAiModelManifest,
  StudyAreaConfig,
  WaterCandidateMaskResult,
} from '../types/terraresq';
import { buildOnePageSituationReport } from '../services/geospatialPipeline';

interface SituationReportPanelProps {
  studyArea: StudyAreaConfig;
  maskResult: WaterCandidateMaskResult | null;
  infraSummary: InfrastructureAndIsolationSummary;
  aiModel: InstalledAiModelManifest | null;
  frozenSnapshot: FrozenOutputSnapshot | null;
}

export const SituationReportPanel: React.FC<SituationReportPanelProps> = ({
  studyArea,
  maskResult,
  infraSummary,
  aiModel,
  frozenSnapshot,
}) => {
  const reportText = buildOnePageSituationReport({
    studyArea,
    maskResult,
    infraSummary,
    aiModel,
    frozenSnapshot,
  });

  const handleExportOnePagePdf = () => {
    const doc = new jsPDF({
      orientation: 'portrait',
      unit: 'mm',
      format: 'a4',
    });

    const pageWidth = doc.internal.pageSize.getWidth();
    const pageHeight = doc.internal.pageSize.getHeight();
    const margin = 12;
    const maxLineWidth = pageWidth - margin * 2;

    doc.setFillColor(13, 148, 136);
    doc.rect(0, 0, pageWidth, 20, 'F');
    doc.setTextColor(255, 255, 255);
    doc.setFont('courier', 'bold');
    doc.setFontSize(11);
    doc.text(
      'TERRARESQ — ONE-PAGE FLOOD EXPOSURE & ISOLATION SITUATION REPORT',
      margin,
      10
    );

    doc.setTextColor(240, 253, 250);
    doc.setFontSize(8);
    doc.text(
      `Multimodal AI Hackathon 2026 · Track B: Mapping Flood Damage from Space · Generated: ${new Date()
        .toISOString()
        .slice(0, 10)}`,
      margin,
      16
    );

    doc.setTextColor(15, 23, 42);
    doc.setFont('courier', 'normal');
    doc.setFontSize(8.2);

    const lines = doc.splitTextToSize(reportText, maxLineWidth);
    let y = 27;
    for (const line of lines) {
      if (y > pageHeight - 14) break; // Strictly keep to a clean one-page summary
      doc.text(line, margin, y);
      y += 4.1;
    }

    doc.setFontSize(7.5);
    doc.setTextColor(100, 116, 139);
    doc.text(
      'Contains modified Copernicus Sentinel data 2026 · Copernicus WorldDEM-30 · © OpenStreetMap contributors.',
      margin,
      pageHeight - 8
    );

    doc.save(`TerraResQ_OnePage_SitRep_${studyArea.eventDate}.pdf`);
  };

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-4 animate-panel-enter">
      <div className="flex flex-wrap items-start justify-between gap-3 border-b border-slate-200 pb-3">
        <div>
          <div className="text-xs font-mono text-teal-700 font-semibold">
            DETERMINISTIC ONE-PAGE SITUATION REPORT · ZERO LLM HALLUCINATION
          </div>
          <h2 className="text-base font-semibold text-slate-900 mt-0.5">
            One-Page Flood Exposure & Isolation Situation Report
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Compiled directly from verified application state without Gemini or OpenAI API calls. Unassessed items are explicitly reported as <code className="text-amber-700 font-semibold">not assessed</code>.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          <button
            type="button"
            onClick={handleExportOnePagePdf}
            className="px-4 py-2 text-xs font-semibold bg-teal-600 hover:bg-teal-700 text-white rounded-md transition-colors whitespace-nowrap shadow-xs cursor-pointer flex items-center gap-1.5"
          >
            <span>📄</span>
            <span>Generate Situation Report</span>
          </button>
          <button
            type="button"
            onClick={() => {
              const blob = new Blob([reportText], { type: 'text/plain;charset=utf-8' });
              const url = URL.createObjectURL(blob);
              const a = document.createElement('a');
              a.href = url;
              a.download = `TerraResQ_SitRep_${studyArea.eventDate}.txt`;
              a.click();
              URL.revokeObjectURL(url);
            }}
            className="px-3 py-2 text-xs font-mono font-medium bg-slate-100 hover:bg-slate-200 text-slate-800 border border-slate-300 rounded-md transition-colors whitespace-nowrap cursor-pointer"
          >
            Export TXT
          </button>
        </div>
      </div>

      <div className="bg-slate-50 border border-slate-200 rounded-md p-4 overflow-x-auto animate-card-enter">
        <pre className="text-xs font-mono text-slate-800 whitespace-pre-wrap leading-relaxed">
          {reportText}
        </pre>
      </div>
    </div>
  );
};
