/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useRef, useState } from 'react';
import {
  InfrastructureAndIsolationSummary,
  MapLayerVisibility,
  OpticalSatelliteImage,
  ParsedGeoTiffRaster,
  RasterValidationResult,
  StudyAreaConfig,
  WaterCandidateMaskResult,
} from '../types/terraresq';
import {
  createSyntheticDemoGeoTiffBuffers,
  parseGeoTiffBuffer,
} from '../services/geotiffProcessor';
import {
  createSyntheticSentinel2DemoPair,
  parseOpticalImageFile,
} from '../services/opticalProcessor';

interface BeforeAfterPanelProps {
  studyArea: StudyAreaConfig;
  preRaster: ParsedGeoTiffRaster | null;
  postRaster: ParsedGeoTiffRaster | null;
  maskResult: WaterCandidateMaskResult | null;
  validation: RasterValidationResult;
  unitsConfirmedAsDb: boolean;
  thresholdDb: number;
  minDropDb: number;
  layers: MapLayerVisibility;
  infraSummary: InfrastructureAndIsolationSummary;
  preOptical: OpticalSatelliteImage | null;
  postOptical: OpticalSatelliteImage | null;
  onUpdateRasters: (
    pre: ParsedGeoTiffRaster | null,
    post: ParsedGeoTiffRaster | null,
    isSynthetic: boolean
  ) => void;
  onUpdateOptical: (
    pre: OpticalSatelliteImage | null,
    post: OpticalSatelliteImage | null
  ) => void;
  onUpdateUnitsConfirmed: (confirmed: boolean) => void;
  onUpdateThresholds: (thresholdDb: number, minDropDb: number) => void;
  onToggleLayer: (key: keyof MapLayerVisibility) => void;
  onRunAnalysis: () => void;
  isAnalyzing: boolean;
  analysisFeedback: string | null;
}

export const BeforeAfterPanel: React.FC<BeforeAfterPanelProps> = ({
  preRaster,
  postRaster,
  maskResult,
  validation,
  unitsConfirmedAsDb,
  thresholdDb,
  minDropDb,
  layers,
  infraSummary,
  preOptical,
  postOptical,
  onUpdateRasters,
  onUpdateOptical,
  onUpdateUnitsConfirmed,
  onUpdateThresholds,
  onToggleLayer,
  onRunAnalysis,
  isAnalyzing,
  analysisFeedback,
}) => {
  const [selectedSensorTab, setSelectedSensorTab] = useState<'SAR' | 'OPTICAL'>('SAR');
  const [comparisonSliderPercent, setComparisonSliderPercent] = useState<number>(50);
  const [comparisonMode, setComparisonMode] = useState<'BEFORE_VS_AFTER' | 'AFTER_VS_MASK'>('BEFORE_VS_AFTER');
  const [maskOverlayEnabled, setMaskOverlayEnabled] = useState<boolean>(true);
  const [maskOpacity, setMaskOpacity] = useState<number>(85);
  const [maskColor, setMaskColor] = useState<'CYAN' | 'AMBER' | 'RED'>('CYAN');
  const [uploadError, setUploadError] = useState<string | null>(null);

  // File input refs
  const sarPreInputRef = useRef<HTMLInputElement | null>(null);
  const sarPostInputRef = useRef<HTMLInputElement | null>(null);
  const opticalPreInputRef = useRef<HTMLInputElement | null>(null);
  const opticalPostInputRef = useRef<HTMLInputElement | null>(null);

  // Upload handlers
  const handleSarUpload = async (file: File, role: 'PRE' | 'POST') => {
    setUploadError(null);
    try {
      const buffer = await file.arrayBuffer();
      const parsed = await parseGeoTiffBuffer(
        buffer,
        file.name,
        new Date(file.lastModified || Date.now()).toISOString().slice(0, 10),
        unitsConfirmedAsDb ? 'dB' : 'unconfirmed',
        'uploaded'
      );
      if (role === 'PRE') {
        onUpdateRasters(parsed, postRaster, false);
      } else {
        onUpdateRasters(preRaster, parsed, false);
      }
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : `Failed to parse SAR GeoTIFF ${file.name}`);
    }
  };

  const handleOpticalUpload = async (file: File, role: 'PRE' | 'POST') => {
    setUploadError(null);
    try {
      const parsed = await parseOpticalImageFile(
        file,
        role === 'PRE' ? 'PRE_EVENT' : 'POST_EVENT',
        role === 'PRE' ? '2026-08-02' : '2026-08-14'
      );
      if (role === 'PRE') {
        onUpdateOptical(parsed, postOptical);
      } else {
        onUpdateOptical(preOptical, parsed);
      }
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : `Failed to upload optical image ${file.name}`);
    }
  };

  const handleLoadSarDemoPair = async () => {
    setUploadError(null);
    try {
      const { preBuffer, postBuffer, preFileName, postFileName } =
        await createSyntheticDemoGeoTiffBuffers({ makeIncompatible: false });
      const preParsed = await parseGeoTiffBuffer(
        preBuffer,
        preFileName,
        '2026-08-02',
        'dB',
        'synthetic demo'
      );
      const postParsed = await parseGeoTiffBuffer(
        postBuffer,
        postFileName,
        '2026-08-14',
        'dB',
        'synthetic demo'
      );
      onUpdateUnitsConfirmed(true);
      onUpdateRasters(preParsed, postParsed, true);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to generate demo SAR rasters.');
    }
  };

  const handleLoadOpticalDemoPair = () => {
    setUploadError(null);
    try {
      const { preOptical: pre, postOptical: post } = createSyntheticSentinel2DemoPair();
      onUpdateOptical(pre, post);
    } catch (err) {
      setUploadError(err instanceof Error ? err.message : 'Failed to generate demo optical imagery.');
    }
  };

  const handleLoadAllDemoData = async () => {
    await handleLoadSarDemoPair();
    handleLoadOpticalDemoPair();
  };

  // Determine active display images based on selected sensor
  const activePreImage =
    selectedSensorTab === 'SAR'
      ? maskResult?.beforeDataUrl || null
      : preOptical?.dataUrl || null;

  const activePostImage =
    selectedSensorTab === 'SAR'
      ? maskResult?.afterDataUrl || null
      : postOptical?.dataUrl || null;

  const activePreMeta =
    selectedSensorTab === 'SAR'
      ? preRaster
        ? {
            sensor: 'Sentinel-1 C-SAR (VV)',
            date: preRaster.acquisitionDate,
            dims: `${preRaster.width} × ${preRaster.height} px`,
            resolution: '10 m / pixel',
            status: preRaster.sourceStatus,
            value: `Mean: ${preRaster.meanDb} dB [${preRaster.minDb}, ${preRaster.maxDb}]`,
            crs: preRaster.crsCode ? `EPSG:${preRaster.crsCode}` : 'Unprojected',
          }
        : null
      : preOptical
        ? {
            sensor: 'Sentinel-2 MSI (Optical)',
            date: preOptical.acquisitionDate,
            dims: `${preOptical.width} × ${preOptical.height} px`,
            resolution: '10 m / pixel',
            status: preOptical.sourceStatus,
            value: `Mean Reflectance: ${preOptical.meanReflectance} · Clouds: ${preOptical.cloudCoverPercent}%`,
            crs: preOptical.crsCode ? `EPSG:${preOptical.crsCode}` : 'EPSG:32645',
          }
        : null;

  const activePostMeta =
    selectedSensorTab === 'SAR'
      ? postRaster
        ? {
            sensor: 'Sentinel-1 C-SAR (VV)',
            date: postRaster.acquisitionDate,
            dims: `${postRaster.width} × ${postRaster.height} px`,
            resolution: '10 m / pixel',
            status: postRaster.sourceStatus,
            value: `Mean: ${postRaster.meanDb} dB [${postRaster.minDb}, ${postRaster.maxDb}]`,
            crs: postRaster.crsCode ? `EPSG:${postRaster.crsCode}` : 'Unprojected',
          }
        : null
      : postOptical
        ? {
            sensor: 'Sentinel-2 MSI (Optical)',
            date: postOptical.acquisitionDate,
            dims: `${postOptical.width} × ${postOptical.height} px`,
            resolution: '10 m / pixel',
            status: postOptical.sourceStatus,
            value: `Mean Reflectance: ${postOptical.meanReflectance} · Clouds: ${postOptical.cloudCoverPercent}%`,
            crs: postOptical.crsCode ? `EPSG:${postOptical.crsCode}` : 'EPSG:32645',
          }
        : null;

  const hasMissingFiles =
    selectedSensorTab === 'SAR'
      ? !preRaster || !postRaster
      : !preOptical || !postOptical;

  const maskFilterStyle =
    maskColor === 'AMBER'
      ? 'hue-rotate(180deg) saturate(200%)'
      : maskColor === 'RED'
        ? 'hue-rotate(280deg) saturate(250%)'
        : 'none';

  return (
    <div className="bg-white border border-slate-200 rounded-md p-5 space-y-6 animate-panel-enter">
      {/* 1. Header with Sensor Toggle & Run Analysis Action */}
      <div className="flex flex-col lg:flex-row lg:items-center justify-between gap-4 border-b border-slate-200 pb-4">
        <div>
          <div className="flex items-center gap-2">
            <span className="text-xs font-mono font-bold tracking-wider text-teal-700 uppercase">
              SATELLITE IMAGERY WORKBENCH
            </span>
            <span className="text-slate-300">|</span>
            <span className="text-xs font-mono text-slate-500">
              Sentinel-1 SAR & Sentinel-2 Optical Multi-Sensor Section
            </span>
          </div>
          <h2 className="text-lg font-bold text-slate-900 mt-1">
            Before & After Satellite Analysis & Side-by-Side Comparison
          </h2>
          <p className="text-xs text-slate-600 mt-0.5">
            Ingest co-registered pre-event and post-event imagery, calibrate flood thresholds, inspect spectral changes, and compute defensible flood extent overlays.
          </p>
        </div>

        {/* Action Buttons: Sensor Mode, Run Analysis, Load Demo Data */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* Sensor Selector Switch */}
          <div className="flex items-center bg-slate-100 p-1 rounded-md border border-slate-200 text-xs font-mono">
            <button
              type="button"
              onClick={() => setSelectedSensorTab('SAR')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer ${
                selectedSensorTab === 'SAR'
                  ? 'bg-white text-teal-800 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sentinel-1 SAR
            </button>
            <button
              type="button"
              onClick={() => setSelectedSensorTab('OPTICAL')}
              className={`px-3 py-1.5 rounded transition-all cursor-pointer ${
                selectedSensorTab === 'OPTICAL'
                  ? 'bg-white text-teal-800 font-semibold shadow-xs'
                  : 'text-slate-600 hover:text-slate-900'
              }`}
            >
              Sentinel-2 Optical
            </button>
          </div>

          {/* Functional Run Analysis Button */}
          <button
            type="button"
            onClick={onRunAnalysis}
            disabled={isAnalyzing}
            className={`px-4 py-2 text-xs font-semibold rounded-md border transition-all flex items-center gap-2 shadow-xs cursor-pointer ${
              isAnalyzing
                ? 'bg-teal-700 text-white border-teal-800 opacity-80 cursor-wait'
                : 'bg-teal-600 hover:bg-teal-700 text-white border-teal-700 active:scale-98'
            }`}
          >
            {isAnalyzing ? (
              <>
                <svg
                  className="animate-spin h-3.5 w-3.5 text-white"
                  xmlns="http://www.w3.org/2000/svg"
                  fill="none"
                  viewBox="0 0 24 24"
                >
                  <circle
                    className="opacity-25"
                    cx="12"
                    cy="12"
                    r="10"
                    stroke="currentColor"
                    strokeWidth="4"
                  />
                  <path
                    className="opacity-75"
                    fill="currentColor"
                    d="M4 12a8 8 0 018-8v8H4z"
                  />
                </svg>
                <span>Running Geospatial Analysis...</span>
              </>
            ) : (
              <>
                <span>▶</span>
                <span>Run Analysis</span>
              </>
            )}
          </button>

          {/* Quick Demo Data Loader */}
          <button
            type="button"
            onClick={handleLoadAllDemoData}
            className="px-3.5 py-2 text-xs font-semibold bg-amber-50 hover:bg-amber-100 text-amber-800 border border-amber-300 rounded-md transition-colors whitespace-nowrap cursor-pointer shadow-xs"
            title="Load calibrated Sentinel-1 SAR GeoTIFF pair and Sentinel-2 Optical demonstration pair"
          >
            [ Load Sample Flood Scenario ]
          </button>
        </div>
      </div>

      {/* Analysis Feedback / Processing Status Notification */}
      {analysisFeedback && (
        <div
          className={`p-3 rounded-md text-xs font-mono border flex items-center justify-between gap-3 animate-panel-enter animate-status-flash ${
            analysisFeedback.startsWith('Error') || analysisFeedback.startsWith('Analysis Blocked')
              ? 'bg-rose-50 border-rose-300 text-rose-800'
              : 'bg-teal-50 border-teal-300 text-teal-900'
          }`}
        >
          <div className="flex items-center gap-2">
            <span>
              {analysisFeedback.startsWith('Error') || analysisFeedback.startsWith('Analysis Blocked')
                ? '✖'
                : '✔'}
            </span>
            <span>{analysisFeedback}</span>
          </div>
          {hasMissingFiles && (
            <button
              type="button"
              onClick={handleLoadAllDemoData}
              className="px-2.5 py-1 bg-amber-600 hover:bg-amber-700 text-white text-[11px] font-semibold rounded transition-colors whitespace-nowrap cursor-pointer"
            >
              Load Demo Data Now
            </button>
          )}
        </div>
      )}

      {/* Missing Files Notice when no images loaded */}
      {hasMissingFiles && !analysisFeedback && (
        <div className="bg-amber-50 border border-amber-300 rounded-md p-4 text-xs">
          <div className="flex items-start justify-between gap-3">
            <div className="space-y-1">
              <div className="font-semibold text-amber-900 flex items-center gap-1.5">
                <span>▲</span>
                <span>
                  {selectedSensorTab === 'SAR'
                    ? 'Sentinel-1 SAR Imagery Missing'
                    : 'Sentinel-2 Optical Imagery Missing'}
                </span>
              </div>
              <p className="text-amber-800">
                To execute flood change detection and infrastructure exposure mapping, provide both Pre-Event and Post-Event satellite imagery below, or load the pre-calibrated sample dataset.
              </p>
            </div>
            <button
              type="button"
              onClick={
                selectedSensorTab === 'SAR' ? handleLoadSarDemoPair : handleLoadOpticalDemoPair
              }
              className="px-3 py-1.5 bg-amber-600 hover:bg-amber-700 text-white rounded text-xs font-semibold whitespace-nowrap transition-colors cursor-pointer"
            >
              Load {selectedSensorTab} Demo Data
            </button>
          </div>
        </div>
      )}

      {/* Upload Error Banner */}
      {uploadError && (
        <div className="bg-rose-50 border border-rose-300 rounded-md p-3.5 text-xs text-rose-800 font-mono">
          ✖ File Upload Error: {uploadError}
        </div>
      )}

      {/* 2. Upload Controls Section (Sentinel-1 SAR & Sentinel-2 Optical) */}
      <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3 animate-card-enter">
        <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-200 pb-2">
          <div className="text-xs font-bold text-slate-800 font-mono">
            {selectedSensorTab === 'SAR'
              ? 'SENTINEL-1 SAR UPLOAD CONTROLS (Single/Dual-Pol .tif)'
              : 'SENTINEL-2 OPTICAL UPLOAD CONTROLS (True Color RGB / Multi-Spectral)'}
          </div>
          <div className="text-[11px] font-mono text-slate-500 flex flex-wrap items-center gap-2">
            <span>Formats: GeoTIFF (.tif, .tiff), PNG, JPEG · Max: 120 MB</span>
            <span className="text-slate-300">|</span>
            <a
              href="https://dataspace.copernicus.eu/browser/"
              target="_blank"
              rel="noopener noreferrer"
              className="text-teal-700 hover:text-teal-900 underline font-semibold flex items-center gap-1"
            >
              <span>Copernicus Browser (CDSE) ↗</span>
            </a>
          </div>
        </div>

        <div className="bg-slate-100/80 border border-slate-200 rounded p-2.5 text-[11px] font-mono text-slate-700 flex flex-wrap items-center justify-between gap-2">
          <div>
            <span className="font-bold text-slate-900">REAL SATELLITE DATA MODE VALIDATION:</span>{' '}
            Input GeoTIFFs are validated for dimensions, single-band Sentinel-1 VV polarizations, decibel calibration, nodata tags, and projected CRS (e.g. EPSG:32645).
          </div>
          <div className="text-slate-500">
            Source: <a href="https://dataspace.copernicus.eu/browser/" target="_blank" rel="noopener noreferrer" className="text-teal-700 underline">dataspace.copernicus.eu</a>
          </div>
        </div>

        {selectedSensorTab === 'SAR' ? (
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {/* Pre-Event SAR Card */}
            <div className="bg-white border border-slate-200 rounded p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">1. Pre-Event Sentinel-1 VV (.tif)</span>
                <span className="text-[11px] font-mono text-slate-500">
                  {preRaster ? preRaster.sourceStatus : 'not assessed'}
                </span>
              </div>
              <input
                ref={sarPreInputRef}
                type="file"
                accept=".tif,.tiff"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleSarUpload(f, 'PRE');
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => sarPreInputRef.current?.click()}
                className="w-full py-2 px-3 bg-slate-50 hover:bg-teal-50 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors truncate cursor-pointer text-left flex items-center justify-between"
              >
                <span>{preRaster ? `✓ ${preRaster.fileName}` : 'Choose Pre-Event GeoTIFF...'}</span>
                <span className="text-[10px] text-slate-400">Browse</span>
              </button>
              {preRaster && (
                <div className="text-[11px] font-mono text-slate-600">
                  Acquired: {preRaster.acquisitionDate} · Grid: {preRaster.width}×{preRaster.height} · Mean: {preRaster.meanDb} dB
                </div>
              )}
            </div>

            {/* Post-Event SAR Card */}
            <div className="bg-white border border-slate-200 rounded p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">2. Post-Event Sentinel-1 VV (.tif)</span>
                <span className="text-[11px] font-mono text-slate-500">
                  {postRaster ? postRaster.sourceStatus : 'not assessed'}
                </span>
              </div>
              <input
                ref={sarPostInputRef}
                type="file"
                accept=".tif,.tiff"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleSarUpload(f, 'POST');
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => sarPostInputRef.current?.click()}
                className="w-full py-2 px-3 bg-slate-50 hover:bg-teal-50 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors truncate cursor-pointer text-left flex items-center justify-between"
              >
                <span>{postRaster ? `✓ ${postRaster.fileName}` : 'Choose Post-Event GeoTIFF...'}</span>
                <span className="text-[10px] text-slate-400">Browse</span>
              </button>
              {postRaster && (
                <div className="text-[11px] font-mono text-slate-600">
                  Acquired: {postRaster.acquisitionDate} · Grid: {postRaster.width}×{postRaster.height} · Mean: {postRaster.meanDb} dB
                </div>
              )}
            </div>

            {/* Threshold & Calibration Quick Knobs */}
            <div className="bg-white border border-slate-200 rounded p-3 space-y-2">
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-700">Backscatter Threshold:</span>
                <span className="text-teal-700 font-bold">{thresholdDb.toFixed(1)} dB</span>
              </div>
              <input
                type="range"
                min={-24.0}
                max={-12.0}
                step={0.5}
                value={thresholdDb}
                onChange={(e) => onUpdateThresholds(Number(e.target.value), minDropDb)}
                className="w-full accent-teal-600 cursor-pointer"
              />
              <div className="flex items-center justify-between text-xs font-mono">
                <span className="text-slate-700">Min ΔdB Drop:</span>
                <span className="text-teal-700 font-bold">-{minDropDb.toFixed(1)} dB</span>
              </div>
              <input
                type="range"
                min={0.0}
                max={6.0}
                step={0.5}
                value={minDropDb}
                onChange={(e) => onUpdateThresholds(thresholdDb, Number(e.target.value))}
                className="w-full accent-teal-600 cursor-pointer"
              />
            </div>
          </div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {/* Pre-Event Optical Card */}
            <div className="bg-white border border-slate-200 rounded p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">1. Pre-Event Sentinel-2 Optical (RGB)</span>
                <span className="text-[11px] font-mono text-slate-500">
                  {preOptical ? preOptical.sourceStatus : 'not assessed'}
                </span>
              </div>
              <input
                ref={opticalPreInputRef}
                type="file"
                accept=".tif,.tiff,.png,.jpg,.jpeg,.webp"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleOpticalUpload(f, 'PRE');
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => opticalPreInputRef.current?.click()}
                className="w-full py-2 px-3 bg-slate-50 hover:bg-teal-50 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors truncate cursor-pointer text-left flex items-center justify-between"
              >
                <span>{preOptical ? `✓ ${preOptical.fileName}` : 'Choose Pre-Event Optical Image...'}</span>
                <span className="text-[10px] text-slate-400">Browse</span>
              </button>
              {preOptical && (
                <div className="text-[11px] font-mono text-slate-600">
                  Acquired: {preOptical.acquisitionDate} · {preOptical.width}×{preOptical.height} px · Clouds: {preOptical.cloudCoverPercent}%
                </div>
              )}
            </div>

            {/* Post-Event Optical Card */}
            <div className="bg-white border border-slate-200 rounded p-3 space-y-2">
              <div className="flex items-center justify-between text-xs">
                <span className="font-semibold text-slate-800">2. Post-Event Sentinel-2 Optical (RGB)</span>
                <span className="text-[11px] font-mono text-slate-500">
                  {postOptical ? postOptical.sourceStatus : 'not assessed'}
                </span>
              </div>
              <input
                ref={opticalPostInputRef}
                type="file"
                accept=".tif,.tiff,.png,.jpg,.jpeg,.webp"
                onChange={(e) => {
                  const f = e.target.files?.[0];
                  if (f) handleOpticalUpload(f, 'POST');
                }}
                className="hidden"
              />
              <button
                type="button"
                onClick={() => opticalPostInputRef.current?.click()}
                className="w-full py-2 px-3 bg-slate-50 hover:bg-teal-50 border border-slate-300 rounded text-xs font-mono text-teal-800 font-medium transition-colors truncate cursor-pointer text-left flex items-center justify-between"
              >
                <span>{postOptical ? `✓ ${postOptical.fileName}` : 'Choose Post-Event Optical Image...'}</span>
                <span className="text-[10px] text-slate-400">Browse</span>
              </button>
              {postOptical && (
                <div className="text-[11px] font-mono text-slate-600">
                  Acquired: {postOptical.acquisitionDate} · {postOptical.width}×{postOptical.height} px · Clouds: {postOptical.cloudCoverPercent}%
                </div>
              )}
            </div>
          </div>
        )}
      </div>

      {/* 3. Before and After Satellite Image Panels (Side-by-Side) */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5 animate-card-enter">
        {/* BEFORE PANEL */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div>
              <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 uppercase">
                PRE-EVENT SATELLITE IMAGE
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Baseline (Pre-Flood)
              </h3>
            </div>
            {activePreMeta && (
              <span
                className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                  activePreMeta.status === 'synthetic demo'
                    ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold'
                    : 'bg-teal-100 border-teal-300 text-teal-900 font-semibold'
                }`}
              >
                {activePreMeta.status === 'synthetic demo' ? 'DEMO DATA' : 'REAL UPLOAD'}
              </span>
            )}
          </div>

          {/* Visual Container */}
          <div className="relative w-full h-64 bg-slate-900 rounded border border-slate-300 overflow-hidden flex items-center justify-center">
            {activePreImage ? (
              <img
                src={activePreImage}
                alt="Before Satellite Image"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />
            ) : (
              <div className="text-center p-4 text-xs font-mono text-slate-400">
                <div>No Pre-Event {selectedSensorTab} Image Loaded</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Upload a file above or click &quot;Load Demo Data&quot;
                </div>
              </div>
            )}
            <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/75 backdrop-blur-xs text-white rounded text-[10px] font-mono">
              BEFORE · {activePreMeta?.date || 'Unspecified'}
            </div>
          </div>

          {/* Metadata Grid */}
          {activePreMeta ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono text-slate-700 bg-white p-2.5 rounded border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px]">SENSOR</span>
                <span className="font-semibold text-slate-900">{activePreMeta.sensor}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">ACQUISITION DATE</span>
                <span className="text-slate-900">{activePreMeta.date}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">RESOLUTION / DIMS</span>
                <span className="text-slate-900">{activePreMeta.dims}</span>
              </div>
              <div className="col-span-2 sm:col-span-3 border-t border-slate-100 pt-1 flex items-center justify-between">
                <span>{activePreMeta.value}</span>
                <span className="text-slate-400">{activePreMeta.crs}</span>
              </div>
            </div>
          ) : (
            <div className="text-center text-xs font-mono text-slate-400 py-2">
              Metadata pending image selection
            </div>
          )}
        </div>

        {/* AFTER PANEL */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 flex flex-col justify-between space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <div>
              <span className="text-[10px] font-mono font-bold tracking-wider text-slate-500 uppercase">
                POST-EVENT SATELLITE IMAGE
              </span>
              <h3 className="text-sm font-bold text-slate-900">
                Inundation Phase (Post-Flood)
              </h3>
            </div>
            {activePostMeta && (
              <span
                className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                  activePostMeta.status === 'synthetic demo'
                    ? 'bg-amber-100 border-amber-300 text-amber-900 font-semibold'
                    : 'bg-teal-100 border-teal-300 text-teal-900 font-semibold'
                }`}
              >
                {activePostMeta.status === 'synthetic demo' ? 'DEMO DATA' : 'REAL UPLOAD'}
              </span>
            )}
          </div>

          {/* Visual Container with optional Mask Overlay */}
          <div className="relative w-full h-64 bg-slate-900 rounded border border-slate-300 overflow-hidden flex items-center justify-center">
            {activePostImage ? (
              <>
                <img
                  src={activePostImage}
                  alt="After Satellite Image"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                />
                {maskOverlayEnabled && maskResult && (
                  <img
                    src={maskResult.maskDataUrl}
                    alt="Flood Segmentation Mask Overlay"
                    referrerPolicy="no-referrer"
                    className="absolute inset-0 w-full h-full object-contain pointer-events-none"
                    style={{
                      opacity: maskOpacity / 100,
                      filter: maskFilterStyle,
                    }}
                  />
                )}
              </>
            ) : (
              <div className="text-center p-4 text-xs font-mono text-slate-400">
                <div>No Post-Event {selectedSensorTab} Image Loaded</div>
                <div className="text-[11px] text-slate-500 mt-1">
                  Upload a file above or click &quot;Load Demo Data&quot;
                </div>
              </div>
            )}
            <div className="absolute top-2 left-2 px-2 py-0.5 bg-black/75 backdrop-blur-xs text-white rounded text-[10px] font-mono flex items-center gap-1.5">
              <span>AFTER · {activePostMeta?.date || 'Unspecified'}</span>
              {maskOverlayEnabled && maskResult && (
                <span className="text-cyan-300 text-[9px] font-semibold border-l border-white/30 pl-1.5">
                  MASK ON ({maskOpacity}%)
                </span>
              )}
            </div>
          </div>

          {/* Metadata Grid */}
          {activePostMeta ? (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-2 text-[11px] font-mono text-slate-700 bg-white p-2.5 rounded border border-slate-200">
              <div>
                <span className="text-slate-400 block text-[10px]">SENSOR</span>
                <span className="font-semibold text-slate-900">{activePostMeta.sensor}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">ACQUISITION DATE</span>
                <span className="text-slate-900">{activePostMeta.date}</span>
              </div>
              <div>
                <span className="text-slate-400 block text-[10px]">RESOLUTION / DIMS</span>
                <span className="text-slate-900">{activePostMeta.dims}</span>
              </div>
              <div className="col-span-2 sm:col-span-3 border-t border-slate-100 pt-1 flex items-center justify-between">
                <span>{activePostMeta.value}</span>
                <span className="text-slate-400">{activePostMeta.crs}</span>
              </div>
            </div>
          ) : (
            <div className="text-center text-xs font-mono text-slate-400 py-2">
              Metadata pending image selection
            </div>
          )}
        </div>
      </div>

      {/* 4. Side-by-Side Image Comparison Slider */}
      <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-4 animate-card-enter">
        <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-3 border-b border-slate-200 pb-3">
          <div>
            <div className="text-xs font-mono font-bold text-teal-700 uppercase">
              INTERACTIVE COMPARISON SLIDER
            </div>
            <h3 className="text-sm font-bold text-slate-900">
              Side-by-Side Split View & Curtain Slider
            </h3>
          </div>

          <div className="flex flex-wrap items-center gap-2">
            {/* Mode Switcher */}
            <div className="flex items-center bg-white p-1 rounded border border-slate-200 text-xs font-mono">
              <button
                type="button"
                onClick={() => setComparisonMode('BEFORE_VS_AFTER')}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  comparisonMode === 'BEFORE_VS_AFTER'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                Before vs After
              </button>
              <button
                type="button"
                onClick={() => setComparisonMode('AFTER_VS_MASK')}
                className={`px-2.5 py-1 rounded transition-colors cursor-pointer ${
                  comparisonMode === 'AFTER_VS_MASK'
                    ? 'bg-slate-900 text-white font-semibold'
                    : 'text-slate-600 hover:text-slate-900'
                }`}
              >
                After vs Flood Mask
              </button>
            </div>

            {/* Quick Preset Buttons */}
            <div className="flex items-center gap-1 text-[11px] font-mono">
              <button
                type="button"
                onClick={() => setComparisonSliderPercent(0)}
                className="px-2 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 cursor-pointer"
              >
                100% Right
              </button>
              <button
                type="button"
                onClick={() => setComparisonSliderPercent(50)}
                className="px-2 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 font-semibold cursor-pointer"
              >
                50 / 50
              </button>
              <button
                type="button"
                onClick={() => setComparisonSliderPercent(100)}
                className="px-2 py-1 bg-white hover:bg-slate-100 border border-slate-200 rounded text-slate-700 cursor-pointer"
              >
                100% Left
              </button>
            </div>
          </div>
        </div>

        {/* Curtain Slider Viewer */}
        <div className="relative w-full h-80 bg-slate-900 rounded-md border border-slate-300 overflow-hidden select-none">
          {activePreImage && activePostImage ? (
            <>
              {/* Left Layer: Before Image or Post Image */}
              <img
                src={comparisonMode === 'BEFORE_VS_AFTER' ? activePreImage : activePostImage}
                alt="Left layer"
                referrerPolicy="no-referrer"
                className="w-full h-full object-contain"
              />

              {/* Right Layer (Clipped by slider percentage): After Image or Mask */}
              <div
                className="absolute inset-0 overflow-hidden"
                style={{
                  clipPath: `inset(0 0 0 ${comparisonSliderPercent}%)`,
                }}
              >
                <img
                  src={
                    comparisonMode === 'BEFORE_VS_AFTER'
                      ? activePostImage
                      : maskResult?.maskDataUrl || activePostImage
                  }
                  alt="Right layer"
                  referrerPolicy="no-referrer"
                  className="w-full h-full object-contain"
                  style={{
                    filter:
                      comparisonMode === 'AFTER_VS_MASK' ? maskFilterStyle : 'none',
                  }}
                />
              </div>

              {/* Draggable Divider Line */}
              <div
                className="absolute top-0 bottom-0 w-0.5 bg-white shadow-lg pointer-events-none"
                style={{ left: `${comparisonSliderPercent}%` }}
              >
                <div className="absolute top-1/2 -translate-y-1/2 -translate-x-1/2 w-8 h-8 rounded-full bg-white shadow-md border-2 border-teal-600 flex items-center justify-center text-slate-900 text-xs font-bold">
                  ↔
                </div>
              </div>

              {/* Left Label */}
              <div className="absolute bottom-3 left-3 px-2.5 py-1 bg-black/80 backdrop-blur-xs text-white rounded text-xs font-mono">
                {comparisonMode === 'BEFORE_VS_AFTER' ? '◀ BEFORE (Pre-Event)' : '◀ BASELINE SATELLITE'}
              </div>

              {/* Right Label */}
              <div className="absolute bottom-3 right-3 px-2.5 py-1 bg-black/80 backdrop-blur-xs text-white rounded text-xs font-mono">
                {comparisonMode === 'BEFORE_VS_AFTER'
                  ? 'AFTER (Inundated) ▶'
                  : 'FLOOD SEGMENTATION MASK ▶'}
              </div>

              {/* Live Position Badge */}
              <div className="absolute top-3 left-1/2 -translate-x-1/2 px-2 py-0.5 bg-slate-900/90 text-teal-300 border border-slate-700 rounded text-[10px] font-mono">
                Split: {comparisonSliderPercent}%
              </div>
            </>
          ) : (
            <div className="w-full h-full flex flex-col items-center justify-center text-xs font-mono text-slate-400 p-4 text-center">
              <div>Comparison slider requires both Pre-Event and Post-Event imagery.</div>
              <button
                type="button"
                onClick={handleLoadAllDemoData}
                className="mt-3 px-3 py-1.5 bg-teal-600 hover:bg-teal-700 text-white rounded font-sans font-semibold transition-colors cursor-pointer"
              >
                Load Demo Imagery Pair
              </button>
            </div>
          )}
        </div>

        {/* Native Horizontal Range Slider for fine control / touch support */}
        <div className="space-y-1">
          <input
            type="range"
            min={0}
            max={100}
            value={comparisonSliderPercent}
            onChange={(e) => setComparisonSliderPercent(Number(e.target.value))}
            className="w-full accent-teal-600 cursor-pointer h-2 bg-slate-200 rounded-lg"
            aria-label="Comparison slider position"
          />
          <div className="flex justify-between text-[10px] font-mono text-slate-500">
            <span>0% (Full Right Layer)</span>
            <span>Slide to compare Before & After imagery</span>
            <span>100% (Full Left Layer)</span>
          </div>
        </div>
      </div>

      {/* 5. Flood Segmentation Mask Overlay & Map Layer Controls */}
      <div className="grid grid-cols-1 lg:grid-cols-3 gap-4 animate-card-enter">
        {/* Mask Overlay Controls */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <span className="text-xs font-bold text-slate-900">
              Flood Mask Overlay Configuration
            </span>
            <label className="flex items-center gap-1.5 text-xs font-mono text-slate-700 cursor-pointer">
              <input
                type="checkbox"
                checked={maskOverlayEnabled}
                onChange={(e) => setMaskOverlayEnabled(e.target.checked)}
                className="accent-teal-600"
              />
              <span>Overlay Active</span>
            </label>
          </div>

          {/* Opacity Slider */}
          <div className="space-y-1">
            <div className="flex justify-between text-xs font-mono">
              <span className="text-slate-600">Mask Opacity:</span>
              <span className="font-semibold text-slate-900">{maskOpacity}%</span>
            </div>
            <input
              type="range"
              min={10}
              max={100}
              value={maskOpacity}
              onChange={(e) => setMaskOpacity(Number(e.target.value))}
              className="w-full accent-teal-600 cursor-pointer"
            />
          </div>

          {/* Color Palette Choice */}
          <div className="space-y-1">
            <span className="text-xs font-mono text-slate-600 block">Overlay Symbology Color:</span>
            <div className="flex items-center gap-2">
              <button
                type="button"
                onClick={() => setMaskColor('CYAN')}
                className={`flex-1 py-1 px-2 rounded border text-xs font-mono cursor-pointer flex items-center justify-center gap-1.5 ${
                  maskColor === 'CYAN'
                    ? 'bg-teal-50 border-teal-600 text-teal-900 font-bold'
                    : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-400 border border-teal-600" />
                <span>Cyan</span>
              </button>
              <button
                type="button"
                onClick={() => setMaskColor('AMBER')}
                className={`flex-1 py-1 px-2 rounded border text-xs font-mono cursor-pointer flex items-center justify-center gap-1.5 ${
                  maskColor === 'AMBER'
                    ? 'bg-amber-50 border-amber-600 text-amber-900 font-bold'
                    : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-amber-400 border border-amber-600" />
                <span>Amber</span>
              </button>
              <button
                type="button"
                onClick={() => setMaskColor('RED')}
                className={`flex-1 py-1 px-2 rounded border text-xs font-mono cursor-pointer flex items-center justify-center gap-1.5 ${
                  maskColor === 'RED'
                    ? 'bg-rose-50 border-rose-600 text-rose-900 font-bold'
                    : 'bg-white border-slate-200 text-slate-700'
                }`}
              >
                <span className="w-2.5 h-2.5 rounded-full bg-rose-500 border border-rose-700" />
                <span>Crimson</span>
              </button>
            </div>
          </div>

          {/* Segmentation Legend */}
          <div className="text-[11px] font-mono text-slate-600 space-y-1 bg-white p-2 rounded border border-slate-200">
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-xs bg-cyan-400 border border-cyan-600 shrink-0" />
              <span>New Water-Candidate Inundation</span>
            </div>
            <div className="flex items-center gap-2">
              <span className="w-3 h-3 rounded-xs bg-sky-700 border border-sky-900 shrink-0" />
              <span>Pre-Existing Water Channel (River Baseline)</span>
            </div>
          </div>
        </div>

        {/* Flood Extent & Analysis Output Stats */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3">
          <div className="text-xs font-bold text-slate-900 border-b border-slate-200 pb-2">
            Flood Segmentation Mask Quantities
          </div>

          <div className="grid grid-cols-2 gap-3 text-xs">
            <div className="bg-white p-2.5 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px]">CANDIDATE PIXELS</span>
              <span className="text-base font-mono font-bold text-teal-700">
                {maskResult ? maskResult.newCandidatePixels.toLocaleString() : '0'}
              </span>
              <span className="text-[10px] text-slate-400 ml-1">px</span>
            </div>

            <div className="bg-white p-2.5 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px]">DEFENSIBLE FLOOD AREA</span>
              <span className="text-base font-mono font-bold text-blue-700">
                {maskResult?.newCandidateAreaSqKm !== null && maskResult?.newCandidateAreaSqKm !== undefined
                  ? `${maskResult.newCandidateAreaSqKm.toFixed(3)} km²`
                  : 'not assessed'}
              </span>
            </div>

            <div className="bg-white p-2.5 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px]">EVALUATED CELLS</span>
              <span className="text-xs font-mono font-semibold text-slate-800">
                {maskResult ? maskResult.validEvaluatedPixels.toLocaleString() : '0'} px
              </span>
            </div>

            <div className="bg-white p-2.5 rounded border border-slate-200">
              <span className="text-slate-500 block text-[10px]">METHOD & INTEGRITY</span>
              <span className="text-[11px] font-mono font-semibold text-amber-800">
                {maskResult ? maskResult.methodLabel : 'Pending Run'}
              </span>
            </div>
          </div>

          <div className="text-[11px] text-slate-500 font-mono">
            {maskResult
              ? `Derived via low-backscatter difference thresholding (${maskResult.thresholdDb} dB, Δ${maskResult.minDropDb} dB).`
              : 'Click "Run Analysis" to compute flood candidate mask.'}
          </div>
        </div>

        {/* Synchronized Map Layer Toggles */}
        <div className="bg-slate-50 border border-slate-200 rounded-md p-4 space-y-3">
          <div className="flex items-center justify-between border-b border-slate-200 pb-2">
            <span className="text-xs font-bold text-slate-900">
              Interactive Map Layers
            </span>
            <span className="text-[11px] font-mono text-teal-700 font-medium">
              Live Layer Stack
            </span>
          </div>

          <div className="grid grid-cols-2 gap-2 text-xs font-mono">
            <label className="flex items-center gap-2 p-1.5 bg-white rounded border border-slate-200 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={layers.waterCandidateMask}
                onChange={() => onToggleLayer('waterCandidateMask')}
                className="accent-teal-600"
              />
              <span className="text-slate-800 truncate">Flood Extent</span>
            </label>

            <label className="flex items-center gap-2 p-1.5 bg-white rounded border border-slate-200 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={layers.osmRoads}
                onChange={() => onToggleLayer('osmRoads')}
                className="accent-teal-600"
              />
              <span className="text-slate-800 truncate">
                Roads ({infraSummary.impassableRoadsCount ?? 0} blocked)
              </span>
            </label>

            <label className="flex items-center gap-2 p-1.5 bg-white rounded border border-slate-200 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={layers.osmBuildings}
                onChange={() => onToggleLayer('osmBuildings')}
                className="accent-teal-600"
              />
              <span className="text-slate-800 truncate">
                Buildings ({infraSummary.exposedBuildingsCount ?? 0} exp)
              </span>
            </label>

            <label className="flex items-center gap-2 p-1.5 bg-white rounded border border-slate-200 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={layers.osmBridges}
                onChange={() => onToggleLayer('osmBridges')}
                className="accent-teal-600"
              />
              <span className="text-slate-800 truncate">
                Bridges ({infraSummary.exposedBridgesCount ?? 0} exp)
              </span>
            </label>

            <label className="flex items-center gap-2 p-1.5 bg-white rounded border border-slate-200 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={layers.osmHospitalsAndTowns}
                onChange={() => onToggleLayer('osmHospitalsAndTowns')}
                className="accent-teal-600"
              />
              <span className="text-slate-800 truncate">Hospitals [H]</span>
            </label>

            <label className="flex items-center gap-2 p-1.5 bg-white rounded border border-slate-200 cursor-pointer hover:bg-slate-50">
              <input
                type="checkbox"
                checked={layers.osmSettlements}
                onChange={() => onToggleLayer('osmSettlements')}
                className="accent-teal-600"
              />
              <span className="text-slate-800 truncate">
                Settlements ({infraSummary.candidateCutOffSettlementsCount ?? 0} cut-off)
              </span>
            </label>

            <label className="flex items-center gap-2 p-1.5 bg-purple-50/60 rounded border border-purple-200 cursor-pointer hover:bg-purple-100/50">
              <input
                type="checkbox"
                checked={Boolean(layers.groundTruthFloodMask)}
                onChange={() => onToggleLayer('groundTruthFloodMask')}
                className="accent-purple-600"
              />
              <span className="text-purple-900 truncate font-semibold">
                Ground-Truth (Kuro Siwo)
              </span>
            </label>
          </div>

          <div className="text-[10px] font-mono text-slate-500 pt-1">
            Checked layers are actively rendered on the interactive Leaflet map above. Ground truth labels are strictly isolated from model predictions.
          </div>
        </div>
      </div>
    </div>
  );
};
