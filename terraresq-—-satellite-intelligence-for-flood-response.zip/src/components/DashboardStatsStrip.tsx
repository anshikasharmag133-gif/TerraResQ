import React from 'react';
import {
  EmsrValidationComparison,
  InfrastructureAndIsolationSummary,
  InstalledAiModelManifest,
  WaterCandidateMaskResult,
} from '../types/terraresq';

interface DashboardStatsStripProps {
  maskResult: WaterCandidateMaskResult | null;
  infraSummary: InfrastructureAndIsolationSummary;
  installedAiModel: InstalledAiModelManifest | null;
  emsrComparison: EmsrValidationComparison | null;
  isAnalyzing?: boolean;
}

export const DashboardStatsStrip: React.FC<DashboardStatsStripProps> = ({
  maskResult,
  infraSummary,
  installedAiModel,
  emsrComparison,
  isAnalyzing = false,
}) => {
  const cardBaseClass =
    'bg-white border rounded-md p-3 flex flex-col justify-between transition-all duration-200 hover:border-slate-300 hover:shadow-xs animate-card-enter';

  return (
    <section
      aria-label="Provenance-Verified Telemetry Summary"
      className="grid grid-cols-2 sm:grid-cols-4 xl:grid-cols-8 gap-3"
    >
      {/* 1. Candidate Pixel Count */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '30ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">Water-Candidate Pixels</div>
        <div className="text-xl font-mono font-semibold tabular-nums text-teal-700 mt-1">
          {maskResult ? `${maskResult.newCandidatePixels.toLocaleString()} px` : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          Status: {maskResult ? maskResult.sourceStatus : 'not assessed'}
        </div>
      </div>

      {/* 2. Defensible Candidate Area */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '60ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">Candidate Area</div>
        <div className="text-xl font-mono font-semibold tabular-nums text-blue-700 mt-1">
          {maskResult && maskResult.areaDefensible && maskResult.newCandidateAreaSqKm !== null
            ? `${maskResult.newCandidateAreaSqKm.toFixed(3)} km²`
            : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          {maskResult?.areaDefensible ? 'Metric CRS verified' : 'Requires metric CRS'}
        </div>
      </div>

      {/* 3. Exposed Buildings */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '90ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">Exposed Buildings</div>
        <div className="text-xl font-mono font-semibold tabular-nums text-amber-700 mt-1">
          {infraSummary.exposedBuildingsCount !== null
            ? `${infraSummary.exposedBuildingsCount} / ${infraSummary.totalBuildingsCount}`
            : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          Status: {infraSummary.status}
        </div>
      </div>

      {/* 4. Exposed / Impassable Roads */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '120ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">Assumed Impassable Roads</div>
        <div className="text-xl font-mono font-semibold tabular-nums text-rose-600 mt-1">
          {infraSummary.impassableRoadsCount !== null
            ? `${infraSummary.impassableRoadsCount} / ${infraSummary.totalRoadsCount}`
            : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          Status: {infraSummary.status}
        </div>
      </div>

      {/* 5. Exposed Bridges */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '150ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">Exposed Bridges</div>
        <div className="text-xl font-mono font-semibold tabular-nums text-amber-700 mt-1">
          {infraSummary.exposedBridgesCount !== null
            ? `${infraSummary.exposedBridgesCount} / ${infraSummary.totalBridgesCount}`
            : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          Exposure estimate only
        </div>
      </div>

      {/* 6. Candidate Cut-Off Settlements */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '180ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">Candidate Cut-Off Nodes</div>
        <div className="text-xl font-mono font-semibold tabular-nums text-rose-600 mt-1">
          {infraSummary.candidateCutOffSettlementsCount !== null
            ? `${infraSummary.candidateCutOffSettlementsCount}`
            : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          Status: {infraSummary.status}
        </div>
      </div>

      {/* 7. AI Model Status */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '210ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">AI Segmentation Model</div>
        <div className="text-sm font-mono font-semibold text-amber-700 mt-1 truncate">
          {installedAiModel ? installedAiModel.modelName : 'AI model not installed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          Status: {installedAiModel ? installedAiModel.provenanceStatus : 'not assessed'}
        </div>
      </div>

      {/* 8. EMSR927 Validation Status */}
      <div
        className={`${cardBaseClass} ${
          isAnalyzing ? 'border-teal-400 animate-analysis-pulse' : 'border-slate-200'
        }`}
        style={{ animationDelay: '240ms' }}
      >
        <div className="text-xs text-slate-500 font-medium">EMSR927 Validation</div>
        <div className="text-sm font-mono font-semibold text-slate-800 mt-1 truncate">
          {emsrComparison
            ? `${(emsrComparison.overlapRatioEstimate * 100).toFixed(1)}% overlap`
            : 'not assessed'}
        </div>
        <div className="text-[10px] font-mono text-slate-500 mt-1">
          {emsrComparison ? 'Post-freeze compared' : 'Freeze outputs first'}
        </div>
      </div>
    </section>
  );
};
