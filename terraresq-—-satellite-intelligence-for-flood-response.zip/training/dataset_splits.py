"""
TerraResQ — Geographic & Event-Based Split Validator
Enforces the strict data-integrity requirement:
- Train, validation, and held-out test splits MUST be partitioned by distinct
  geographic event / scene IDs.
- Patches from the same satellite scene or flood event MUST NEVER be randomly
  mixed across train, validation, and test splits (preventing spatial autocorrelation leakage).
"""

from typing import List, Dict, Set, Any


class SpatialLeakageError(ValueError):
    """Raised when patches from the same scene or flood event appear in multiple splits."""
    pass


def verify_event_disjoint_splits(
    manifest_records: List[Dict[str, Any]]
) -> Dict[str, Any]:
    """
    Validate a list of patch records, where each record contains:
      - 'patch_id': str
      - 'scene_id': str (e.g., 'S1A_IW_GRDH_1SDV_...')
      - 'event_id': str (e.g., 'Bolivia_2018', 'Mekong_2018', 'Ghana_2018')
      - 'split': 'train' | 'val' | 'test'
      - 'source_dataset': 'Sen1Floods11' | 'KuroSiwo'

    Raises SpatialLeakageError if any event_id or scene_id is shared across splits,
    or if any prohibited source (EMSR927, Copernicus EMS, UNOSAT, post-event OSM) is present.
    """
    prohibited_keywords = {"emsr", "copernicus_ems", "unosat", "post_event_osm"}

    splits_by_event: Dict[str, Set[str]] = {"train": set(), "val": set(), "test": set()}
    splits_by_scene: Dict[str, Set[str]] = {"train": set(), "val": set(), "test": set()}
    patch_counts: Dict[str, int] = {"train": 0, "val": 0, "test": 0}

    for rec in manifest_records:
        src = str(rec.get("source_dataset", "")).lower()
        for banned in prohibited_keywords:
            if banned in src:
                raise SpatialLeakageError(
                    f"Prohibited dataset source '{rec.get('source_dataset')}' detected in patch "
                    f"'{rec.get('patch_id')}'. EMS/UNOSAT products and post-event OSM must never "
                    f"be used as training labels, tuning data, or model inputs."
                )

        split = rec.get("split")
        if split not in ("train", "val", "test"):
            raise ValueError(f"Invalid split '{split}' for patch {rec.get('patch_id')}")

        splits_by_event[split].add(str(rec["event_id"]))
        splits_by_scene[split].add(str(rec["scene_id"]))
        patch_counts[split] += 1

    # Check pairwise disjointness of events
    for s1, s2 in [("train", "val"), ("train", "test"), ("val", "test")]:
        shared_events = splits_by_event[s1].intersection(splits_by_event[s2])
        if shared_events:
            raise SpatialLeakageError(
                f"Spatial/Event leakage detected! Event IDs {sorted(shared_events)} appear in "
                f"both '{s1}' and '{s2}' splits. Partition strictly by event/region."
            )
        shared_scenes = splits_by_scene[s1].intersection(splits_by_scene[s2])
        if shared_scenes:
            raise SpatialLeakageError(
                f"Scene leakage detected! Scene IDs {sorted(shared_scenes)} appear in "
                f"both '{s1}' and '{s2}' splits."
            )

    return {
        "verified_disjoint": True,
        "split_strategy": "Geographic / Event-Grouped Disjoint Partition",
        "events_per_split": {k: sorted(list(v)) for k, v in splits_by_event.items()},
        "scenes_per_split": {k: len(v) for k, v in splits_by_scene.items()},
        "patches_per_split": patch_counts,
    }
