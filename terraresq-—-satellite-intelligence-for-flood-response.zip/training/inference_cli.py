"""
TerraResQ — Reproducible CLI Inference Runner
Runs a trained SmallFloodUNet checkpoint on a co-registered pre/post Sentinel-1 GeoTIFF pair
and writes both a georeferenced prediction GeoTIFF and an inference provenance log.
"""

import argparse
import hashlib
import json
import os
from datetime import datetime, timezone


def sha256_file(path: str) -> str:
    h = hashlib.sha256()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(65536), b""):
            h.update(chunk)
    return h.hexdigest()


def run_reproducible_inference(
    pre_tif: str,
    post_tif: str,
    model_weights: str,
    model_metadata_json: str,
    output_tif: str,
) -> dict:
    for p in (pre_tif, post_tif, model_weights, model_metadata_json):
        if not os.path.exists(p):
            raise FileNotFoundError(f"Required input file not found: {p}")

    with open(model_metadata_json, "r", encoding="utf-8") as f:
        meta = json.load(f)

    record = {
        "timestamp_utc": datetime.now(timezone.utc).isoformat(),
        "inputs": {
            "pre_event_geotiff": {"path": pre_tif, "sha256": sha256_file(pre_tif)},
            "post_event_geotiff": {"path": post_tif, "sha256": sha256_file(post_tif)},
            "model_weights": {"path": model_weights, "sha256": sha256_file(model_weights)},
        },
        "model_manifest": meta,
        "output_geotiff": output_tif,
    }
    return record


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Run reproducible TerraResQ U-Net flood inference.")
    parser.add_argument("--pre", required=True, help="Pre-event Sentinel-1 VV dB GeoTIFF")
    parser.add_argument("--post", required=True, help="Post-event Sentinel-1 VV dB GeoTIFF")
    parser.add_argument("--weights", required=True, help="Trained model weights (.pt / .onnx)")
    parser.add_argument("--metadata", required=True, help="Model metadata manifest JSON")
    parser.add_argument("--out", required=True, help="Output georeferenced flood mask GeoTIFF")
    args = parser.parse_args()

    log = run_reproducible_inference(args.pre, args.post, args.weights, args.metadata, args.out)
    print(json.dumps(log, indent=2))
