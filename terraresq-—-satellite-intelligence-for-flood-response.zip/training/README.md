# TerraResQ — AI Flood Segmentation Training Workflow (`training/`)

This folder contains the standalone Python training and evaluation workflow for the **TerraResQ SmallFloodUNet** segmentation model. Heavy Python ML dependencies (`torch`, `rasterio`, `onnx`, `scikit-learn`) are intentionally isolated in `training/requirements-training.txt` so the main React + TypeScript web application stays fast and lightweight for local VS Code development on Windows.

---

## 1. Permitted Datasets & Access Terms

Confirm current access terms and attribution requirements before downloading or redistributing any training dataset:

1. **Sen1Floods11** (Bonafilia et al., 2020)
   - **Contents:** 4,831 non-overlapping $512 \times 512$ tiles at 10 m resolution across 11 global flood events, with Sentinel-1 SAR (`VV`, `VH`) and Sentinel-2 MSI bands.
   - **License:** Creative Commons Attribution 4.0 International (CC BY 4.0).
   - **Citation:** Bonafilia, D., Tellman, B., Anderson, T., & Issenberg, E. (2020). *Sen1Floods11: A Georeferenced Dataset to Train and Test Deep Learning Flood Algorithms for Sentinel-1*. IEEE/CVF CVPR Workshops.
2. **Kuro Siwo** (Bountos et al., 2023)
   - **Contents:** Multi-temporal Sentinel-1 SAR flood segmentation dataset paired with Copernicus DEM elevation conditioning across global flood events.
   - **Note:** Verify current repository license and usage restrictions prior to training.

### Strictly Prohibited Inputs
- **DO NOT** use **EMSR927** or any other **Copernicus EMS** / **UNOSAT** rapid mapping product as training labels, hyperparameter tuning targets, or model input channels.
- **DO NOT** use post-event OpenStreetMap edits as model inputs.

---

## 2. Geographic / Event-Based Split Requirement

Randomly splitting patches from the same satellite scene across `train`, `val`, and `test` sets introduces severe spatial autocorrelation leakage and inflates reported IoU/F1 metrics.

`training/dataset_splits.py` enforces **strict event-disjoint and scene-disjoint partitioning**:
- Every patch record must declare its `event_id` (e.g., `Ghana_2018`, `Mekong_2018`, `Bolivia_2018`) and `scene_id`.
- `verify_event_disjoint_splits()` verifies that:
  $$\text{Events}_{\text{train}} \cap \text{Events}_{\text{val}} = \emptyset, \quad \text{Events}_{\text{train}} \cap \text{Events}_{\text{test}} = \emptyset, \quad \text{Events}_{\text{val}} \cap \text{Events}_{\text{test}} = \emptyset$$
- For the **August 2026 Trishuli Corridor** case study, Nepal scenes are held out completely from training and tuning.

---

## 3. Recorded Model Provenance Manifest (`model_metadata.json`)

When a model is trained via `training/train_unet.py`, it exports both the model weights (`.onnx` / `.pt`) and a structured `model_metadata.json` file containing:
- `sensor`: e.g., `"Sentinel-1 C-Band SAR (IW GRD)"`
- `polarizations_or_bands`: e.g., `["VV (dB)"]` or `["VV (dB)", "VH (dB)"]`
- `preprocessing_steps`: Thermal noise removal, radiometric calibration to $\sigma^0$ (dB), terrain correction (Copernicus DEM-30), dB clamping `[-30, 0]`.
- `dataset_source` & `dataset_license`
- `split_verification`: Event list per split (`train`, `val`, `test`) and patch counts.
- `held_out_test_metrics`: Measured `iou`, `f1_score`, `precision`, `recall` on the held-out geographic test split.
- `limitations`: Explicit operational limitations (radar shadow/layover in steep gorges, wet snow, urban double-bounce).

---

## 4. Loading an Exported Model into the Web App

In the TerraResQ web interface (**AI Segmentation Pathway** tab):
- If no model file and metadata manifest are supplied, the app explicitly displays **`AI model not installed`** (`status: "not assessed"`) and never fabricates model weights or accuracy claims.
- Users can upload their exported `model_metadata.json` and model binary (`.onnx` / `.pt`) to inspect the recorded provenance and activate model-based segmentation separately from the dB threshold baseline.
