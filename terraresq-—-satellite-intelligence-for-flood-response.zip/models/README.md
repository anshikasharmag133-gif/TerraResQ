# TerraResQ Model Weights Directory (`models/`)

Place trained PyTorch flood segmentation checkpoints here:

- `models/dual_sensor_unet_sen1floods11.pt` — Dual-Sensor U-Net trained on **Sen1Floods11** (Bonafilia et al., 2020) and **WorldFloods** (Mateo-Garcia et al., 2021).
- Set `TERRARESQ_MODEL_WEIGHTS=models/dual_sensor_unet_sen1floods11.pt` in `.env` to switch `src/ai/segmentation/inference.py` from `DEMO / MOCK INFERENCE MODE` to `LIVE PYTORCH INFERENCE`.
