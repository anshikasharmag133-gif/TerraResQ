# Raw Satellite & Geospatial Data Directory (`data/raw/`)

Place raw operational satellite scenes and baseline vector extracts here when transitioning from **DEMO MODE** to live operational analysis:

1. **Sentinel-1 C-Band SAR (GRD / IW Dual-Pol VV+VH)**:
   - Place `.SAFE` archives or Cloud-Optimized GeoTIFFs (`*_VV.tif`, `*_VH.tif`) in `data/raw/sentinel1/`.
   - Recommended source: Copernicus Data Space Ecosystem (CDSE) STAC API.

2. **Sentinel-2 MSI Level-2A Optical**:
   - Place 10m/20m bands (`B02.tif`, `B03.tif`, `B04.tif`, `B08.tif`, `B11.tif`, `SCL.tif`) in `data/raw/sentinel2/`.

3. **Copernicus WorldDEM-30 (GLO-30)**:
   - Place 30m elevation tiles (`Copernicus_DSM_COG_10_*.tif`) in `data/raw/dem/`.

4. **Pre-Event OpenStreetMap Extracts**:
   - Place pre-event `.osm.pbf` or `.geojson` snapshots in `data/raw/osm/`.
   - **Data Rule Compliance**: Never place post-event OSM damage edits, Copernicus EMS (`EMSR*`), or UNOSAT damage maps in `data/raw/` for model ingestion.
