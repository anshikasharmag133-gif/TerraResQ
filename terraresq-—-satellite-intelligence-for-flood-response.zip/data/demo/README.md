# Kuro Siwo Flood-Mapping Sample Dataset (`data/demo/`)

This directory contains bundled demonstration data for the **TerraResQ** flood-mapping prototype (Multimodal AI Hackathon 2026, Track B).

## 1. Dataset Origin & Citation
- **Source**: Kuro Siwo: A global multi-temporal SAR dataset for rapid flood mapping
- **Paper**: [arXiv:2311.12056](https://arxiv.org/abs/2311.12056)
- **Repository**: [https://github.com/Orion-AI-Lab/KuroSiwo](https://github.com/Orion-AI-Lab/KuroSiwo)
- **Annotations**: [https://github.com/Orion-AI-Lab/KuroSiwo-annotations](https://github.com/Orion-AI-Lab/KuroSiwo-annotations)
- **Hugging Face**: [orion-ai-lab/Kuro-Siwo-GeoTIFFs](https://huggingface.co/datasets/orion-ai-lab/Kuro-Siwo-GeoTIFFs)
- **License**: MIT License (Copyright © 2024 Orion Lab, Harokopio University of Athens, NOA BEYOND)

### Citation
```bibtex
@article{kurosiwo2023,
  title={Kuro Siwo: A global multi-temporal SAR dataset for rapid flood mapping},
  author={Papoutsis, Ioannis and Bountos, Nikolaos Ioannis and Michail, Dimitrios and others},
  journal={arXiv preprint arXiv:2311.12056},
  year={2023}
}
```

## 2. Included Directory Structure
```
data/
  demo/
    imagery/
      kurosiwo_s1_pre_event_vv.tif        # Pre-event Sentinel-1 VV SAR (EPSG:32645, 10m, dB)
      kurosiwo_s1_post_event_vv.tif       # Post-event Sentinel-1 VV SAR (EPSG:32645, 10m, dB)
      sentinel2_pre_event_rgb.png         # Sentinel-2 pre-event reference optical RGB
      sentinel2_post_event_rgb.png        # Sentinel-2 post-event reference optical RGB
    labels/
      kurosiwo_flood_ground_truth_mask.geojson  # Ground-truth validation polygon mask (EPSG:4326)
    metadata.json                         # Scene metadata, sensor specs, coordinate bounds & metrics
    README.md                             # Dataset documentation and licensing details
```

## 3. Sensor & Image Specifications
- **SAR Imagery**: Sentinel-1 C-Band SAR, Interferometric Wide (IW) swath, VV polarization, decibel (`dB`) values.
- **Coordinate Reference System**: EPSG:32645 (WGS 84 / UTM Zone 45N), with exact ModelPixelScale (`[10.0, 10.0, 0]`) and ModelTiepoint tags conforming to the GeoTIFF 1.1 specification.
- **Dimensions**: 120 × 120 pixels (1.2 km × 1.2 km footprint).
- **Ground Truth Labels**: Ground-truth water polygons formatted in RFC 7946 GeoJSON, derived following Kuro Siwo annotation protocols.

## 4. Operational Data Compliance & Safeguards
- **Zero Data Leakage**: Ground truth labels and external Copernicus EMSR products are strictly isolated from the flood-detection pipeline. They are never ingested as model features or input layers.
- **Honest Provenance Reporting**: When trained neural network weights (`models/dual_sensor_unet_sen1floods11.pt`) are not loaded, the application explicitly reports outputs as **"deterministic threshold-based baseline change detection"** rather than claiming neural network inference.
- **Geospatial Area Defensibility**: Pixel surface areas are computed strictly when georeferencing tags (metric pixel scale in projected CRS or UTM coordinates) are mathematically valid. Arbitrary unprojected degrees are never multiplied directly into square kilometers without metric validation.

## 5. How to Run Demo Mode vs Real Data Mode
1. **One-Click Demo Mode**:
   Click the **[ Load Sample Flood Scenario ]** button in the top navigation bar or the Satellite Analysis panel. The bundled GeoTIFF rasters, optical scenes, dated OSM extracts, and ground-truth validation layers load instantly without external API keys or credentials.
2. **Real Satellite Data Mode**:
   Upload your own pre-event and post-event Sentinel-1 GRD GeoTIFF files or Sentinel-2 Level-2A GeoTIFFs using the upload controls in the **Satellite Imagery & Comparison** panel or the **GeoTIFF Baseline** workbench.
